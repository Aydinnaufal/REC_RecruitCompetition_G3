# REC UM Robocon: Robot Station V 9.2

A PC dashboard (Python, pygame) and the ESP32 firmware for the robot. V 9.0 did the same as V 8.0.4, reorganised into a documented package, plus **Auto-tune** of the gyro gains.

**New in V 9.2**

* **The box lift did not move** because `config.h` in the robot firmware had `ROBOT_TYPE = "simple"`, which drives the grip servo only. It is now `"tower"` (grip on GPIO 18, lift on GPIO 19). Flash `esp32_robot_V_9_2` again. The lift stick works like a speed: full stick moves it 40 % of its travel per second, so end to end takes about 2.5 s. If you build a robot without a lift, set it back to `"simple"`.
* **BACK now stops every turning process first**: a snap turn, a PID step test, Auto-tune, and the Tune page's wheel sliders and start-power search. After that BACK arms or disarms as before (so one press while armed stops the turn and disarms; one press while disarmed stops it and arms).
* Folders renamed to V_9_2.

**V 9.1 (servo trouble and the Tune page)**

* **Reset all** and **Undo** buttons on the Tune page. Reset all (press twice) puts start power, wheel direction, servo limits and the battery ratio back to their defaults. Undo puts back the values from when the robot connected (or from just before the last reset); pressing it again goes forward again.
* **A servo that "cannot move"**: the servo limits are kept in the robot's flash, and a squeezed pair (for example 90..95) lets the servo move 5 degrees only. The tuning firmware now refuses limits less than 10 degrees apart, ignores saved ones that cannot work, and the Tune page warns in red when a servo has almost no room.
* **A servo that hums or stutters**: the default limits are 10..170 degrees (the ends are often the mechanical stop), and servos glide at 100 degrees per second at most (was 150), which is a smaller current spike.
* The tuning sketch (`esp32_tune_V_9_2`) is now part of this folder, readable and split into small files, like the robot firmware.
* Wiring cause not fixable in code: if servos stutter when the wheels start, the servo supply dips. Power the servos from their own 5 V regulator (not the ESP32 board), join all grounds, and put a 470-1000 uF capacitor across the servo supply.

## Quick start

1. Flash `esp32_robot_V_9_2/esp32_robot_V_9_2.ino` to the ESP32 for driving and Auto-tune (open the folder in the Arduino IDE; all `.h` files are part of the sketch). For the **Tune page** flash `esp32_tune_V_9_2/esp32_tune_V_9_2.ino` instead. Both keep their values in the same flash area, so what you tune with one is used by the other.
2. Double-click `run_dashboard.bat` (installs `requirements.txt`, then starts the dashboard). Or run `python run_dashboard.py`.
3. LINK tab: connect (Bluetooth LE or serial). The output starts **disarmed**. Press BACK on the controller (sticks centred) or the OUTPUT button to arm.

## Folder layout

| Path | What is in it |
|---|---|
| `run_dashboard.py` | Starts the dashboard |
| `robot_station/` | The dashboard (see `docs/ARCHITECTURE.md`) |
| `esp32_robot_V_9_2/` | Robot firmware (driving, gyro hold, snap turns, auto-tune), split into small headers |
| `esp32_tune_V_9_2/` | Tuning firmware for the Tune page (motors, servos, gyro, battery), split into small headers |
| `docs/PROTOCOL.md` | The messages between PC and robot |
| `docs/AUTOTUNE.md` | How the auto-tune works and how to use it |

## Auto-tune (PID tab)

Finds Kp, Ki, Kd (hold) and Turn strength / Turn damping (snap turns) by turning the robot, measuring, adjusting and turning again.

1. Put the robot on the floor with about half a metre free around it. Arm the output. Turn **Gyro hold: ON**.
2. On the PID tab choose **Cycles** (tests per stage; fewer is faster) and **Tune:** TURN + HOLD / TURN only / HOLD only.
3. Press **AUTO-TUNE**. The robot turns and drives short distances by itself.
4. It stops at once on: any stick move, E-STOP, disarm, leaving the PID tab, or a lost link. On finishing or stopping it leaves the **best gains it measured** in the robot (saved in flash).

Details and the decision rules are in `docs/AUTOTUNE.md`.

## What did not change

Game, Monitor, Tune and PID modes, the controller mapping, simulated robot, BACK = arm / disarm, auto-reconnect (always comes back disarmed), "Speed without RT", straight-line hold on a lone forward/back stick. Safety is unchanged: disarmed by default, a new or lost link disarms, no command for 400 ms stops the wheels.

## Testing status

Tested on the PC only: 41 dashboard checks, 20 auto-tune checks, 13 Tune-page checks (reset, undo, servo limits), 13 servo checks on the tuning firmware compiled for the PC, the robot firmware compiled for the PC and compared with V 8.0.4 (identical output), and the whole auto-tune run against that compiled firmware with a simulated robot (lag, dead zone, weak left motor). **Not yet tested on the real robot.** Try the first auto-tune with the wheels off the ground, then on the floor with one cycle.

## Settings and files

* `.rec_station_v80.json` is the dashboard settings file (same name as V 8.0, so your settings carry over).
* `tuning_values.txt` is written by the Tune tab.
