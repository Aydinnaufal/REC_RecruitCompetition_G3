"""The Link: connection state machine, heartbeat, handshake, telemetry and frame bookkeeping between the dashboard and the robot."""

import time
from collections import deque

from .errors import friendly_error
from .protocol import Command, FrameParser, TUNE_KEYS, _fmt, encode

TX_HZ = 30.0  # CMD rate


PING_EVERY = 1.0


STALE_AFTER = 0.6  # connected but nothing heard for this long -> STALE


HELLO_EVERY = 0.5


class Link:
    """Call update() every frame. Everything the panel shows is in .state .stats .telemetry .hello .log .last_error."""

    DISCONNECTED, CONNECTING, HANDSHAKE, CONNECTED, STALE, NO_REPLY, ERROR = (
        'DISCONNECTED',
        'CONNECTING',
        'HANDSHAKE',
        'CONNECTED',
        'STALE',
        'NO REPLY',
        'ERROR',
    )

    def __init__(self, clock=time.monotonic):
        """A link starts DISCONNECTED and DISARMED. `clock` is injectable so tests can control time."""
        self.clock = clock
        self.transport, self._factory = None, None
        self.parser = FrameParser()
        self.state, self.armed, self.cmd = self.DISCONNECTED, False, Command()
        self.tune = None  # None, or dict(vl, vr, s1, s2): the Tune page's wish; sent instead of the normal command
        self.log = deque(maxlen=200)  # (time, 'tx' | 'rx' | 'sys' | 'err', text)
        self.last_error = ''
        self._reset_stats()

    def _reset_stats(self):
        """Zero the counters shown on the LINK tab."""
        self.stats = dict(
            tx=0,
            rx=0,
            bad=0,
            tel=0,
            lost=0,
            rtt=None,
            rtt_avg=None,
            rtt_max=0.0,
            rtt_min=None,
            tx_rate=0.0,
            rx_rate=0.0,
            tel_rate=0.0,
            since_rx=None,
            connected_at=None,
        )
        self._seq, self._tel_seq_last = 0, None
        self._sent, self._ping_sent, self._rtts = {}, {}, deque(maxlen=40)
        self._rate_t, self._rate_n = self.clock(), (0, 0, 0)
        self._last_rx, self._next_tx, self._next_ping, self._next_hello = None, 0.0, 0.0, 0.0
        self._hello_deadline = None
        self.telemetry, self.hello, self.heard = {}, {}, False
        self.tune_tel, self.tune_cfg = {}, {}
        self.hold = {}  # the robot's gyro-hold state and settings (HLD frame)

    def say(self, kind, text):
        """Add a line to the log (kind: sys, err, tx, rx)."""
        self.log.append((self.clock(), kind, text))

    @property
    def connected(self):
        """True once the robot has answered, whether or not it is currently silent."""
        return self.state in (self.CONNECTED, self.STALE, self.NO_REPLY)

    @property
    def active(self):
        """True while a link is open or opening."""
        return self.state not in (self.DISCONNECTED, self.ERROR)

    # ---- connect / disconnect
    def connect(self, factory):
        """factory() returns a fresh Transport."""
        self.disconnect(quiet=True)
        self._factory = factory
        self.armed = False  # a new connection always starts disarmed
        self.state = self.CONNECTING
        self._reset_stats()
        self.parser = FrameParser()
        try:
            self.transport = factory()
            self.transport.start_open()
        except Exception as e:
            self._fail('open failed: %s' % friendly_error(e))
            return
        self.say('sys', 'opening %s ...' % self.transport.name)

    def _finish_open(self):
        """The transport finished opening (or failed): start the handshake."""
        t = self.transport
        if t.opening:
            return
        if not t.is_open:
            self._fail('open failed: %s' % (t.last_error or 'unknown error'))
            return
        now = self.clock()
        self.stats['connected_at'] = now
        self.say('sys', 'link open')
        self.state = self.HANDSHAKE
        self._hello_deadline = now + t.handshake_timeout
        self._write(encode('HELLO?'), 'HELLO?')
        self._next_hello = now + HELLO_EVERY

    def disconnect(self, quiet=False):
        """Close the link and disarm. quiet=True skips the log line."""
        if self.transport:
            try:
                if self.transport.is_open:
                    self.transport.write(encode('STOP'))
            except Exception:
                pass
            self.transport.close()
        was = self.state != self.DISCONNECTED
        self.transport, self.state, self.armed = None, self.DISCONNECTED, False
        if was and not quiet:
            self.say('sys', 'disconnected')

    def _fail(self, msg):
        """Go to ERROR with a readable message and close the transport."""
        self.last_error = msg
        self.say('err', msg)
        if self.armed:
            self.say('sys', 'output disarmed because the link failed')
        self.armed, self.state = False, self.ERROR
        if self.transport:
            try:
                self.transport.close()
            except Exception:
                pass

    # ---- send
    def _write(self, data, shown=None):
        """Send bytes; a failed write ends the link. `shown` is what the log displays."""
        try:
            self.transport.write(data)
        except Exception as e:
            self._fail('write failed: %s' % friendly_error(e))
            return False
        self.stats['tx'] += 1
        if shown is not None:
            self.say('tx', shown)
        return True

    def send_raw(self, text):
        """Terminal input: the text plus a newline, exactly as typed."""
        if self.transport and self.transport.is_open:
            self._write(text.encode('ascii', 'replace') + b'\n', text)

    def set_command(self, cmd):
        """The command that the next heartbeat will carry (only used while armed)."""
        self.cmd = cmd

    def send_frame(self, ftype, *fields):
        """One frame that is not the heartbeat (TCFG, CAL ...)."""
        if self.transport and self.transport.is_open:
            self._write(encode(ftype, *fields), ','.join([ftype] + [_fmt(f) for f in fields]))

    def estop(self):
        """Send STOP, then disarm."""
        self.armed = False
        if self.transport and self.transport.is_open:
            self._write(encode('STOP'), 'STOP')
        self.say('sys', 'E-STOP: output disarmed')

    # ---- every frame
    def update(self):
        """Call every frame: read bytes, handle frames, run the timers and send the heartbeat."""
        now = self.clock()
        if self.state == self.CONNECTING and self.transport:
            self._finish_open()
        if not self.transport or self.state in (self.DISCONNECTED, self.ERROR, self.CONNECTING):
            return
        try:
            data = self.transport.read()
        except Exception as e:
            self._fail('link lost: %s' % friendly_error(e))
            return
        if data:
            self._last_rx = now
            for ev in self.parser.feed(data):
                self._event(ev, now)
        self._timers(now)

    def _heard_robot(self):
        """Anything arrived from the robot: leave HANDSHAKE / NO_REPLY / STALE."""
        self.heard = True
        if self.state in (self.HANDSHAKE, self.NO_REPLY, self.STALE):
            if self.state != self.STALE:
                self.say('sys', 'robot answered')
            self.state = self.CONNECTED

    def _event(self, ev, now):
        """Handle one parsed event from the FrameParser (text, bad frame, or a frame)."""
        s = self.stats
        if ev[0] == 'text':
            self.say('rx', ev[1])
            s['rx'] += 1
        elif ev[0] == 'bad':
            s['bad'] += 1
            self.say('err', 'bad frame: %s' % ev[1][:60])
        else:
            _, t, f = ev
            s['rx'] += 1
            try:
                if t == 'TEL':
                    self._on_tel(f, now)
                elif t == 'TUN':
                    self._on_tun(f, now)
                elif t == 'HLD':
                    k = (
                        'mode',
                        'target',
                        'err',
                        'corr',
                        'bal',
                        'gl',
                        'gr',
                        'ml',
                        'mr',
                        'kp',
                        'ki',
                        'kd',
                        'hold',
                        'gsign',
                        'skp',
                        'skd',
                    )
                    self.hold = dict(zip(k, [float(v) for v in f]), at=now)
                    self._heard_robot()
                elif t == 'TCFG':
                    self.tune_cfg = dict(zip(TUNE_KEYS, [float(v) for v in f]))
                    self._heard_robot()
                elif t == 'PONG':
                    self._heard_robot()
                    t0 = self._ping_sent.pop(int(f[0]), None)
                    if t0 is not None:
                        self._rtt(now - t0)
                elif t == 'HELLO':
                    self.hello = dict(
                        proto=f[0], fw=f[1], robot=f[2], version=f[3] if len(f) > 3 else ''
                    )
                    self.say('rx', '$HELLO ' + ' '.join(f))
                    self._heard_robot()
                else:
                    self._heard_robot()
                    self.say('rx', '$%s %s' % (t, ' '.join(f)))
            except (IndexError, ValueError):
                s['bad'] += 1
                self.say('err', 'malformed %s' % t)

    def _on_tel(self, f, now):
        """A TEL frame: store the telemetry, work out packet loss and the round-trip time."""
        s = self.stats
        tseq, ack = int(f[0]), int(f[1])
        self.telemetry = dict(
            tseq=tseq,
            ack=ack,
            t_ms=int(f[2]),
            yaw=float(f[3]),
            gz=float(f[4]),
            vl=int(f[5]),
            vr=int(f[6]),
            grip=int(f[7]),
            lift=int(f[8]),
            vbat_mv=int(f[9]),
            flags=int(f[10]),
            at=now,
        )
        s['tel'] += 1
        if self._tel_seq_last is not None:
            gap = (tseq - self._tel_seq_last) % 65536
            if 1 < gap < 1000:
                s['lost'] += gap - 1
        self._tel_seq_last = tseq
        t0 = self._sent.pop(ack, None)
        if t0 is not None:
            self._rtt(now - t0)
        for k in [k for k in self._sent if (ack - k) % 65536 < 30000 and k != ack]:
            self._sent.pop(k, None)
        self._heard_robot()

    def _on_tun(self, f, now):
        """The tuning firmware's telemetry. It also fills self.telemetry (TEL layout) so the Link tab keeps working."""
        pl, pr = int(f[3]), int(f[4])
        self.tune_tel = dict(
            pwm_l=pl,
            pwm_r=pr,
            s1=int(f[5]),
            s2=int(f[6]),
            gx=float(f[7]),
            gy=float(f[8]),
            gz=float(f[9]),
            ax=float(f[10]),
            ay=float(f[11]),
            az=float(f[12]),
            temp=float(f[13]),
            yaw=float(f[14]),
            who=int(f[17]),
            at=now,
        )
        self._on_tel(
            [
                f[0],
                f[1],
                f[2],
                f[14],
                f[9],
                str(round(pl * 100 / 255)),
                str(round(pr * 100 / 255)),
                '0',
                '0',
                f[15],
                f[16],
            ],
            now,
        )

    def _rtt(self, r):
        """Record one round-trip time in milliseconds."""
        s = self.stats
        s['rtt'] = r * 1000
        self._rtts.append(r * 1000)
        s['rtt_avg'] = sum(self._rtts) / len(self._rtts)
        s['rtt_max'] = max(s['rtt_max'], r * 1000)
        s['rtt_min'] = r * 1000 if s['rtt_min'] is None else min(s['rtt_min'], r * 1000)

    def _timers(self, now):
        """Handshake retries, PING, silence detection (STALE / NO_REPLY)."""
        s = self.stats
        if self.state == self.HANDSHAKE:
            if now >= self._next_hello:
                self._next_hello = now + HELLO_EVERY
                self._write(encode('HELLO?'))
            if self._hello_deadline is not None and now > self._hello_deadline:
                self.state, self._next_hello = self.NO_REPLY, now + 1.0
                self.say(
                    'err',
                    'link is open but the robot is silent: is it powered and running the V_5_0 firmware?',
                )
        elif self.state == self.NO_REPLY and now >= self._next_hello:
            self._next_hello = now + 1.0
            self._write(encode('HELLO?'))
        elif (
            self.state in (self.CONNECTED, self.STALE)
            and not self.hello
            and now >= self._next_hello
        ):
            self._next_hello = (
                now + 2.0
            )  # telemetry arrived but the banner did not: ask again so the version shows
            self._write(encode('HELLO?'))
        s['since_rx'] = None if self._last_rx is None else now - self._last_rx
        if (
            self.state == self.CONNECTED
            and s['since_rx'] is not None
            and s['since_rx'] > STALE_AFTER
            and self.heard
        ):
            self.state = self.STALE
            self.say('err', 'link stale: nothing heard for %.1f s' % s['since_rx'])
        if self.state in (self.CONNECTED, self.STALE, self.HANDSHAKE, self.NO_REPLY):
            if now >= self._next_tx:
                self._next_tx = max(self._next_tx + 1.0 / TX_HZ, now - 0.1)
                self._send_cmd(now)
            if now >= self._next_ping:
                self._next_ping = now + PING_EVERY
                self._seq = (self._seq + 1) % 65536
                self._ping_sent[self._seq] = now
                if len(self._ping_sent) > 8:
                    self._ping_sent.pop(next(iter(self._ping_sent)))
                self._write(encode('PING', self._seq))
        if now - self._rate_t >= 1.0:
            dt = now - self._rate_t
            tx, rx, tel = s['tx'], s['rx'], s['tel']
            s['tx_rate'], s['rx_rate'], s['tel_rate'] = (
                (tx - self._rate_n[0]) / dt,
                (rx - self._rate_n[1]) / dt,
                (tel - self._rate_n[2]) / dt,
            )
            self._rate_n, self._rate_t = (tx, rx, tel), now

    def _send_cmd(self, now):
        """Send the heartbeat: the command while armed and fresh, zeros otherwise."""
        self._seq = (self._seq + 1) % 65536
        self._sent[self._seq] = now
        if len(self._sent) > 60:
            self._sent.pop(next(iter(self._sent)))
        if (
            self.tune is not None
        ):  # Tune page: wheels in percent, servos in degrees; disarmed = wheels zero, servos keep where they are
            t, a = self.tune, self.armed
            c = lambda v, lo, hi: int(max(lo, min(hi, round(v))))
            self._write(
                encode(
                    'CMD',
                    self._seq,
                    c(t['vl'], -100, 100) if a else 0,
                    c(t['vr'], -100, 100) if a else 0,
                    c(t['s1'], -1, 180) if a else -2,
                    c(t['s2'], -1, 180) if a else -2,
                    1 if a else 0,
                )
            )
            return
        cmd = self.cmd.clamped() if self.armed else self.cmd.zero()
        cmd.enable = self.armed
        if cmd.enable and cmd.hdg is not None:
            fields = [self._seq, cmd.vl, cmd.vr, cmd.grip, cmd.lift, 1, int(round(cmd.hdg * 10))]
            if cmd.steer:
                fields.append(1)
            self._write(encode('CMD', *fields))
        else:
            self._write(
                encode('CMD', self._seq, cmd.vl, cmd.vr, cmd.grip, cmd.lift, 1 if cmd.enable else 0)
            )

    # ---- helpers for the panel
    def telemetry_age(self):
        """Seconds since the last TEL frame, or None if there has been none."""
        t = self.telemetry.get('at')
        return None if t is None else self.clock() - t

    def uptime(self):
        """Seconds since the robot answered."""
        c = self.stats.get('connected_at')
        return 0.0 if c is None or not self.connected else self.clock() - c

    def loss_percent(self):
        """Share of telemetry frames that never arrived."""
        s = self.stats
        total = s['tel'] + s['lost']
        return 0.0 if total == 0 else 100.0 * s['lost'] / total

    def quality(self):
        """0..4 bars from latency, loss and freshness. 0 when not connected."""
        if self.state in (self.STALE, self.NO_REPLY):
            return 1
        if not self.connected:
            return 0
        rtt = self.stats['rtt_avg']
        if rtt is None:
            return 2
        q = 4 - (rtt > 60) - (rtt > 150) - (self.loss_percent() > 2) - (self.loss_percent() > 10)
        return max(1, q)
