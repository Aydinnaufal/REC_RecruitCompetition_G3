"""The rec1 wire protocol: how frames are built, checked and parsed.

A frame is one line of ASCII text::

    $TYPE,field1,field2*HH\n

HH is the XOR of every character between ``$`` and ``*``, in hex. A line without a ``$`` is plain text and is shown as it is.

Laptop -> robot::

    CMD,seq,vl,vr,grip,lift,enable[,hdg[,steer]]   30 per second, also the heartbeat.
                                           hdg = target yaw in tenths of a degree: the robot turns to it with its gyro.
                                           steer = 1: reach it while driving (straight-line PID) instead of turning in place.
    PING,n   HELLO?   STOP   ZERO   CAL   CFG,name,value

Robot -> laptop::

    HELLO,proto,fw,robot,version
    TEL,seq,ack,ms,yaw,gz,vl,vr,grip,lift,vbat_mv,flags
    HLD,mode,target,err,corr,bal,gl,gr,ml,mr,kp,ki,kd,hold,gsign,skp,skd   gyro control state and settings, 10 per second
    PONG,n   ACK,...

Tuning firmware (esp32_tune)::

    CMD,seq,vl,vr,s1,s2,enable    servo angle 0..180, -1 = limp, -2 = keep
    TCFG,name,value   CAL
    robot -> TUN,seq,ack,ms,pwmL,pwmR,s1,s2,gx,gy,gz,ax,ay,az,temp,yaw,vbat_mv,flags,whoami
             TCFG,minpwm,invl,invr,lo1,hi1,lo2,hi2,ratio

Safety: a new or lost link is always DISARMED; while disarmed the robot is sent zeros; the robot's own failsafe stops it after 400 ms of silence.
"""

F_ARMED, F_FAILSAFE, F_GYRO_OK, F_GYRO_CAL, F_LOWBAT = 1, 2, 4, 8, 16


TUNE_KEYS = (
    'minpwm',
    'invl',
    'invr',
    'lo1',
    'hi1',
    'lo2',
    'hi2',
    'ratio',
)  # the tuning values the tuning firmware keeps, in the order of its TCFG frame


def checksum(body):
    """XOR of the characters of a frame body."""
    c = 0
    for ch in body.encode('ascii', 'replace'):
        c ^= ch
    return c


def _fmt(v):
    """A number as short text (no trailing zeros)."""
    if isinstance(v, float):
        return ('%.2f' % v).rstrip('0').rstrip('.') if v != int(v) else str(int(v))
    return str(v)


def encode(ftype, *fields):
    """Build one frame: encode("CMD", 1, 50) -> b"$CMD,1,50*HH\n"."""
    body = ','.join([ftype] + [_fmt(f) for f in fields])
    return ('$%s*%02X\n' % (body, checksum(body))).encode('ascii')


class FrameParser:
    """Feed it bytes as they arrive. Returns events: ('frame', type, [fields]) | ('bad', text) | ('text', line)."""

    def __init__(self, maxline=240):
        """Lines longer than `maxline` are dropped."""
        self.buf, self.maxline, self.bad = bytearray(), maxline, 0

    def feed(self, data):
        """Bytes in; a list of events out: ("frame", type, fields), ("text", line) or ("bad", reason)."""
        out = []
        for b in data:
            if b == 10:
                out += self._line(bytes(self.buf).decode('ascii', 'replace').rstrip('\r'))
                self.buf.clear()
            elif len(self.buf) < self.maxline:
                self.buf.append(b)
            else:
                self.buf.clear()
                self.bad += 1
                out.append(('bad', 'line too long'))
        return out

    def _line(self, s):
        """Turn one complete line into an event."""
        if not s:
            return []
        if s[0] != '$':
            return [('text', s)]
        body, _, hh = s[1:].rpartition('*')
        try:
            ok = '*' in s and int(hh[:2], 16) == checksum(body)
        except ValueError:
            ok = False
        if not ok:
            self.bad += 1
            return [('bad', s)]
        parts = body.split(',')
        return [('frame', parts[0], parts[1:])]


class Command:
    """What the laptop wants the robot to do.

    Wheels in percent (-100..100), grip 0..100 (0 = open), box lift -100..100 (up positive).
    ``hdg`` is a target yaw in degrees (None = no target). By default the robot turns to it in
    place (snap turn); with ``steer=True`` it reaches it while driving, using the straight-line
    PID (this is what the auto-tuner uses to test Kp, Kd and Ki).
    """

    def __init__(self, vl=0, vr=0, grip=0, lift=0, enable=False, hdg=None, steer=False):
        self.vl = vl
        self.vr = vr
        self.grip = grip
        self.lift = lift
        self.enable = enable
        self.hdg = hdg
        self.steer = steer

    def clamped(self):
        """A copy limited to what the protocol allows (wheels +-100, grip 0..100)."""

        def limit(value, low, high):
            return int(max(low, min(high, round(value))))

        return Command(
            limit(self.vl, -100, 100),
            limit(self.vr, -100, 100),
            limit(self.grip, 0, 100),
            limit(self.lift, -100, 100),
            bool(self.enable),
            self.hdg,
            self.steer,
        )

    def zero(self):
        """A command that asks for nothing."""
        return Command(0, 0, 0, 0, False)
