"""The PID page: history of the robot's gyro control, step tests, and the control settings kept in the robot."""

from collections import deque

from robot_station import ui
from robot_station.config import PID


class PidPageMixin:
    """The PID page: history of the robot's gyro control, step tests, and the control settings kept in the robot."""

    def _init_pid_page(self):
        self.hist = deque(maxlen=400)  # the last samples of the robot's gyro control
        self.hist_pause = False
        self.hist_at = None  # time of the newest sample
        self.pid_test = None  # the running step test, see pid_start()
        self.pid_result = ''  # text shown under the graphs
        self.pid_ended = ''  # how the last test ended: 'done' or 'stopped'

    def sample_hist(self):
        """Add the newest HLD report to the history that the PID graphs draw."""
        if self.hist_pause or not self.hold_fresh():
            return
        h, t = self.link.hold, self.link.telemetry
        if h['at'] == self.hist_at:
            return
        self.hist_at = h['at']
        self.hist.append(
            dict(
                t=h['at'],
                yaw=t.get('yaw', 0.0),
                gz=t.get('gz', 0.0),
                target=h['target'],
                err=h['err'],
                corr=h['corr'],
                bal=h['bal'],
                vl=t.get('vl', 0),
                vr=t.get('vr', 0),
                mode=int(h['mode']),
            )
        )

    def pid_start(self, kind, deg=0.0, speed=50.0, duration=None, auto=False):
        """Start a step test. Needs the output armed and PID data from the robot. Returns True if it started.

        kind:
          "straight"  drive straight at `speed` percent (the hold keeps the line)
          "turn"      turn in place by `deg` degrees (the snap-turn controller)
          "steer"     change heading by `deg` degrees while driving at `speed` (the hold controller)
          "drift"     like straight; used by the auto-tuner to watch the balance being learned
        auto: the auto-tuner started it, so no result line is written (the tuner reports instead).
        """
        link = self.link
        if not (link.armed and self.hold_fresh()):
            link.say('err', 'step test: connect and ARM OUTPUT first')
            return False
        if duration is None:
            duration = {'straight': 3.0, 'turn': 4.0, 'steer': 3.0, 'drift': 4.0}[kind]
        yaw = link.telemetry.get('yaw', 0.0)
        self.pid_test = dict(
            kind=kind,
            t0=link.clock(),
            deg=deg,
            y0=yaw,
            target=yaw + deg,
            dur=duration,
            speed=speed,
            auto=auto,
        )
        self.pid_result = '' if auto else 'running ... (move a stick to stop it)'
        return True

    def apply_step_test(self, cmd):
        """Let the running step test override the wheel command; end it when it is done or must stop."""
        test, link, sim = self.pid_test, self.link, self.sim
        now = link.clock()
        yaw, turn_rate = link.telemetry.get('yaw', 0.0), link.telemetry.get('gz', 0.0)

        # A stick move, a disarmed output or leaving the page stops the test.
        if abs(sim.raw_l) + abs(sim.raw_r) > 0.05 or not link.armed or self.mode != PID:
            self.pid_cancel('stopped')
            return

        # A test with a target ends 0.6 s after the robot has settled on it.
        if test['kind'] in ('turn', 'steer'):
            arrived = (
                abs(yaw - test['target']) < 1.5 and abs(turn_rate) < 12 and now - test['t0'] > 0.8
            )
            if arrived:
                test.setdefault('arrive', now)
            else:
                test.pop('arrive', None)
        settled = test.get('arrive') is not None and now - test['arrive'] > 0.6
        if now - test['t0'] > test['dur'] or settled:
            self.pid_cancel('done')
            return

        if test['kind'] == 'turn':
            cmd.vl = cmd.vr = 0
            cmd.hdg = test['target']
        elif test['kind'] == 'steer':
            cmd.vl = cmd.vr = test['speed']
            cmd.hdg = test['target']
            cmd.steer = True
        else:  # straight, drift
            cmd.vl = cmd.vr = test['speed']

    def pid_cancel(self, why=''):
        """End the running step test; with why="done" the result line is worked out from the history."""
        tt = self.pid_test
        if tt is None:
            return
        self.pid_test = None
        self.pid_ended = why
        if tt.get('auto'):
            return  # the auto-tuner measures and reports by itself
        rows = [r for r in self.hist if r['t'] >= tt['t0']]
        if why != 'done' or not rows:
            self.pid_result = 'test stopped'
        elif tt['kind'] == 'straight':
            emax = max([abs(r['err']) for r in rows if r['mode'] == 2] or [0.0])
            self.pid_result = (
                'straight run: biggest error %.1f deg, ended %+.1f deg from the start heading, balance %+.2f %%'
                % (emax, rows[-1]['yaw'] - tt['y0'], rows[-1]['bal'])
            )
        else:
            sg = 1 if tt['deg'] > 0 else -1
            over = max((r['yaw'] - tt['y0']) * sg for r in rows) - abs(tt['deg'])
            late = [r['t'] for r in rows if abs(r['yaw'] - tt['target']) >= 2.0]
            settle = (max(late) - tt['t0'] + 0.1) if late else 0.0
            self.pid_result = (
                'turn %+d deg: overshoot %+.1f deg, settled in %.1f s, final error %+.1f deg'
                % (tt['deg'], over, settle, rows[-1]['yaw'] - tt['target'])
            )

    def pid_status(self):
        """(text, colour) for the PID page header."""
        l = self.link
        if not l.connected:
            return 'NOT CONNECTED: open the LINK tab, connect to REC-Robot', ui.WARN
        if not self.hold_fresh():
            return 'connected, but no PID data: flash esp32_robot_V_9_3', ui.WARN
        return (
            'OUTPUT LIVE: the robot can move'
            if l.armed
            else 'connected. ARM OUTPUT (LINK tab) to run the tests'
        ), (ui.BAD if l.armed else ui.OK)

    def hold_fresh(self):
        """True when the robot's HLD report is recent."""
        h = self.link.hold
        return bool(h) and self.link.connected and self.link.clock() - h['at'] < 1.5

    def hcfg(self, key):
        """A gyro control setting as the robot reports it, or None."""
        return self.link.hold.get(key) if self.hold_fresh() else None

    def set_hcfg(self, key, v):
        """Change a gyro control setting in the robot (CFG frame; the robot keeps it in flash)."""
        self.link.send_frame('CFG', key, v)
        self.link.hold[key] = float(v)  # shown at once; the robot's next HLD confirms it

    def hold_toggle(self):
        """Switch the straight-line gyro hold on or off."""
        self.set_hcfg('hold', 0 if self.hcfg('hold') else 1)

    def gyro_flip(self):
        """Flip the gyro direction (use when turning left makes the yaw go down)."""
        self.set_hcfg('gsign', -(self.hcfg('gsign') or 1))
