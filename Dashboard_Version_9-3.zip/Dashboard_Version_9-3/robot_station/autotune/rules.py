"""The tuning rules: from "how did the last run go" to "which gain to change, and which way".

Each rule gets the gains that gave the best run so far, the measurements of that run and a
relative step size (0.5 = change by about half). It returns ``(new_gains, reason)`` or ``None``
when it sees nothing left worth changing.

The rules read the response the way a person does:

* swinging past the target or ringing  -> not enough damping (raise the D gain; if it is bad,
  soften the P gain too)
* jumpy correction once settled        -> too much damping (lower the D gain)
* slow, or never arrives               -> not enough push (raise the P gain)
* smooth, no overshoot                 -> try a bit faster (raise the P gain a little); the
  tuner keeps the new gain only if the measured cost really got better.
"""

# Gain limits: the same as the spin boxes on the PID page.
LIMITS = {
    'skp': (0.2, 4.0),
    'skd': (0.0, 1.0),
    'kp': (0.0, 5.0),
    'kd': (0.0, 2.0),
    'ki': (0.0, 5.0),
}

# Smallest useful change of each gain: a gain of 0 cannot grow by a percentage.
MIN_CHANGE = {'skp': 0.1, 'skd': 0.05, 'kp': 0.1, 'kd': 0.05, 'ki': 0.1}

OVERSHOOT_LIMIT_PCT = 10.0  # more than this counts as "swings past the target"
BAD_OVERSHOOT_PCT = 25.0  # ... and this as "much too lively"
SMOOTH_OVERSHOOT_PCT = 3.0  # less than this counts as "smooth"
CHATTER_LIMIT = 0.5  # jumpiness above this counts as "too much damping / noise"


def change(gains, key, direction, step):
    """Return a copy of ``gains`` with ``key`` raised (direction +1) or lowered (-1) by ``step``."""
    value = gains[key]
    delta = max(abs(value) * step, MIN_CHANGE[key])
    low, high = LIMITS[key]
    new = min(high, max(low, value + direction * delta))
    return dict(gains, **{key: round(new, 2)})  # the protocol and the robot's report use 2 decimals


def differs(a, b):
    """True when two gain sets are not the same."""
    return any(abs(a[k] - b[k]) > 1e-6 for k in a)


def _result(old, new, reason):
    return (new, reason) if differs(old, new) else None


def propose_turn(gains, m, step):
    """Turn in place: gains ``skp`` (turn strength) and ``skd`` (turn damping)."""
    new = dict(gains)
    if m.ringing >= 2 or m.overshoot_pct > OVERSHOOT_LIMIT_PCT:
        new = change(new, 'skd', +1, step)
        reason = 'it swings past the target: more turn damping'
        if m.overshoot_pct > BAD_OVERSHOOT_PCT or m.ringing >= 3:
            new = change(new, 'skp', -1, step / 2)
            reason += ' and a softer push'
    elif m.chatter > CHATTER_LIMIT:
        new = change(new, 'skd', -1, step)
        reason = 'the correction is jumpy: less turn damping'
    elif not m.reached or not m.settled:
        new = change(new, 'skp', +1, step)
        reason = 'it does not settle on the target: more turn strength'
    elif m.overshoot_pct < SMOOTH_OVERSHOOT_PCT:
        new = change(new, 'skp', +1, step / 2)
        reason = 'smooth and safe: try a faster turn'
    else:
        return None
    return _result(gains, new, reason)


def propose_steer(gains, m, step):
    """Steering while driving: gains ``kp`` (hold strength) and ``kd`` (hold damping)."""
    new = dict(gains)
    if m.ringing >= 2 or m.overshoot_pct > OVERSHOOT_LIMIT_PCT:
        new = change(new, 'kd', +1, step)
        reason = 'it swings past the heading: more hold damping'
        if m.overshoot_pct > BAD_OVERSHOOT_PCT or m.ringing >= 3:
            new = change(new, 'kp', -1, step / 2)
            reason += ' and a softer push'
    elif m.chatter > CHATTER_LIMIT:
        new = change(new, 'kd', -1, step)
        reason = 'the correction is jumpy: less hold damping'
    elif m.saturation > 0.6:
        return None  # the correction is at its 25 % limit most of the time: a bigger Kp cannot help
    elif not m.reached or not m.settled:
        new = change(new, 'kp', +1, step)
        reason = 'it does not settle on the heading: more hold strength'
    elif m.overshoot_pct < SMOOTH_OVERSHOOT_PCT:
        new = change(new, 'kp', +1, step / 2)
        reason = 'smooth and safe: try a stronger hold'
    else:
        return None
    return _result(gains, new, reason)


def propose_drift(gains, m, step, tolerance_deg=1.0):
    """Straight drive with the balance reset: gain ``ki`` (hold learning)."""
    new = dict(gains)
    if m.ringing >= 2:
        new = change(new, 'ki', -1, step)
        reason = 'the error swings across zero: it learns too aggressively, lower Ki'
    elif m.final_error_deg > tolerance_deg or m.settle_s > 2.5:
        new = change(new, 'ki', +1, step)
        reason = 'the lean is learned away too slowly: raise Ki'
    else:
        return None
    return _result(gains, new, reason)
