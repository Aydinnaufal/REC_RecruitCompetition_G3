"""Version, file locations and the layout of the dashboard.

Everything is drawn on a fixed "design canvas" of CW x CH pixels, which main.py scales to the
real window. All positions below are canvas pixels.

The screen is three columns under a top bar::

    +--------------------------------- top bar ---------------------------------+
    | left column  |        centre column (picture, gauges)        | right column |
    | controller   |                                               | LINK / SETTINGS |
    +--------------+-----------------------------------------------+--------------+
"""

import os

from robot_station import comms
from robot_station import ui

# ---------------------------------------------------------------- version and files
VERSION = 'V 9.3'

# The folder that holds run_dashboard.py: files that sit next to the program live here.
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Remembered between runs (which robot, auto-reconnect, speed without RT). The file name is the
# same as in version 8 so the saved robot is found again.
SETTINGS_FILE = os.path.join(os.path.expanduser('~'), '.rec_station_v80.json')

# "Save values to a file" on the Tune page writes here.
TUNE_FILE = os.path.join(PROJECT_ROOT, 'tuning_values.txt')

# What "Reset all" on the Tune page puts back: the same defaults as esp32_tune_V_9_3.
# The servo limits stop 10 degrees short of each end: the last degrees are often the servo's
# mechanical stop, where it hums and draws a lot of current.
TUNE_DEFAULTS = {
    'minpwm': 0,  # start power: 0 = the percent goes straight to PWM
    'invl': 0,  # wheels not reversed
    'invr': 0,
    'lo1': 10,  # servo 1 limits, degrees
    'hi1': 170,
    'lo2': 10,  # servo 2 limits, degrees
    'hi2': 170,
    'ratio': 3.13,  # battery divider: 100k over 47k = 147 / 47 (frames carry 2 decimals)
}
SERVO_MIN_SPAN = 10  # servo limits closer together than this (degrees) are refused

# ---------------------------------------------------------------- pages
GAME, MONITOR, TUNE, PID = 'game', 'monitor', 'tune', 'pid'

# Tabs of the right column, and what the dropdowns offer.
TABS = [('link', 'LINK'), ('settings', 'SETTINGS')]
SOURCES = [('sim', 'Simulation'), ('robot', 'Robot (live)')]
TRANSPORTS = [('ble', 'Bluetooth LE'), ('serial', 'USB cable')]

# ---------------------------------------------------------------- canvas and columns
CW, CH = 1440, 860  # design canvas
M = 12  # margin around and between columns
TOP, BOT = 60, 832  # the columns run from y = TOP to y = BOT

LX, LW = M, 300  # left column: x and width
CX, CWD = LX + LW + M, 720  # centre column
RX, RW = CX + CWD + M, 372  # right column

VP = (CX + 12, 112, CWD - 24, 456)  # the 3D picture: x, y, width, height

# Inside the right column: cards start at X0 and are WW wide; widgets keep 10 px from the edge.
X0, WW = RX + 12, RW - 24

# The Tune and PID pages cover the controller panel and the centre column.
PAGE = (LX, TOP, CX + CWD - LX, BOT - TOP)

# ---------------------------------------------------------------- colours
# Link state -> colour of the light in the top bar.
STATE_COL = {
    comms.Link.CONNECTED: ui.OK,
    comms.Link.STALE: ui.WARN,
    comms.Link.HANDSHAKE: ui.WARN,
    comms.Link.CONNECTING: ui.WARN,
    comms.Link.NO_REPLY: ui.WARN,
    comms.Link.ERROR: ui.BAD,
}
AMBER = (238, 168, 58)  # "busy / careful" tiles and bars
OFF_RED = (112, 42, 40)  # a switch that is off on purpose (TURN)
