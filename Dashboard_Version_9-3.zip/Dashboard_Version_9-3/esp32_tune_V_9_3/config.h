// config.h - names, pins and limits of the tuning firmware.
#pragma once

const char* BT_NAME = "REC-Robot";  // Bluetooth name the dashboard scans for
const char* FW_VERSION = "V_9_3";

// ---------------------------------------------------------------- pins
// L298N (or any driver with two inputs per motor): speed is PWM on the IN pins.
const int IN1 = 26, IN2 = 27;  // left motor
const int IN3 = 32, IN4 = 33;  // right motor
const int SERVO1_PIN = 18;     // grip
const int SERVO2_PIN = 19;     // lift
const int BATTERY_PIN = 34;    // battery divider
const int LED_PIN = 2;         // on-board LED
// MPU6050 gyro: SDA = GPIO 21, SCL = GPIO 22 (see imu.h)

// ---------------------------------------------------------------- safety
const uint32_t FAILSAFE_MS = 400;  // no valid CMD for this long = the wheels stop

// ---------------------------------------------------------------- servos
const float SERVO_DPS = 100.0f;  // servos move at most this fast (degrees per second). A sudden full
                                 // swing is a current spike that can dip the supply and make the servo
                                 // stutter or the ESP32 reset.
// The last few degrees at each end are often the servo's mechanical stop: pushing there makes it hum
// and draw a lot of current. These limits are used when none are saved, after "reset all" on the
// dashboard, and when the saved ones cannot work.
const int SERVO_SAFE_LOW = 10, SERVO_SAFE_HIGH = 170;
const int SERVO_MIN_SPAN = 10;  // limits closer together than this (degrees) are ignored

// ---------------------------------------------------------------- battery
// Divider on GPIO 34: 100k on top, 47k below gives (100 + 47) / 47.
const float DEFAULT_VBAT_RATIO = 147.0f / 47.0f;
