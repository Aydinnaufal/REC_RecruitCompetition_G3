// gyro.h - MPU6050 on I2C (SDA 21, SCL 22), only the Z-axis rate is used.
#pragma once
#include <Wire.h>

const uint8_t MPU_ADDRESS = 0x68;

void gyroInit() {
  Wire.begin(21, 22);
  Wire.setClock(400000);
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(0x6B);  // power management: wake up
  Wire.write(0);
  imuOk = Wire.endTransmission() == 0;
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(0x1B);  // gyro range +-250 deg/s
  Wire.write(0);
  Wire.endTransmission();
}

// Z-axis rate in deg/s. Returns false if the sensor did not answer.
bool readGyroZ(float& dps) {
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(0x47);
  if (Wire.endTransmission(false) || Wire.requestFrom(MPU_ADDRESS, 2) != 2) return false;
  uint8_t high = Wire.read();
  uint8_t low = Wire.read();
  dps = (int16_t)((high << 8) | low) / 131.0f;
  return true;
}

// Measure the zero-rate offset: the robot must stand still for one second.
void startCalibration() {
  gyroCalibrating = true;
  calSamples = 0;
  calSum = 0;
  calStartMs = millis();
}

// Call every loop: reads the sensor at 100 Hz and integrates the yaw angle.
void updateGyro(uint32_t now) {
  if (!imuOk || now - lastGyroMs < 10) return;
  float dt = (now - lastGyroMs) * 1e-3f, dps;
  lastGyroMs = now;
  if (!readGyroZ(dps)) return;
  if (gyroCalibrating) {
    calSum += dps;
    calSamples++;
    yawRate = 0;
    if (now - calStartMs > 1000 && calSamples > 20) {
      gyroBias = calSum / calSamples;
      gyroCalibrating = false;
      yaw = 0;
    }
  } else {
    yawRate = (dps - gyroBias) * gsign;
    if (fabsf(yawRate) > GYRO_DEADBAND) yaw += yawRate * dt;
  }
}
