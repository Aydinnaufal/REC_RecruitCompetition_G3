// protocol.h - the rec1 text protocol over USB and Bluetooth.
//
// A frame is one line:  $TYPE,field,field*HH\n   (HH = XOR of everything between $ and *, in hex)
//
// Dashboard -> robot
//   CMD,seq,vl,vr,grip,lift,enable[,hdg[,steer]]
//        sent 30 times a second, it is also the heartbeat. Nothing moves unless enable = 1.
//        hdg   = target yaw in tenths of a degree; the robot turns to it with its gyro.
//        steer = 1: reach that heading while DRIVING (the straight-line PID steers there, used by auto-tune).
//   PING,n   HELLO?   STOP   ZERO   CAL   CFG,name,value
// Robot -> dashboard
//   HELLO,proto,fw,robot,version   RST,reason,seconds   PONG,n,ms   ACK,...
//   TEL,seq,ack,ms,yaw,gz,vl,vr,grip,lift,vbat_mv,flags
//   HLD,mode,target,err,corr,bal,gl,gr,ml,mr,kp,ki,kd,hold,gsign,skp,skd
#pragma once
#include <esp_system.h>

// One serial-like connection (USB or Bluetooth) with its line buffer.
struct Port {
  Stream* stream;
  uint32_t lastRxMs;   // when a valid frame last arrived (0 = never)
  char line[120];      // the line being received
  size_t length;
  uint32_t telemetryPeriodMs;  // how often TEL goes out on this port
};

enum { PORT_USB = 0, PORT_BLE = 1 };
Port ports[2] = {{&Serial, 0, {0}, 0, 50}, {&ble, 0, {0}, 0, 100}};

uint8_t checksum(const char* body) {
  uint8_t c = 0;
  while (*body) c ^= (uint8_t)*body++;
  return c;
}

void sendFrame(Port& port, const char* body) {
  char out[200];
  int n = snprintf(out, sizeof out, "$%s*%02X\n", body, checksum(body));
  if (n > 0 && n < (int)sizeof out) port.stream->write((const uint8_t*)out, n);
}

// A port is usable if it heard a frame in the last 3 s (and, for Bluetooth, is still connected).
bool portUsable(Port& port) {
  return port.lastRxMs && millis() - port.lastRxMs < 3000 && (&port != &ports[PORT_BLE] || ble.connected);
}

// The port that heard the dashboard most recently, or nullptr.
Port* activePort() {
  Port* best = nullptr;
  for (auto& p : ports)
    if (portUsable(p) && (!best || (int32_t)(p.lastRxMs - best->lastRxMs) > 0)) best = &p;
  return best;
}

// Why the board last restarted. BROWNOUT means the supply dipped.
const char* resetReasonText() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON: return "poweron";
    case ESP_RST_SW: return "software";
    case ESP_RST_BROWNOUT: return "BROWNOUT";
    case ESP_RST_PANIC: return "CRASH";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT: return "watchdog";
    default: return "other";
  }
}

// ---------------------------------------------------------------- reports
// HLD: what the gyro control is doing and its settings.
void sendControlState(Port& port) {
  float target = holding ? holdYaw : (turnActive ? turnTarget : yaw);
  char out[170];
  snprintf(out, sizeof out, "HLD,%d,%.1f,%.1f,%.1f,%.2f,%.2f,%.2f,%d,%d,%.2f,%.2f,%.2f,%d,%d,%.2f,%.2f",
           controlMode, target, headingError, correction, bal, gl, gr, (int)ml, (int)mr, kp, ki, kd,
           (int)hold, (int)gsign, skp, skd);
  sendFrame(port, out);
}

// TEL: heading, turn rate, wheel speeds, battery and status flags.
void sendTelemetry(Port& port) {
  int batteryMv = 0;
  if (VBAT_RATIO > 0) {
    uint32_t sum = 0;
    for (int i = 0; i < 8; i++) sum += analogReadMilliVolts(BATTERY_PIN);
    batteryMv = (int)(sum / 8 * VBAT_RATIO);
  }
  bool failsafe = millis() - lastCmdMs > FAILSAFE_MS;
  int flags = (armed ? 1 : 0) | (failsafe ? 2 : 0) | (imuOk && !gyroCalibrating ? 4 : 0) |
              (gyroCalibrating ? 8 : 0) | (batteryMv > 1000 && batteryMv < 6400 ? 16 : 0);
  char out[160];
  snprintf(out, sizeof out, "TEL,%u,%u,%lu,%.1f,%.1f,%d,%d,%d,%d,%d,%d", (unsigned)++telemetrySeq,
           (unsigned)lastCmdSeq, (unsigned long)millis(), yaw, yawRate, (int)lroundf(speedLeft),
           (int)lroundf(speedRight), cmdGrip, (int)liftPosition, batteryMv, flags);
  sendFrame(port, out);
}

// ---------------------------------------------------------------- incoming frames
void handleCmd(const char* fields) {
  int seq, left, right, grip, lift, enable, heading, steer = 0;
  int n = sscanf(fields, "%d,%d,%d,%d,%d,%d,%d,%d", &seq, &left, &right, &grip, &lift, &enable, &heading, &steer);
  if (n < 6) return;
  lastCmdSeq = seq;
  cmdLeft = constrain(left, -100, 100);
  cmdRight = constrain(right, -100, 100);
  cmdGrip = constrain(grip, 0, 100);
  cmdLift = constrain(lift, -100, 100);
  armed = enable == 1;
  lastCmdMs = millis();
  if (n >= 7 && armed) {  // field 7: turn to this yaw (tenths of a degree)
    if (!turnActive) turnSinceMs = millis();
    turnActive = true;
    turnTarget = heading / 10.0f;
    steerWhileDriving = n == 8 && steer == 1;  // field 8: reach it while driving
  } else {
    turnActive = false;
    steerWhileDriving = false;
  }
}

// CFG,name,value: change a setting and keep it in flash.
void handleCfg(Port& port, const char* fields) {
  char name[8];
  float value;
  if (sscanf(fields, "%7[^,],%f", name, &value) != 2) return;
  for (auto& s : SETTINGS) {
    if (strcmp(name, s.name)) continue;
    if (!strcmp(name, "gsign")) {
      value = value < 0 ? -1 : 1;
      if (value != gsign) {  // the other gyro direction: mirror the angle so nothing jumps
        yaw = -yaw;
        holding = false;
      }
    }
    if (!strcmp(name, "bal")) balSavedInFlash = value;
    *s.value = value;
    flash.putFloat(s.name, value);
    char reply[32];
    snprintf(reply, sizeof reply, "ACK,CFG,%s", name);
    sendFrame(port, reply);
    sendControlState(port);
  }
}

void handleFrame(Port& port, char* line) {
  char* star = strrchr(line, '*');
  if (line[0] != '$' || !star) return;
  *star = 0;
  if ((uint8_t)strtol(star + 1, nullptr, 16) != checksum(line + 1)) return;  // damaged frame: ignore
  const char* body = line + 1;
  port.lastRxMs = millis() | 1;  // |1: never 0, which means "never heard"

  if (!strncmp(body, "CMD,", 4)) {
    handleCmd(body + 4);
  } else if (!strncmp(body, "PING,", 5)) {
    char reply[48];
    snprintf(reply, sizeof reply, "PONG,%s,%lu", body + 5, (unsigned long)millis());
    sendFrame(port, reply);
  } else if (!strncmp(body, "HELLO?", 6)) {
    char reply[72];
    snprintf(reply, sizeof reply, "HELLO,1,rec-robot,%s,%s", ROBOT_TYPE, FW_VERSION);
    sendFrame(port, reply);
    snprintf(reply, sizeof reply, "RST,%s,%lu", resetReasonText(), (unsigned long)(millis() / 1000));
    sendFrame(port, reply);
    sendControlState(port);
  } else if (!strncmp(body, "STOP", 4)) {
    disarm();
    sendFrame(port, "ACK,STOP");
  } else if (!strncmp(body, "ZERO", 4)) {
    yaw = 0;
    holding = false;
    sendFrame(port, "ACK,ZERO");
  } else if (!strncmp(body, "CAL", 3)) {
    stopWheels();
    startCalibration();
    sendFrame(port, "ACK,CAL");
  } else if (!strncmp(body, "CFG,", 4)) {
    handleCfg(port, body + 4);
  }
}

// Read everything waiting on a port and act on each complete line.
void readPort(Port& port) {
  while (port.stream->available()) {
    int c = port.stream->read();
    if (c < 0) break;
    if (c == '\n') {
      port.line[port.length] = 0;
      if (port.length) {
        if (port.line[0] == '$') {
          handleFrame(port, port.line);
        } else if (!strcmp(port.line, "status") && &port == &ports[PORT_USB]) {
          Serial.printf("[status] %s %s yaw %.1f gyro %s armed %d hold %d bal %.2f gsign %d bt %d restart %s\n",
                        FW_VERSION, ROBOT_TYPE, yaw, imuOk ? "ok" : "MISSING", armed, (int)hold, bal,
                        (int)gsign, (int)ble.connected, resetReasonText());
        } else {  // any other typed text: the LED lights for 2 s and the robot answers
          ledUntilMs = millis() + 2000;
          blinkCount = 3;
          sendFrame(port, "ACK,TEXT");
        }
      }
      port.length = 0;
    } else if (c != '\r') {
      if (port.length < sizeof port.line - 1) port.line[port.length++] = c;
      else port.length = 0;  // line too long: drop it
    }
  }
}
