// config.h - everything you may want to change, and the hardware pin numbers.
#pragma once

// ---------------------------------------------------------------- identity
const char* BT_NAME = "REC-Robot";    // Bluetooth name the dashboard scans for
const char* ROBOT_TYPE = "tower";     // "tower":  grip servo (18) + lift servo (19), the lift stick moves it like a speed
                                      // "simple": grip servo only (GPIO 18); the lift servo is NOT driven then
const char* FW_VERSION = "V_9_4";

// ---------------------------------------------------------------- pins
// L298N: ENA / ENB jumpers stay ON; speed is PWM on the IN pins.
const int IN1 = 26, IN2 = 27;         // left motor
const int IN3 = 32, IN4 = 33;         // right motor
const int SERVO1_PIN = 18;            // grip
const int SERVO2_PIN = 19;            // lift (tower only)
const int BATTERY_PIN = 34;           // battery divider (optional)
const int LED_PIN = 2;                // on-board LED
// MPU6050 gyro: SDA = GPIO 21, SCL = GPIO 22 (see gyro.h)

// ---------------------------------------------------------------- safety
const uint32_t FAILSAFE_MS = 400;     // no valid CMD for this long = the wheels stop

// ---------------------------------------------------------------- battery
// 0 = no divider fitted (battery shows 0). With a 100k / 47k divider on GPIO 34 use 147.0 / 47.0.
const float VBAT_RATIO = 0;

// ---------------------------------------------------------------- gyro
// First-run default; the dashboard button "Flip gyro direction" changes it and the choice is kept in flash.
// +1 = turning LEFT (counter-clockwise seen from above) raises the yaw angle.
const float GYRO_SIGN = 1.0f;
const float GYRO_DEADBAND = 0.15f;    // deg/s ignored while integrating the yaw angle

// ---------------------------------------------------------------- wheel ramp
// The wheel speed may change by at most this many percent per second (700 = about 0.15 s from stop
// to full). Stopping by failsafe is instant and does not use the ramp.
const float RAMP_UP = 700, RAMP_DOWN = 2000;

// ---------------------------------------------------------------- servos
const float SERVO_DPS = 300.0f;       // servos move at most this fast (degrees per second). A small step per update makes
                                      // a servo weak and slow (it only pushes in proportion to the gap), so this is high;
                                      // lower it if the servo supply dips and the servo stutters or the ESP32 resets.
// The last few degrees at each end are often the servo's mechanical stop: pushing there makes it hum and
// draw a lot of current. These are the limits used when none are saved, and when saved ones are unusable.
const int SERVO_SAFE_LOW = 10, SERVO_SAFE_HIGH = 170;
const int SERVO_MIN_SPAN = 10;        // limits closer together than this (degrees) are ignored
const float LIFT_RATE = 2.0f;         // tower: the lift stick (-100..100) times this is the lift speed in percent of its travel per second:
                                      // full stick = 200 % per second, about 0.5 s end to end (SERVO_DPS also limits it)
const int LIFT_MIN_DEG = 20, LIFT_MAX_DEG = 160;

// ---------------------------------------------------------------- gyro control limits
const float HOLD_MAX = 25;            // biggest straight-line correction, in percent of wheel speed
const float BAL_MAX = 25;             // biggest learned wheel balance, in percent
const float SNAP_MAX = 70;            // snap turn: fastest wheel speed (percent)
const float SNAP_MIN = 20;            // snap turn: below this the wheels do not even turn
const float SNAP_TOL = 1.5f;          // snap turn: this close (degrees) counts as arrived
const float SNAP_STILL = 12;          // ... and the turn rate must be below this (deg/s)
const uint32_t SNAP_TIMEOUT_MS = 3000;  // give up a snap turn after this long
const uint32_t HOLD_LATCH_MS = 300;   // heading is latched this long after the last turn settled
const float HOLD_LATCH_RATE = 20;     // ... and only when the turn rate is below this (deg/s)
const float STRAIGHT_MAX_DIFF = 3;    // wheels count as "the same speed" when commands differ by less (percent)
const float STRAIGHT_MIN_SPEED = 10;  // ... and the robot counts as driving above this (percent)

// ---------------------------------------------------------------- reports to the dashboard
const uint32_t HOLD_REPORT_MS = 100;       // gyro control report (HLD) period
const uint32_t HOLD_REPORT_FAST_MS = 50;   // ... while a heading target is active (auto-tune needs the detail)
