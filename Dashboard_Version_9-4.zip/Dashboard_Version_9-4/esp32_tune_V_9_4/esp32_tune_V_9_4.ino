// REC robot - TUNING firmware V_9_4 for Robot Station V 9.4 (the Tune page).
//
// Test the motors, the two servos, the MPU6050 gyro and the battery reading from the dashboard, and
// keep the values found (start power, wheel direction, servo limits, battery ratio) in flash.
// The full robot firmware (esp32_robot_V_9_4) reads the same values.
//
// Board "ESP32 Dev Module" (core 3.x), no extra library.
// Serial Monitor 115200 / Newline. Link: Bluetooth LE ("REC-Robot", no pairing) AND the USB cable.
//
// Files of this sketch (they are included below in this order):
//   config.h      names, pins, limits
//   pwm.h         PWM output
//   settings.h    the tuning values kept in flash
//   state.h       everything that changes while running
//   ble_stream.h  Bluetooth LE as a serial-like stream
//   outputs.h     wheels and servos
//   imu.h         MPU6050 and the yaw angle
//   protocol.h    the text protocol
//
// Safety: nothing moves until the dashboard arms the output. No command for 400 ms, or a lost link,
// stops the wheels.
//
// What changed in V_9_4 (servo trouble):
//   * Servo limits that cannot work (saved upside down, or almost equal, so the servo could not move)
//     are ignored and replaced by 10..170 degrees; the dashboard cannot save them either.
//   * Default limits are 10..170 instead of 0..180: the last degrees are often the servo's stop.
//   * Servos glide at 100 deg/s at most (was 150), a smaller current spike.
//
// NOT TESTED on the real robot: wheels in the air first.
#include <Wire.h>
#include <esp_system.h>
#include <Preferences.h>

#include "config.h"
#include "pwm.h"
#include "settings.h"
#include "state.h"
#include "ble_stream.h"
#include "outputs.h"
#include "imu.h"
#include "protocol.h"

void setup() {
  pinMode(LED_PIN, OUTPUT);
  for (int k = 0; k < 4; k++) {  // motors off
    pwmAttach(MOTOR_PIN[k], k, 4000, 8);
    pwmOut(MOTOR_PIN[k], k, 0);
  }
  for (int k = 0; k < 2; k++) {  // servos limp until told
    pwmAttach(SERVO_PIN[k], 4 + k, 50, 14);
    pwmOut(SERVO_PIN[k], 4 + k, 0);
  }
  Serial.begin(115200);
  analogReadResolution(12);
  analogSetPinAttenuation(BATTERY_PIN, ADC_11db);
  loadSettings();
  imuInit();
  startCalibration();
  bleBegin();
  Serial.printf("\nLast restart: %s.\n", resetReasonText());
  Serial.printf("\nREC tune firmware %s ready. BLE name '%s'. Gyro %s (id 0x%02X)\n", FW_VERSION, BT_NAME,
                imuOk ? "found" : "NOT found - check 3V3 SDA 21 SCL 22", whoAmI);
}

void loop() {
  uint32_t now = millis();
  pump(ports[0]);
  pump(ports[1]);

  bool failsafe = now - lastCmdMs > FAILSAFE_MS;
  bool live = armed && !failsafe;
  static uint32_t lastLoopMs;
  float dt = (now - lastLoopMs) * 1e-3f;
  lastLoopMs = now;

  if (!live) {
    if (wheelPercent[0] || wheelPercent[1]) stopAll();
  } else {
    drive(0, cmdLeft);
    drive(1, cmdRight);
    servoCommand(0, cmdServo1);
    servoCommand(1, cmdServo2);
  }
  servoStep(dt);
  updateImu(now);

  // Link change: never stay armed across it.
  static bool bleWasConnected;
  if (ble.connected != bleWasConnected) {
    bleWasConnected = ble.connected;
    if (bleWasConnected) {
      blinkCount = 5;
    } else {
      Serial.printf("[bt] disconnected, reason 0x%02X\n", bleDisconnectReason);
      if (ports[1].lastRxMs > ports[0].lastRxMs) disarm();
    }
  }

  // Telemetry: a frame that fits one notification can go 10 times a second; otherwise slower.
  ports[1].periodMs = ble.chunk >= 120 ? 100 : 250;
  Port* port = activePort();
  if (port && now - lastTelemetryMs >= port->periodMs) {
    lastTelemetryMs = now;
    sendTelemetry(*port);
  }

  // LED: on while talking, blinks on a new connection or typed text.
  static uint32_t blinkMs;
  static int blinkStep;
  if (blinkCount && now - blinkMs > 150) {
    blinkMs = now;
    blinkStep++;
    if (blinkStep >= blinkCount * 2) blinkCount = blinkStep = 0;
  }
  digitalWrite(LED_PIN, blinkCount ? blinkStep % 2 == 0 : ((int32_t)(ledUntilMs - now) > 0 || ble.connected));
}
