// imu.h - MPU6050 on I2C (SDA 21, SCL 22): acceleration, temperature and rotation rate, and the yaw
// angle integrated from the Z rate.
#pragma once
#include <Wire.h>

const uint8_t MPU_ADDRESS = 0x68;

uint8_t readRegister(uint8_t reg) {
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(reg);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_ADDRESS, (uint8_t)1);
  return Wire.read();
}

void imuInit() {
  Wire.begin(21, 22);
  Wire.setClock(400000);
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(0x6B);  // power management: wake up
  Wire.write(0);
  imuOk = Wire.endTransmission() == 0;
  whoAmI = imuOk ? readRegister(0x75) : 0;
}

// Read all 14 bytes: accel x y z, temperature, gyro x y z. False if the sensor did not answer.
bool readImu() {
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(0x3B);
  if (Wire.endTransmission(false) || Wire.requestFrom(MPU_ADDRESS, (uint8_t)14) != 14) return false;
  int16_t raw[7];
  for (auto& value : raw) {
    uint8_t high = Wire.read();
    uint8_t low = Wire.read();
    value = (high << 8) | low;
  }
  for (int i = 0; i < 3; i++) {
    imu[i] = raw[i] / 16384.0f;        // acceleration in g
    imu[4 + i] = raw[4 + i] / 131.0f;  // rotation in deg/s
  }
  imu[3] = raw[3] / 340.0f + 36.53f;  // temperature in C
  return true;
}

// Measure the zero-rate offset: the robot must stand still for one second.
void startCalibration() {
  calibrating = true;
  calSamples = 0;
  calSum = 0;
  calStartMs = millis();
}

// Call every loop: reads the sensor at 100 Hz and integrates the yaw angle.
void updateImu(uint32_t now) {
  if (!imuOk || now - lastImuMs < 10) return;
  float dt = (now - lastImuMs) * 1e-3f;
  lastImuMs = now;
  if (!readImu()) return;
  if (calibrating) {
    calSum += imu[6];
    calSamples++;
    if (now - calStartMs > 1000 && calSamples > 20) {
      gyroBias = calSum / calSamples;
      calibrating = false;
      yaw = 0;
    }
  } else {
    float rate = imu[6] - gyroBias;
    if (fabsf(rate) > 0.15f) yaw += rate * dt;
  }
}
