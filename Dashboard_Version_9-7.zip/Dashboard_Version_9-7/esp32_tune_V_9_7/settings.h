// settings.h - the tuning values. They are changed from the dashboard (TCFG,name,value) and kept
// in flash, in the namespace "tune" that the full robot firmware reads too.
#pragma once
#include <Preferences.h>

float minpwm = 0;                                   // lowest PWM that still turns a wheel
float invl = 0, invr = 0;                           // 1 = this wheel is wired the other way round
float lo1 = SERVO_SAFE_LOW, hi1 = SERVO_SAFE_HIGH;  // servo 1 limits, degrees
float lo2 = SERVO_SAFE_LOW, hi2 = SERVO_SAFE_HIGH;  // servo 2 limits, degrees
float ratio = DEFAULT_VBAT_RATIO;                   // battery divider ratio

// Name -> variable. The order is the order of the TCFG frame the dashboard expects.
struct TuneValue {
  const char* name;
  float* value;
};
TuneValue TUNE_VALUES[] = {
    {"minpwm", &minpwm}, {"invl", &invl}, {"invr", &invr}, {"lo1", &lo1},
    {"hi1", &hi1},       {"lo2", &lo2},   {"hi2", &hi2},   {"ratio", &ratio},
};

Preferences flash;

void loadSettings() {
  flash.begin("tune", false);
  for (auto& v : TUNE_VALUES) *v.value = flash.getFloat(v.name, *v.value);
}

// Change one value by name and keep it in flash. Returns false for an unknown name.
bool changeSetting(const char* name, float value) {
  for (auto& v : TUNE_VALUES) {
    if (strcmp(name, v.name) != 0) continue;
    *v.value = value;
    flash.putFloat(v.name, value);
    return true;
  }
  return false;
}
