// state.h - everything that changes while the firmware runs.
#pragma once

// One serial-like connection (USB or Bluetooth) with its line buffer.
struct Port {
  Stream* stream;
  uint32_t lastRxMs;  // when a valid frame last arrived (0 = never)
  char line[120];     // the line being received
  size_t length;      // characters in `line`
  uint32_t periodMs;  // time between telemetry frames on this port
};

// ---- what the dashboard asked for
bool armed = false;
int cmdLeft, cmdRight;               // wheels, -100..100 percent
int cmdServo1 = -2, cmdServo2 = -2;  // degrees; -1 = limp, -2 = keep
uint16_t lastSeq, telemetrySeq;
uint32_t lastCmdMs, lastTelemetryMs;

// ---- outputs
int wheelPercent[2], wheelPwm[2];  // what the wheels get now
int servoAngle[2] = {-1, -1};      // angle now (-1 = limp: no pulses)
int servoTarget[2] = {-1, -1};     // angle it is asked to go to
float servoPosition[2];            // angle on its way there

// ---- sensors
bool imuOk = false, calibrating = true;
uint8_t whoAmI;
float imu[7];  // ax ay az (g), temperature (C), gx gy gz (deg/s)
float gyroBias, yaw;
double calSum;
int calSamples;
uint32_t calStartMs, lastImuMs;

// ---- LED
uint32_t ledUntilMs;
int blinkCount;
