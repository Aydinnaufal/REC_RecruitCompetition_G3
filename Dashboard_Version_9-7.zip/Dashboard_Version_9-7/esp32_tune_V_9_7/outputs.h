// outputs.h - wheels and servos.
#pragma once

// ---------------------------------------------------------------- wheels
// Wheel `side` (0 = left, 1 = right) at `percent`. The driver is always enabled; the PWM goes on the
// IN pin of the direction wanted.
void drive(int side, int percent) {
  percent = constrain(percent, -100, 100);
  wheelPercent[side] = percent;
  int direction = (side ? invr : invl) > 0 ? -percent : percent;
  int pwm = percent ? map(abs(percent), 1, 100, (int)minpwm, 255) : 0;
  wheelPwm[side] = direction < 0 ? -pwm : pwm;
  pwmOut(MOTOR_PIN[side * 2], side * 2, direction > 0 ? pwm : 0);
  pwmOut(MOTOR_PIN[side * 2 + 1], side * 2 + 1, direction < 0 ? pwm : 0);
}

void stopAll() {
  drive(0, 0);
  drive(1, 0);
}

void disarm() {
  armed = false;
  cmdLeft = cmdRight = 0;
  stopAll();
}

// ---------------------------------------------------------------- servos
// 0..180 degrees = 0.5..2.4 ms pulse in a 20 ms frame, 14-bit duty.
void servoPulse(int i, int degrees) {
  pwmOut(SERVO_PIN[i], 4 + i, (uint32_t)(500 + 1900L * degrees / 180) * 16384UL / 20000UL);
}

// The limits servo i really uses. Saved limits that cannot work (outside 0..180, upside down, or
// almost the same number: the servo could not move at all) are replaced by the safe ones.
void servoLimits(int i, int* low, int* high) {
  int a = constrain((int)(i ? lo2 : lo1), 0, 180);
  int b = constrain((int)(i ? hi2 : hi1), 0, 180);
  if (a > b) {
    int t = a;
    a = b;
    b = t;
  }
  if (b - a < SERVO_MIN_SPAN) {
    a = SERVO_SAFE_LOW;
    b = SERVO_SAFE_HIGH;
  }
  *low = a;
  *high = b;
}

// Servo i: -1 = limp (no pulses), -2 = keep as it is, otherwise an angle that is kept inside the
// limits and reached at SERVO_DPS.
void servoCommand(int i, int degrees) {
  if (degrees == -2) return;
  if (degrees < 0) {
    if (servoAngle[i] >= 0) pwmOut(SERVO_PIN[i], 4 + i, 0);
    servoAngle[i] = servoTarget[i] = -1;
    return;
  }
  int low, high;
  servoLimits(i, &low, &high);
  servoTarget[i] = constrain(degrees, low, high);
  if (servoAngle[i] < 0) {  // first command after limp: the real position is unknown, start there
    servoPosition[i] = servoTarget[i];
    servoAngle[i] = servoTarget[i];
    servoPulse(i, servoAngle[i]);
  }
}

// Glide the servos toward their targets. Call every loop.
void servoStep(float dt) {
  for (int i = 0; i < 2; i++) {
    if (servoAngle[i] < 0 || servoTarget[i] < 0 || servoPosition[i] == servoTarget[i]) continue;
    float diff = servoTarget[i] - servoPosition[i], most = SERVO_DPS * dt;
    servoPosition[i] += diff > most ? most : diff < -most ? -most : diff;
    int angle = (int)(servoPosition[i] + 0.5f);
    if (angle != servoAngle[i]) {
      servoAngle[i] = angle;
      servoPulse(i, angle);
    }
  }
}
