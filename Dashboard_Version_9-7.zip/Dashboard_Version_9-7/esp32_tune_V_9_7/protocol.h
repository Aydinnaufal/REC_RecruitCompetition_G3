// protocol.h - the text protocol ($TYPE,field,field*HH, HH = XOR of the characters in hex).
//
// Dashboard -> robot
//   CMD,seq,left,right,servo1,servo2,enable   wheels in percent, servos in degrees (-1 limp, -2 keep)
//   TCFG,name,value                           change a tuning value (kept in flash)
//   PING,n   HELLO?   STOP   CAL
// Robot -> dashboard
//   HELLO,proto,fw,robot,version   RST,reason,seconds   PONG,n,ms   ACK,...
//   TCFG,minpwm,invl,invr,lo1,hi1,lo2,hi2,ratio     all tuning values
//   TUN,seq,ack,ms,pwmL,pwmR,s1,s2,gx,gy,gz,ax,ay,az,temp,yaw,vbat_mv,flags,whoami
#pragma once

uint8_t checksum(const char* text) {
  uint8_t c = 0;
  while (*text) c ^= (uint8_t)*text++;
  return c;
}

void sendFrame(Port& port, const char* body) {
  char out[220];
  int n = snprintf(out, sizeof out, "$%s*%02X\n", body, checksum(body));
  if (n > 0 && n < (int)sizeof out) port.stream->write((const uint8_t*)out, n);
}

// A port is usable when it spoke in the last 3 s (and, for Bluetooth, is still connected).
bool portUsable(Port& port, Port& bluetoothPort) {
  return port.lastRxMs && millis() - port.lastRxMs < 3000 && (&port != &bluetoothPort || ble.connected);
}

Port ports[2] = {{&Serial, 0, {0}, 0, 50}, {&ble, 0, {0}, 0, 100}};

// The port that spoke last, or null.
Port* activePort() {
  Port* best = nullptr;
  for (auto& port : ports) {
    if (portUsable(port, ports[1]) && (!best || (int32_t)(port.lastRxMs - best->lastRxMs) > 0)) best = &port;
  }
  return best;
}

// Why the ESP32 last started. BROWNOUT = the supply dipped (battery missing, or a servo spike).
const char* resetReasonText() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON:
      return "poweron";
    case ESP_RST_SW:
      return "software";
    case ESP_RST_BROWNOUT:
      return "BROWNOUT";
    case ESP_RST_PANIC:
      return "CRASH";
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:
      return "watchdog";
    default:
      return "other";
  }
}

void sendTuningValues(Port& port) {
  char out[120];
  snprintf(out, sizeof out, "TCFG,%g,%g,%g,%g,%g,%g,%g,%g", minpwm, invl, invr, lo1, hi1, lo2, hi2, ratio);
  sendFrame(port, out);
}

// Reject a value that would make a servo unable to move (or move past its ends): the saved limits are
// kept and the dashboard is told what is in the robot.
bool servoLimitAllowed(const char* name, float value) {
  if (name[0] != 'l' && name[0] != 'h') return true;  // not lo1 hi1 lo2 hi2
  if (name[1] != 'o' && name[1] != 'i') return true;
  if (value < 0 || value > 180) return false;
  bool second = name[2] == '2';
  float otherLow = second ? lo2 : lo1, otherHigh = second ? hi2 : hi1;
  if (name[0] == 'l') return value <= otherHigh - SERVO_MIN_SPAN;
  return value >= otherLow + SERVO_MIN_SPAN;
}

void handleFrame(Port& port, char* line) {
  char* star = strrchr(line, '*');
  if (line[0] != '$' || !star) return;
  *star = 0;
  if ((uint8_t)strtol(star + 1, nullptr, 16) != checksum(line + 1)) return;
  char* body = line + 1;
  port.lastRxMs = millis() | 1;

  if (!strncmp(body, "CMD,", 4)) {
    int seq, left, right, servo1, servo2, enable;
    if (sscanf(body + 4, "%d,%d,%d,%d,%d,%d", &seq, &left, &right, &servo1, &servo2, &enable) == 6) {
      lastSeq = seq;
      cmdLeft = constrain(left, -100, 100);
      cmdRight = constrain(right, -100, 100);
      cmdServo1 = servo1;
      cmdServo2 = servo2;
      armed = enable == 1;
      lastCmdMs = millis();
    }
  } else if (!strncmp(body, "PING,", 5)) {
    char out[48];
    snprintf(out, sizeof out, "PONG,%s,%lu", body + 5, (unsigned long)millis());
    sendFrame(port, out);
  } else if (!strncmp(body, "HELLO?", 6)) {
    char out[64];
    snprintf(out, sizeof out, "HELLO,1,rec-tune,tune,%s", FW_VERSION);
    sendFrame(port, out);
    sendTuningValues(port);
    snprintf(out, sizeof out, "RST,%s,%lu", resetReasonText(), (unsigned long)(millis() / 1000));
    sendFrame(port, out);
  } else if (!strncmp(body, "STOP", 4)) {
    disarm();
    sendFrame(port, "ACK,STOP");
  } else if (!strncmp(body, "CAL", 3)) {
    stopAll();
    startCalibration();
    sendFrame(port, "ACK,CAL");
  } else if (!strncmp(body, "TCFG,", 5)) {
    char name[8];
    float value;
    if (sscanf(body + 5, "%7[^,],%f", name, &value) == 2 && servoLimitAllowed(name, value))
      changeSetting(name, value);
    sendTuningValues(port);  // always answer: the dashboard shows what the robot really holds
  }
}

// Collect characters into lines and hand complete ones on.
void pump(Port& port) {
  while (port.stream->available()) {
    int c = port.stream->read();
    if (c < 0) break;
    if (c == '\n') {
      port.line[port.length] = 0;
      if (port.length) {
        if (port.line[0] == '$') {
          handleFrame(port, port.line);
        } else {  // typed text: the LED lights for 2 s and the robot answers
          ledUntilMs = millis() + 2000;
          blinkCount = 3;
          sendFrame(port, "ACK,TEXT");
        }
      }
      port.length = 0;
    } else if (c != '\r') {
      if (port.length < sizeof port.line - 1)
        port.line[port.length++] = c;
      else
        port.length = 0;
    }
  }
}

void sendTelemetry(Port& port) {
  uint32_t millivolts = 0;
  for (int i = 0; i < 8; i++) millivolts += analogReadMilliVolts(BATTERY_PIN);
  int batteryMv = (int)(millivolts / 8 * ratio);
  bool failsafe = millis() - lastCmdMs > FAILSAFE_MS;
  int flags = (armed ? 1 : 0) | (failsafe ? 2 : 0) | (imuOk && !calibrating ? 4 : 0) | (calibrating ? 8 : 0) |
              (batteryMv > 1000 && batteryMv < 6400 ? 16 : 0);
  char out[200];
  snprintf(out, sizeof out, "TUN,%u,%u,%lu,%d,%d,%d,%d,%.1f,%.1f,%.1f,%.2f,%.2f,%.2f,%.1f,%.1f,%d,%d,%d",
           (unsigned)++telemetrySeq, (unsigned)lastSeq, (unsigned long)millis(), wheelPwm[0], wheelPwm[1],
           servoAngle[0], servoAngle[1], imu[4], imu[5], imu[6] - gyroBias, imu[0], imu[1], imu[2], imu[3],
           yaw, batteryMv, flags, whoAmI);
  sendFrame(port, out);
}
