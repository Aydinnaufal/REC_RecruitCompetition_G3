// ble_stream.h - Bluetooth LE as a serial-like Stream (Nordic UART service), so the rest of the
// firmware reads and writes the same way over USB and Bluetooth.
#pragma once
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define NUS_SERVICE_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define NUS_RX_UUID "6e400002-b5a3-f393-e0a9-e50e24dcca9e"  // laptop -> robot
#define NUS_TX_UUID "6e400003-b5a3-f393-e0a9-e50e24dcca9e"  // robot -> laptop (notifications)

const int BLE_RX_SIZE = 512;  // power of two: the ring buffer wraps with a mask

class BleStream : public Stream {
 public:
  uint8_t rx[BLE_RX_SIZE];
  volatile uint16_t head = 0, tail = 0;
  volatile bool connected = false;
  volatile int chunk = 20;  // bytes per notification (MTU - 3)
  BLECharacteristic* tx = nullptr;

  int available() override { return (head - tail) & (BLE_RX_SIZE - 1); }
  int read() override {
    if (head == tail) return -1;
    uint8_t c = rx[tail];
    tail = (tail + 1) & (BLE_RX_SIZE - 1);
    return c;
  }
  int peek() override { return head == tail ? -1 : rx[tail]; }
  void flush() override {}
  size_t write(uint8_t b) override { return write(&b, 1); }
  size_t write(const uint8_t* data, size_t n) override {
    if (!connected || !tx) return 0;
    for (size_t i = 0; i < n; i += chunk) {
      size_t m = n - i < (size_t)chunk ? n - i : chunk;
      tx->setValue((uint8_t*)data + i, m);
      tx->notify();
      if (n > (size_t)chunk) delay(3);  // a frame that needs several notifications: give the stack time
    }
    return n;
  }
  void push(uint8_t c) {  // called from the Bluetooth callback
    uint16_t next = (head + 1) & (BLE_RX_SIZE - 1);
    if (next != tail) {
      rx[head] = c;
      head = next;
    }
  }
} ble;

volatile int bleDisconnectReason = -1;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*) override {
    ble.chunk = 20;
    ble.connected = true;
  }
  void onMtuChanged(BLEServer*, esp_ble_gatts_cb_param_t* p) override {
    ble.chunk = constrain((int)p->mtu.mtu - 3, 20, 180);
  }
  void onDisconnect(BLEServer*, esp_ble_gatts_cb_param_t* p) override {
    bleDisconnectReason = p->disconnect.reason;
    ble.connected = false;
    ble.chunk = 20;
    esp_ble_remove_bond_device(p->disconnect.remote_bda);  // no bonding: a stale one drops the link
    BLEDevice::startAdvertising();
  }
};

class RxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) override {
    auto value = c->getValue();
    for (size_t i = 0; i < value.length(); i++) ble.push((uint8_t)value[i]);
  }
};

// Forget old pairings: a stale one makes the link drop after one second.
void forgetBondedDevices() {
  int n = esp_ble_get_bond_device_num();
  if (n <= 0) return;
  auto* list = (esp_ble_bond_dev_t*)malloc(n * sizeof(esp_ble_bond_dev_t));
  if (list && esp_ble_get_bond_device_list(&n, list) == ESP_OK) {
    for (int i = 0; i < n; i++) esp_ble_remove_bond_device(list[i].bd_addr);
  }
  free(list);
}

void bleBegin() {
  BLEDevice::init(BT_NAME);
  BLEDevice::setMTU(185);
  BLESecurity* security = new BLESecurity();
  security->setAuthenticationMode(ESP_LE_AUTH_NO_BOND);
  security->setCapability(ESP_IO_CAP_NONE);
  forgetBondedDevices();

  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService* service = server->createService(NUS_SERVICE_UUID);
  ble.tx = service->createCharacteristic(NUS_TX_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  ble.tx->addDescriptor(new BLE2902());
  service->createCharacteristic(NUS_RX_UUID,
                                BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR)
      ->setCallbacks(new RxCallbacks());
  service->start();

  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(NUS_SERVICE_UUID);
  advertising->setScanResponse(true);
  BLEDevice::startAdvertising();
}
