// settings.h - values that are kept in flash and can be changed from the dashboard with CFG,name,value.
//
// The first ten have the same names and flash namespace ("tune") as the tuning firmware, so
// whatever was tuned there is used here. The rest are new.
#pragma once
#include <Preferences.h>

// ---- shared with the tuning firmware
float minpwm = 0;          // lowest PWM that still turns a wheel (the per-wheel ml / mr start from it)
float invl = 0, invr = 0;  // 1 = this wheel is wired the other way round
float lo1 = SERVO_SAFE_LOW, hi1 = SERVO_SAFE_HIGH;  // servo 1 (grip) limits in degrees
float lo2 = SERVO_SAFE_LOW, hi2 = SERVO_SAFE_HIGH;  // servo 2 (lift) limits
float go = 90, gc = 30;    // grip servo angle when open / closed
float hold = 1;            // 1 = keep a straight line with the gyro

// ---- straight-line hold: PID on the heading error
float kp = 1.2f;   // hold strength
float ki = 1.0f;   // hold learning: how fast the wheel balance is learned
float kd = 0.15f;  // hold damping (uses the turn rate)

// ---- wheel corrections
float gl = 1, gr = 1;   // wheel gain: one wheel is a bit stronger or weaker
float ml = 0, mr = 0;   // start PWM per wheel
float bal = 0;          // learned balance: how much more the weaker wheel needs, in percent
float gsign = GYRO_SIGN;  // gyro direction, +1 or -1
float gscale = 1.0f;      // gyro scale: the measured angle is multiplied by this (a turn that reads 90 but really is 92 needs 1.022)

// ---- snap turn: PD on the heading error
float skp = 1.4f;  // turn strength
float skd = 0.2f;  // turn damping

// Name -> variable table used by CFG and when loading from flash.
struct Setting {
  const char* name;
  float* value;
};
Setting SETTINGS[] = {
    {"minpwm", &minpwm}, {"invl", &invl}, {"invr", &invr}, {"lo1", &lo1}, {"hi1", &hi1},
    {"lo2", &lo2},       {"hi2", &hi2},   {"go", &go},     {"gc", &gc},   {"hold", &hold},
    {"kp", &kp},         {"ki", &ki},     {"kd", &kd},     {"gl", &gl},   {"gr", &gr},
    {"ml", &ml},         {"mr", &mr},     {"bal", &bal},   {"gsign", &gsign}, {"gscale", &gscale},
    {"skp", &skp},       {"skd", &skd},
};

Preferences flash;
float balSavedInFlash;  // the balance last written to flash (it is rewritten only when it changed)

void loadSettings() {
  flash.begin("tune", false);
  for (auto& s : SETTINGS) *s.value = flash.getFloat(s.name, *s.value);
  // The per-wheel start PWM begins as the value found on the dashboard's Tune page.
  if (!flash.isKey("ml")) ml = minpwm;
  if (!flash.isKey("mr")) mr = minpwm;
  balSavedInFlash = bal;
}
