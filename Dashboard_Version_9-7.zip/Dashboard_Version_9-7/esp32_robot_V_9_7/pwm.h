// pwm.h - PWM output through the ESP32 LEDC peripheral (works on core 2.x and 3.x).
//
// Every output has its own LEDC channel:  motors = channels 0-3 at 4 kHz, servos = channels 4-5 at 50 Hz.
#pragma once

const int MOTOR_PIN[4] = {IN1, IN2, IN3, IN4};
const int SERVO_PIN[2] = {SERVO1_PIN, SERVO2_PIN};

#if ESP_ARDUINO_VERSION_MAJOR >= 3
void pwmAttach(int pin, int channel, int hz, int bits) { ledcAttachChannel(pin, hz, bits, channel); }
void pwmOut(int pin, int channel, uint32_t duty) { ledcWrite(pin, duty); }
#else
void pwmAttach(int pin, int channel, int hz, int bits) {
  ledcSetup(channel, hz, bits);
  ledcAttachPin(pin, channel);
}
void pwmOut(int pin, int channel, uint32_t duty) { ledcWrite(channel, duty); }
#endif
