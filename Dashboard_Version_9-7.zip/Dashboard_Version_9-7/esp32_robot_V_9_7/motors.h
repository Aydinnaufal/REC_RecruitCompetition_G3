// motors.h - wheels, servos and the speed ramp.
#pragma once

// One wheel. side: 0 = left, 1 = right. percent: -100..100.
void setWheel(int side, float percent) {
  // gl / gr: this wheel is a bit stronger or weaker than the other.
  int pc = constrain((int)lroundf(percent * (side ? gr : gl)), -100, 100);
  // invl / invr: the motor is wired the other way round.
  int signedPercent = (side ? invr : invl) > 0 ? -pc : pc;
  // ml / mr: the lowest PWM that still turns this wheel; 1 % maps to it, 100 % to full power.
  int pwm = pc ? map(abs(pc), 1, 100, (int)(side ? mr : ml), 255) : 0;
  pwmOut(MOTOR_PIN[side * 2], side * 2, signedPercent > 0 ? pwm : 0);
  pwmOut(MOTOR_PIN[side * 2 + 1], side * 2 + 1, signedPercent < 0 ? pwm : 0);
}

void stopWheels() {
  speedLeft = speedRight = 0;
  setWheel(0, 0);
  setWheel(1, 0);
  holding = false;
  correction = headingError = 0;
}

void disarm() {
  armed = false;
  cmdLeft = cmdRight = 0;
  turnActive = false;
  stopWheels();
}

// Move `current` toward `wanted` by at most RAMP_UP / RAMP_DOWN percent per second.
float ramp(float current, float wanted, float dt) {
  float diff = wanted - current;
  float limit = (fabsf(wanted) > fabsf(current) ? RAMP_UP : RAMP_DOWN) * dt;
  if (diff > limit) return current + limit;
  if (diff < -limit) return current - limit;
  return wanted;
}

// ---------------------------------------------------------------- servos
// 0..180 degrees = 0.5..2.4 ms pulse in a 20 ms frame, 14-bit duty.
void servoPulse(int i, int degrees) {
  pwmOut(SERVO_PIN[i], 4 + i, (uint32_t)(500 + 1900L * degrees / 180) * 16384UL / 20000UL);
}

// The limits servo i really uses. Saved limits that cannot work (outside 0..180, upside down, or
// almost the same number: the servo could not move at all) are replaced by the safe ones.
void servoLimits(int i, int* low, int* high) {
  int a = constrain((int)(i ? lo2 : lo1), 0, 180);
  int b = constrain((int)(i ? hi2 : hi1), 0, 180);
  if (a > b) {
    int t = a;
    a = b;
    b = t;
  }
  if (b - a < SERVO_MIN_SPAN) {
    a = SERVO_SAFE_LOW;
    b = SERVO_SAFE_HIGH;
  }
  *low = a;
  *high = b;
}

// Ask servo i to go to an angle (kept inside its limits; reached at SERVO_DPS).
void servoGoto(int i, int degrees) {
  int low, high;
  servoLimits(i, &low, &high);
  servoTarget[i] = constrain(degrees, low, high);
  if (servoAngle[i] < 0) {  // first command after power-up: the real position is unknown, start there
    servoPosition[i] = servoTarget[i];
    servoAngle[i] = servoTarget[i];
    servoPulse(i, servoAngle[i]);
  }
}

// Move the servos toward their targets, SERVO_DPS at most.
void servoStep(float dt) {
  for (int i = 0; i < 2; i++) {
    if (servoAngle[i] < 0 || servoPosition[i] == servoTarget[i]) continue;
    float diff = servoTarget[i] - servoPosition[i], most = SERVO_DPS * dt;
    servoPosition[i] += diff > most ? most : diff < -most ? -most : diff;
    int angle = (int)(servoPosition[i] + 0.5f);
    if (angle != servoAngle[i]) {
      servoAngle[i] = angle;
      servoPulse(i, angle);
    }
  }
}
