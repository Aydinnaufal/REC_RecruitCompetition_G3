// REC robot - FULL ROBOT firmware V_9_7 for Robot Station V 9.7.
//
// Xbox controller -> dashboard -> this board: wheels, grip / lift servos, gyro feedback, gyro PID,
// snap turns and the steering used by auto-tune.
//
// Board "ESP32 Dev Module" (core 3.x), no extra library.
// Serial Monitor 115200 / Newline. Link: Bluetooth LE ("REC-Robot", no pairing) AND the USB cable.
//
// Files of this sketch (they are included below in this order):
//   config.h      settings you may change, pins, limits
//   pwm.h         PWM output
//   settings.h    values kept in flash, changeable from the dashboard
//   state.h       everything that changes while running
//   ble_stream.h  Bluetooth LE as a serial-like stream
//   motors.h      wheels, servos, speed ramp
//   gyro.h        MPU6050 and calibration
//   protocol.h    the text protocol: frames, reports, commands
//   control.h     the gyro control (snap turn, straight hold, steering)
//
// Safety: nothing moves until the dashboard arms the output. No command for 400 ms, or a lost link,
// stops the wheels.
// Tuning from the Tune page (min PWM, wheel invert, servo limits) is kept in flash by the tuning
// firmware and read here: flash that one first, tune, then flash this one.
//
// NOT TESTED on the real robot: wheels in the air first, then on the floor at a low speed.
#include <Wire.h>
#include <esp_system.h>
#include <Preferences.h>

#include "config.h"
#include "pwm.h"
#include "settings.h"
#include "state.h"
#include "ble_stream.h"
#include "motors.h"
#include "gyro.h"
#include "protocol.h"
#include "control.h"

// ---------------------------------------------------------------- setup
void setup() {
  pinMode(LED_PIN, OUTPUT);
  isTower = !strcmp(ROBOT_TYPE, "tower");

  for (int k = 0; k < 4; k++) {  // motors off
    pwmAttach(MOTOR_PIN[k], k, 4000, 8);
    pwmOut(MOTOR_PIN[k], k, 0);
  }
  for (int k = 0; k < 2; k++) {  // servos limp until the first armed command
    pwmAttach(SERVO_PIN[k], 4 + k, 50, 14);
    pwmOut(SERVO_PIN[k], 4 + k, 0);
  }

  Serial.begin(115200);
  analogReadResolution(12);
  analogSetPinAttenuation(BATTERY_PIN, ADC_11db);

  loadSettings();
  gyroInit();
  startCalibration();
  bleBegin();

  Serial.printf("\nLast restart: %s.\nREC robot firmware %s (%s) ready. BLE name '%s'. Gyro %s. "
                "Keep the robot still for 1 s: gyro calibration.\n",
                resetReasonText(), FW_VERSION, ROBOT_TYPE, BT_NAME,
                imuOk ? "found" : "NOT found - check 3V3 SDA 21 SCL 22");
}

// ---------------------------------------------------------------- loop pieces
// Armed and the dashboard is talking: drive. Otherwise the wheels stop at once and the servos hold.
void updateOutputs(float dt, bool live) {
  if (!live) {
    controlMode = hold > 0 && imuOk && !gyroCalibrating ? 1 : 0;
    if (speedLeft != 0 || speedRight != 0 || holding) stopWheels();
    return;
  }
  drive(dt);
  servoGoto(0, (int)map(cmdGrip, 0, 100, (int)go, (int)gc));
  if (isTower) {
    liftPosition = constrain(liftPosition + cmdLift * LIFT_RATE * dt, 0.0f, 100.0f);
    servoGoto(1, (int)map((int)liftPosition, 0, 100, LIFT_MIN_DEG, LIFT_MAX_DEG));
  }
}

// A Bluetooth link change: never stay armed across it.
void watchBluetoothLink() {
  static bool wasConnected;
  if (ble.connected == wasConnected) return;
  wasConnected = ble.connected;
  if (wasConnected) {
    blinkCount = 5;
  } else {
    Serial.printf("[bt] disconnected, reason 0x%02X\n", bleDisconnectReason);
    if (ports[PORT_BLE].lastRxMs > ports[PORT_USB].lastRxMs) disarm();
  }
}

// The learned balance is written to flash when the robot stands still.
void saveBalanceIfStill() {
  if (speedLeft == 0 && speedRight == 0 && fabsf(bal - balSavedInFlash) > 0.3f) {
    flash.putFloat("bal", bal);
    balSavedInFlash = bal;
  }
}

void sendReports(uint32_t now) {
  Port* port = activePort();
  if (!port) return;
  if (now - lastTelemetryMs >= port->telemetryPeriodMs) {
    lastTelemetryMs = now;
    sendTelemetry(*port);
  }
  uint32_t holdPeriod = turnActive ? HOLD_REPORT_FAST_MS : HOLD_REPORT_MS;
  if (now - lastHoldReportMs >= holdPeriod) {
    lastHoldReportMs = now;
    sendControlState(*port);
  }
}

// LED: on while connected; fast blink = armed but no commands; a few blinks for events.
void updateLed(uint32_t now, bool failsafe) {
  static uint32_t lastStepMs;
  static int step;
  if (blinkCount && now - lastStepMs > 150) {
    lastStepMs = now;
    step++;
    if (step >= blinkCount * 2) blinkCount = step = 0;
  }
  bool on;
  if (blinkCount) on = step % 2 == 0;
  else if (armed && failsafe) on = (now / 100) % 2;
  else on = (int32_t)(ledUntilMs - now) > 0 || ble.connected;
  digitalWrite(LED_PIN, on);
}

// ---------------------------------------------------------------- loop
void loop() {
  static uint32_t lastLoopMs;
  uint32_t now = millis();
  float dt = (now - lastLoopMs) * 1e-3f;
  lastLoopMs = now;

  readPort(ports[PORT_USB]);
  readPort(ports[PORT_BLE]);

  bool failsafe = now - lastCmdMs > FAILSAFE_MS;
  bool live = armed && !failsafe;

  updateGyro(now);
  updateOutputs(dt, live);
  servoStep(dt);
  watchBluetoothLink();
  ports[PORT_BLE].telemetryPeriodMs = ble.chunk >= 120 ? 100 : 250;  // a frame fits one notification: 10 per second; otherwise slower
  saveBalanceIfStill();
  sendReports(now);
  updateLed(now, failsafe);
}
