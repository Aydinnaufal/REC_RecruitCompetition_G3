// nano_hc05_setup_V_9_7 - sets up the HC-05 Bluetooth module once (name, 115200 baud). Run it, do the setup, then
// upload nano_robot_V_9_7 or nano_tune_V_9_7 again.
//
// This sketch passes everything between the USB cable (Serial Monitor) and the HC-05 on D8 / D7, so the HC-05
// does not use D0 / D1 here, and you can type AT commands to it.
//
// Wiring for the setup (move the HC-05 off D0 / D1 and wire it like this):
//     HC-05 TXD -> Nano D8        (the Nano reads it)
//     HC-05 RXD -> Nano D7        THROUGH A DIVIDER: the HC-05 RXD pin is 3.3 V. D7 --1k-- RXD --2k-- GND
//     HC-05 VCC -> Nano 5V,  GND -> GND
//     HC-05 KEY / EN pin (pin 34, the small one) -> 3.3 V or 5 V BEFORE it is powered, to start in AT mode
//        (the LED then blinks slowly: about 2 s on / 2 s off). AT mode talks at 38400 baud.
//
// Serial Monitor: 115200 baud, line ending "Both NL & CR". Type these one by one; each answers OK:
//     AT                      -> OK
//     AT+NAME=REC-Robot       -> the name that shows in the Windows Bluetooth list
//     AT+ROLE=0               -> slave: the PC connects to the robot
//     AT+UART=115200,0,0      -> the speed the dashboard uses (1 stop bit, no parity)
//     AT+PSWD="1234"          -> pairing code (older modules: AT+PSWD=1234)
//     AT+CMODE=1              -> accept any device
//     AT+RESET
// Then move the HC-05 back to D0 (its TXD) and D1 (its RXD, through the divider), remove the KEY wire, upload the robot sketch.
#include <Arduino.h>
#include <SoftwareSerial.h>

SoftwareSerial hc05(8, 7);  // RX = D8, TX = D7

void setup() {
  Serial.begin(115200);
  hc05.begin(38400);  // the HC-05 answers AT commands at 38400
  Serial.println(F("HC-05 AT setup. Type AT and press Enter. (38400 baud to the module)"));
}

void loop() {
  if (hc05.available()) Serial.write(hc05.read());
  if (Serial.available()) hc05.write(Serial.read());
}
