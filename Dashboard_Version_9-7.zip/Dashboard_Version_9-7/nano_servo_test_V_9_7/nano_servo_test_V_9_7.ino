// nano_servo_test_V_9_7 - checks ONE servo with nothing else running: no Bluetooth, no gyro, no wheels, no dashboard.
// If the servo works here, the wiring and the servo are fine and the problem is in the robot firmware.
// If it does not work here, the problem is the wiring, the power or the servo itself.
//
// Board "Arduino Nano". Open the Serial Monitor at 115200 baud, line ending "Newline" (USB cable; HC-05 unplugged from D0 / D1).
//
// Wiring: servo signal (orange / yellow / white) -> D6 (change SERVO_PIN to 9 for the lift servo).
//         servo + (red)   -> its own 5 V supply (not the Nano's 5 V pin: a servo draws up to 1 A)
//         servo - (brown) -> the supply's ground AND a Nano GND pin. THE GROUNDS MUST BE JOINED:
//                            without it the signal has no reference and the servo twitches or ignores it.
//
// Commands (type, then Enter):
//   1500   hold that pulse width in microseconds (500..2500). 1500 is the middle.
//   s      sweep slowly between 1000 and 2000 microseconds (the range every servo accepts)
//   w      sweep slowly between 600 and 2400 microseconds (the wide range the robot firmware uses)
//   x      stop sending pulses (the servo goes limp)
#include <Arduino.h>
#include <Servo.h>

const uint8_t SERVO_PIN = 6;  // 6 = grip servo, 9 = lift servo

Servo servo;
enum Mode { HOLD, SWEEP, LIMP } mode = LIMP;
int sweepLow, sweepHigh, sweepNow, sweepStep = 5;
char line[16];
uint8_t length = 0;

void pulse(int microseconds) {
  if (!servo.attached()) servo.attach(SERVO_PIN, 500, 2500);
  servo.writeMicroseconds(microseconds);
}

void handleLine() {
  line[length] = 0;
  length = 0;
  if (line[0] == 's' || line[0] == 'w') {
    sweepLow = line[0] == 's' ? 1000 : 600;
    sweepHigh = line[0] == 's' ? 2000 : 2400;
    sweepNow = (sweepLow + sweepHigh) / 2;
    sweepStep = 5;
    mode = SWEEP;
    Serial.print(F("sweeping "));
    Serial.print(sweepLow);
    Serial.print(F(".."));
    Serial.print(sweepHigh);
    Serial.println(F(" us"));
  } else if (line[0] == 'x') {
    mode = LIMP;
    servo.detach();
    Serial.println(F("limp (no pulses)"));
  } else if (line[0] >= '0' && line[0] <= '9') {
    int us = constrain(atoi(line), 500, 2500);
    mode = HOLD;
    pulse(us);
    Serial.print(F("holding "));
    Serial.print(us);
    Serial.println(F(" us"));
  }
}

void setup() {
  Serial.begin(115200);
  Serial.print(F("\nServo test on pin D"));
  Serial.print(SERVO_PIN);
  Serial.println(F(". Type 1500, s, w or x."));
}

void loop() {
  while (Serial.available()) {
    int c = Serial.read();
    if (c == '\n') {
      if (length) handleLine();
    } else if (c != '\r' && length < sizeof line - 1) {
      line[length++] = c;
    }
  }
  static uint32_t lastMs;
  if (mode == SWEEP && millis() - lastMs >= 20) {
    lastMs = millis();
    sweepNow += sweepStep;
    if (sweepNow >= sweepHigh || sweepNow <= sweepLow) sweepStep = -sweepStep;
    pulse(sweepNow);
  }
}
