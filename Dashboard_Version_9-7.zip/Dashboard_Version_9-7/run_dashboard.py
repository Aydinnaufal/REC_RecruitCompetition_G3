"""Start the Robot Station dashboard:  python run_dashboard.py"""

from robot_station.main import main

if __name__ == '__main__':
    main()
