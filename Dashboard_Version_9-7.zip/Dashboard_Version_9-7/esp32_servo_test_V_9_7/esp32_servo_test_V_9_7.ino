// esp32_servo_test_V_9_7 - checks ONE servo with nothing else running: no Bluetooth, no gyro, no wheels,
// no dashboard. If the servo works here, the wiring and the servo are fine and the problem is in the robot
// firmware. If it does not work here, the problem is the wiring, the power or the servo itself.
//
// Board "ESP32 Dev Module". Open the Serial Monitor at 115200 baud, line ending "Newline".
//
// Wiring: servo signal (orange / yellow / white) -> GPIO 18 (change SERVO_PIN for the other servo: 19).
//         servo + (red)     -> its own 5 V supply
//         servo - (brown)   -> the supply's ground AND an ESP32 GND pin. THE GROUNDS MUST BE JOINED:
//                              without it the signal has no reference and the servo twitches or ignores it.
//
// Commands (type, then Enter):
//   1500      hold that pulse width in microseconds (500..2500). 1500 is the middle.
//   s         sweep slowly between 1000 and 2000 microseconds (the range every servo accepts)
//   w         sweep slowly between 600 and 2400 microseconds (the wide range the robot firmware uses)
//   x         stop sending pulses (the servo goes limp)
#include <Arduino.h>

const int SERVO_PIN = 18;     // 18 = grip servo, 19 = lift servo
const int CHANNEL = 4;        // same LEDC channel as the robot firmware
const int PWM_HZ = 50, PWM_BITS = 14;

#if ESP_ARDUINO_VERSION_MAJOR >= 3
void pwmAttach(int pin, int channel, int hz, int bits) { ledcAttachChannel(pin, hz, bits, channel); }
void pwmOut(int pin, int channel, uint32_t duty) { ledcWrite(pin, duty); }
#else
void pwmAttach(int pin, int channel, int hz, int bits) {
  ledcSetup(channel, hz, bits);
  ledcAttachPin(pin, channel);
}
void pwmOut(int pin, int channel, uint32_t duty) { ledcWrite(channel, duty); }
#endif

// Send a pulse of `microseconds` every 20 ms.
void pulse(int microseconds) {
  pwmOut(SERVO_PIN, CHANNEL, (uint32_t)microseconds * (1UL << PWM_BITS) / 20000UL);
}

enum Mode { HOLD, SWEEP, LIMP } mode = LIMP;
int sweepLow, sweepHigh, sweepNow, sweepStep = 5;
char line[16];
int length = 0;

void handleLine() {
  line[length] = 0;
  length = 0;
  if (line[0] == 's' || line[0] == 'w') {
    sweepLow = line[0] == 's' ? 1000 : 600;
    sweepHigh = line[0] == 's' ? 2000 : 2400;
    sweepNow = (sweepLow + sweepHigh) / 2;
    sweepStep = 5;
    mode = SWEEP;
    Serial.printf("sweeping %d..%d us\n", sweepLow, sweepHigh);
  } else if (line[0] == 'x') {
    mode = LIMP;
    pwmOut(SERVO_PIN, CHANNEL, 0);
    Serial.println("limp (no pulses)");
  } else if (line[0] >= '0' && line[0] <= '9') {
    int us = constrain(atoi(line), 500, 2500);
    mode = HOLD;
    pulse(us);
    Serial.printf("holding %d us\n", us);
  }
}

void setup() {
  Serial.begin(115200);
  pwmAttach(SERVO_PIN, CHANNEL, PWM_HZ, PWM_BITS);
  pwmOut(SERVO_PIN, CHANNEL, 0);
  Serial.printf("\nServo test on GPIO %d. Type 1500, s, w or x.\n", SERVO_PIN);
}

void loop() {
  while (Serial.available()) {
    int c = Serial.read();
    if (c == '\n') {
      if (length) handleLine();
    } else if (c != '\r' && length < (int)sizeof line - 1) {
      line[length++] = c;
    }
  }
  static uint32_t lastMs;
  if (mode == SWEEP && millis() - lastMs >= 20) {
    lastMs = millis();
    sweepNow += sweepStep;
    if (sweepNow >= sweepHigh || sweepNow <= sweepLow) sweepStep = -sweepStep;
    pulse(sweepNow);
  }
}
