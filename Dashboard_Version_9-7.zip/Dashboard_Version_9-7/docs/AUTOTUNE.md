# Auto-tune

Code: `robot_station/autotune/` (the logic) and `robot_station/app/autotune.py` (runs it on the robot).

## The loop

For every test: **rest** (wait until the robot stands still) -> **apply** (send the gains with `CFG`, wait until the robot reports them back) -> **run** (a step test from the PID tab; the robot moves) -> **measure** (from the recorded HEADING, ORIENTATION, ERROR + CORRECTION and WHEELS data) -> **adjust** (pick the next gains) -> repeat.

## Stages

| Stage | Gains | Test | Number of tests |
|---|---|---|---|
| turn | Turn strength `skp`, Turn damping `skd` | In-place turn of 60 deg, direction alternates | Cycles |
| steer | Hold Kp `kp`, Hold Kd `kd` (Ki forced to 0) | Change of heading of 15 deg while driving or reversing at 50 % | Cycles |
| drift | Hold Ki `ki` | Straight drive with the balance reset each time | max(2, Cycles / 2) |

"TURN only" skips steer and drift; "HOLD only" skips turn. Cycles is 1 to 12. The tuner also ends a stage early when the steps get too small to matter, so a good start needs fewer tests.

## What is measured

Overshoot (percent of the step), settling time (into +-2 deg and staying), ringing (swings through the target), final error, whether the output saturated, and chatter (fast sign changes of the correction). One cost number combines them:

`cost = settle_s + 0.04 * overshoot% + 0.25 * ringing + up to 0.3 * |final error| / tolerance` (+2 if the target was never reached).

## Rules

* Overshoot or ringing: more damping (kd or skd); also a softer push (lower kp or skp) if it is bad.
* Chatter: less damping.
* Does not reach the target: more P.
* Smooth and slow: try faster.
* Drift: raise or lower Ki from the lean seen in the straight drive.

The best gains so far are kept; a try that is not better is discarded and the step halves. A better try keeps going with the step x0.85. Gains are limited to the ranges of the PID tab and rounded to 2 decimals.

## Stops

Stick moved, E-STOP, disarm, leaving the PID tab, or lost robot: the test stops, the wheels stop, and the best gains measured so far are applied.

## Limits (be honest)

* The thresholds are heuristics tuned on a simulated robot, not on yours. If a stage ends worse than it began, note the numbers in the messages box and send them to me.
* It needs about half a metre of free floor.
* The `tolerance` is 2 deg; a gyro with drift will limit what the drift stage can find.
