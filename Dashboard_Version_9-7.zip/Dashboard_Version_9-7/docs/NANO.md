# Arduino Nano + HC-05 (V 9.7)

The Nano firmware does what the ESP32 firmware does (driving, gyro hold, snap turns, steering for auto-tune, gyro scale, grip and lift, failsafe, settings). The dashboard is the same; only the link differs: **Bluetooth Classic through an HC-05 on the Nano's serial port**, seen by the PC as a COM port.

**Status: compiled for the ATmega328P (about 16.5 KB flash, under 0.5 KB static RAM) and the protocol code was tested against the dashboard's parser on the PC. Nothing has run on a real Nano yet.** Wheels in the air first.

## Wiring (from your schematic)

| Part | Pin |
|---|---|
| L298N motor A (left) | IN1 D5, IN2 D4, ENA D11 |
| L298N motor B (right) | IN3 D3, IN4 D2, ENB D10 |
| Servo 1 (grip, SG90) | D6 |
| Servo 2 (lift) | D9 |
| GY-521 (MPU6050) | SDA A4, SCL A5, power 5 V |
| HC-05 | its TXD to Nano D0 (RX), its RXD from Nano D1 (TX) |
| LED | D13 (the Nano's own) |

* **HC-05 RXD is 3.3 V logic.** Put a divider between D1 and RXD: D1 - 1 k - RXD - 2 k - GND. Many modules survive 5 V, but not for long.
* **Nano power:** the Nano's VIN wants 7-12 V. If your schematic feeds VIN from +5 V, the Nano will brown out; feed the **5V pin** with 5 V, or VIN with the 9 V pack. Join all grounds (battery, L298N, Nano, servo supply, HC-05).
* Servos: give them their own 5 V supply (not the Nano), grounds joined, a 470-1000 uF capacitor across it. The same advice as before: a dipping supply makes servos hum or stutter.
* The schematic has no battery divider, so the battery reading is off (`BATTERY_FITTED = false` in `config.h`). To add one: 100 k from battery + to A0, 47 k from A0 to GND, then set it to true.
* The Servo library takes Timer 1, which normally makes D9 and D10 PWM. So ENB (D10) is produced by Timer 2 interrupts, at the same 976 Hz as ENA. `motors.h` explains it.

## One-time HC-05 setup

1. Open `nano_hc05_setup_V_9_7`. Wire the HC-05 as the header of that sketch says (D8 / D7 through a divider, KEY pin high at power-on for AT mode). Upload, open the Serial Monitor at 115200, "Both NL & CR".
2. Type `AT` (expect OK), then `AT+NAME=REC-Robot`, `AT+ROLE=0`, `AT+UART=115200,0,0`, `AT+PSWD="1234"`, `AT+RESET`.
3. Move the HC-05 back to D0 / D1 and remove the KEY wire.

## Flash the robot

1. Arduino IDE: board **Arduino Nano**, processor **ATmega328P** (if the upload fails, try "ATmega328P (Old Bootloader)"). Open the folder `nano_robot_V_9_7` and upload.
2. **Unplug the HC-05's TXD wire from D0 while uploading** (it shares the USB serial port), then plug it back.
3. First check: LED on D13 blinks 3 times at start. With the USB cable you can type text in the Serial Monitor (115200): the LED blinks and the Nano answers `ACK,TEXT`.
4. For the Tune page flash `nano_tune_V_9_7` instead. Both keep their values in the EEPROM in the same place, so what you tune is used by the robot. To test one servo alone use `nano_servo_test_V_9_7`.

## Connect from the PC

1. Windows: Settings - Bluetooth - add device - `REC-Robot` (code 1234). Windows then creates two COM ports; the one listed as **Outgoing** is the right one (More Bluetooth settings - COM Ports).
2. Dashboard: LINK tab, choose **Serial**, that COM port, 115200. The output starts disarmed; press BACK to arm.
3. The USB cable works the same way (its COM port) when the HC-05 is unplugged.

Bluetooth Classic is slower to open than BLE. A link silent for 3 s is treated as lost: the Nano disarms itself, and the HC-05 reconnects when the dashboard opens the port again.

## Differences from the ESP32 firmware

* **One serial port** serves the USB cable and the HC-05. Use one at a time; unplug the HC-05's TXD when uploading.
* **Settings are in the EEPROM** (23 values, 4 bytes each). The balance value is saved when the robot stands still and has changed by more than 0.3; other values are saved when you change them. A Nano's EEPROM lasts about 100 000 writes per cell, which is plenty for this.
* **The control loop runs at 200 Hz**; the gyro is read at 200 Hz over I2C at 400 kHz. Floating point is in software on the ATmega, so there is less headroom than on the ESP32: if you add a lot of code, watch the loop.
* **Reports** (TEL and HLD, 10 per second, 20 per second during a turn) wait in a 200-byte queue. If the link is slow a report is skipped, never the control loop delayed.
* No BLE and no on-board battery reading by default.
* `ROBOT_TYPE` in `config.h` is `"tower"` (lift on D9). Set `"simple"` for a robot with the grip only.

## If something is off

* **No HELLO / the dashboard cannot connect:** baud mismatch is the usual cause. The HC-05 must be at 115200 (`AT+UART?` in AT mode) and the dashboard at 115200.
* **Nano resets when the wheels start:** the supply dips. Separate the Nano and servo supplies from the motor supply, or add capacitors near the L298N.
* **The yaw drifts or the gyro reads 0:** GY-521 power or I2C wires; the TEL flags show whether the gyro answered.
* **Turn direction reversed:** the dashboard's "Flip gyro direction" button (saved in the EEPROM).
