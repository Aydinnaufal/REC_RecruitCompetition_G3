@echo off
cd /d "%~dp0"
set PY=python
if exist "..\.venv\Scripts\python.exe" set PY="..\.venv\Scripts\python.exe"
%PY% -m pip install -q -r requirements.txt
%PY% run_dashboard.py
pause
