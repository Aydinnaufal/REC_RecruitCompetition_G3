// config.h - everything you may want to change, and the hardware pin numbers.
//
// Arduino Nano (ATmega328P, 16 MHz) + HC-05 Bluetooth module + L298N + MPU6050 (GY-521) + 2 servos.
#pragma once

// ---------------------------------------------------------------- identity
const char ROBOT_TYPE[] = "tower";    // "tower":  grip servo (D6) + lift servo (D9), the lift stick moves it like a speed
                                      // "simple": grip servo only; the lift servo is NOT driven then
const char FW_VERSION[] = "V_9_7_nano";

// ---------------------------------------------------------------- serial link
// The HC-05 sits on the Nano's only serial port (D0 / D1), the same one the USB cable uses.
// The dashboard talks at 115200: set the HC-05 to 115200 once (see docs/NANO.md, sketch nano_hc05_setup).
const uint32_t LINK_BAUD = 115200;

// ---------------------------------------------------------------- pins (schematic: Arduino Nano)
const uint8_t IN1 = 5, IN2 = 4;       // left motor  (L298N motor A) direction
const uint8_t IN3 = 3, IN4 = 2;       // right motor (L298N motor B) direction
const uint8_t ENA_PIN = 11;           // left motor speed  (PWM, Timer 2)
const uint8_t ENB_PIN = 10;           // right motor speed (PWM made by Timer 2 too, see motors.h)
const uint8_t SERVO1_PIN = 6;         // grip
const uint8_t SERVO2_PIN = 9;         // lift (tower only)
const uint8_t BATTERY_PIN = A0;       // battery divider (not fitted in the schematic)
const uint8_t LED_PIN = 13;           // on-board LED
// MPU6050 gyro: SDA = A4, SCL = A5 (see gyro.h)

// ---------------------------------------------------------------- safety
const uint32_t FAILSAFE_MS = 400;     // no valid CMD for this long = the wheels stop
const uint32_t LINK_LOST_MS = 3000;   // ... and after this long the output is disarmed too (the HC-05 gives no "connected" signal)

// ---------------------------------------------------------------- battery
// The schematic has no battery divider. To measure the pack, put 100k from the battery + to A0 and 47k from A0 to GND
// (3.1 x ratio, the default) and set BATTERY_FITTED to true. A0 may not see more than 5 V: 9 V / 3.13 = 2.9 V is fine.
const bool BATTERY_FITTED = false;
const float DEFAULT_VBAT_RATIO = 3.13f;  // (100 + 47) / 47; the Tune page can change it (kept in EEPROM)

// ---------------------------------------------------------------- gyro
// First-run default; the dashboard button "Flip gyro direction" changes it and the choice is kept in EEPROM.
// +1 = turning LEFT (counter-clockwise seen from above) raises the yaw angle.
const float GYRO_SIGN = 1.0f;
const float GYRO_DEADBAND = 0.15f;    // deg/s ignored while integrating the yaw angle
// Gyro measuring range. +-250 deg/s is too small for fast motors: a spin faster than that is clipped and the
// robot turns further than the yaw says.
const uint8_t GYRO_RANGE_REG = 0x10;  // 0x00 = +-250, 0x08 = +-500, 0x10 = +-1000, 0x18 = +-2000 deg/s
const float GYRO_LSB_PER_DPS = 32.8f; // 131.0 for +-250, 65.5 for +-500, 32.8 for +-1000, 16.4 for +-2000
const uint32_t GYRO_PERIOD_MS = 5;    // read and integrate the gyro every 5 ms (200 Hz)

// The control (turns, hold, ramp, servos) runs at this period. The Nano has no hardware float: this keeps the load low.
const uint32_t CONTROL_PERIOD_MS = 5;

// ---------------------------------------------------------------- wheel ramp
// The wheel speed may change by at most this many percent per second (700 = about 0.15 s from stop
// to full). Stopping by failsafe is instant and does not use the ramp.
const float RAMP_UP = 700, RAMP_DOWN = 2000;

// ---------------------------------------------------------------- servos
const float SERVO_DPS = 300.0f;       // servos move at most this fast (degrees per second). A small step per update makes
                                      // a servo weak and slow (it only pushes in proportion to the gap), so this is high;
                                      // lower it if the servo supply dips and the servo stutters or the Nano resets.
// The last few degrees at each end are often the servo's mechanical stop: pushing there makes it hum and
// draw a lot of current. These are the limits used when none are saved, and when saved ones are unusable.
const int SERVO_SAFE_LOW = 10, SERVO_SAFE_HIGH = 170;
const int SERVO_MIN_SPAN = 10;        // limits closer together than this (degrees) are ignored
const float LIFT_RATE = 2.0f;         // tower: the lift stick (-100..100) times this is the lift speed in percent of its travel per second:
                                      // full stick = 200 % per second, about 0.5 s end to end (SERVO_DPS also limits it)
const int LIFT_MIN_DEG = 20, LIFT_MAX_DEG = 160;

// ---------------------------------------------------------------- gyro control limits
const float HOLD_MAX = 25;            // biggest straight-line correction, in percent of wheel speed
const float BAL_MAX = 25;             // biggest learned wheel balance, in percent
const float SNAP_MAX = 50;            // snap turn: fastest wheel speed (percent)
const float SNAP_APPROACH = 0.9f;     // snap turn: the wheel speed may be at most this many percent per degree of error left,
                                      // so the turn slows down smoothly on the way in (90 deg away: no limit; 10 deg: 9 %)
const float SNAP_MIN = 12;            // snap turn: the lowest steady wheel speed. A wanted speed below this is made by
                                      // pulsing this speed on and off (SNAP_PULSE_MS), so the average is what is wanted
const float SNAP_DECEL = 500;         // snap turn: the turn rate may not be more than sqrt(2 * this * error) (deg/s, deg/s^2):
                                      // the speed the robot can still stop from; faster than that and the wheels brake
const float SNAP_BRAKE = 0.25f;       // snap turn: braking wheel speed (percent) per deg/s above that rate
const float SNAP_PULSE_BELOW_RATE = 40;  // snap turn: braking is not pulsed while turning faster than this (deg/s)
const uint32_t SNAP_PULSE_MS = 80;    // length of one on / off pulse period
const float SNAP_REARM = 1.7f;        // after arriving the wheels stay off until the error is SNAP_TOL times this
const float SNAP_TOL = 1.2f;          // snap turn: this close (degrees) counts as arrived
const float SNAP_STILL = 12;          // ... and the turn rate must be below this (deg/s)
const uint32_t SNAP_TIMEOUT_BASE_MS = 2000;  // give up a snap turn after this long plus ...
const uint32_t SNAP_TIMEOUT_MS_PER_DEG = 15;  // ... this many ms for every degree it had to turn (180 degrees: 4.7 s)
const uint32_t HOLD_LATCH_MS = 300;   // heading is latched this long after the last turn settled
const float HOLD_LATCH_RATE = 20;     // ... and only when the turn rate is below this (deg/s)
const float STRAIGHT_MAX_DIFF = 3;    // wheels count as "the same speed" when commands differ by less (percent)
const float STRAIGHT_MIN_SPEED = 10;  // ... and the robot counts as driving above this (percent)

// ---------------------------------------------------------------- reports to the dashboard
const uint32_t HOLD_REPORT_MS = 100;       // gyro control report (HLD) period
const uint32_t HOLD_REPORT_FAST_MS = 50;   // ... while a heading target is active (auto-tune needs the detail)
