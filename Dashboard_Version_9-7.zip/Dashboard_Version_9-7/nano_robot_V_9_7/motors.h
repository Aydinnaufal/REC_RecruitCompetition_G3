// motors.h - wheels, servos and the speed ramp.
//
// L298N: the direction comes from the two IN pins, the speed from PWM on the EN pin.
//   left  motor (A): IN1 D5, IN2 D4, ENA D11   -> Timer 2 PWM pin
//   right motor (B): IN3 D3, IN4 D2, ENB D10   -> D10 is a Timer 1 pin, but the Servo library owns Timer 1
//                                                 (D6 and D9 are servos). So ENB is made by Timer 2, in software
//                                                 inside its interrupts: same 976 Hz as ENA.
#pragma once
#include <Servo.h>

// ---------------------------------------------------------------- PWM for the two EN pins
volatile uint8_t enbDuty;  // 0..255 for D10

ISR(TIMER2_OVF_vect) {      // the counter wrapped: start of a PWM period, D10 goes high
  if (enbDuty) PORTB |= _BV(PB2);
}
ISR(TIMER2_COMPB_vect) {    // the counter reached the duty: D10 goes low
  PORTB &= ~_BV(PB2);
}

void setEnb(uint8_t duty) {
  uint8_t sreg = SREG;
  cli();
  enbDuty = duty;
  OCR2B = duty;
  if (duty == 0 || duty == 255) {  // no compare needed: steady low or steady high
    TIMSK2 &= ~_BV(OCIE2B);
    if (duty) PORTB |= _BV(PB2);
    else PORTB &= ~_BV(PB2);
  } else {
    TIMSK2 |= _BV(OCIE2B);
  }
  SREG = sreg;
}

void motorsInit() {
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);
  pinMode(ENA_PIN, OUTPUT);
  pinMode(ENB_PIN, OUTPUT);
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
  digitalWrite(ENA_PIN, LOW);
  digitalWrite(ENB_PIN, LOW);
  // Timer 2: fast PWM, prescaler 64 = 976 Hz (the Arduino default is 490 Hz). ENA uses its output pin (OC2A),
  // ENB uses the overflow and compare-B interrupts.
  TCCR2A = _BV(WGM21) | _BV(WGM20);
  TCCR2B = _BV(CS22);
  OCR2A = 0;
  OCR2B = 0;
  TIMSK2 = _BV(TOIE2);
}

// One wheel. side: 0 = left, 1 = right. percent: -100..100.
void setWheel(int side, float percent) {
  // gl / gr: this wheel is a bit stronger or weaker than the other.
  int pc = constrain((int)lroundf(percent * (side ? gr : gl)), -100, 100);
  // invl / invr: the motor is wired the other way round.
  int signedPercent = (side ? invr : invl) > 0 ? -pc : pc;
  // ml / mr: the lowest PWM that still turns this wheel; 1 % maps to it, 100 % to full power.
  int pwm = pc ? map(abs(pc), 1, 100, (int)(side ? mr : ml), 255) : 0;
  pwm = constrain(pwm, 0, 255);
  uint8_t forward = side ? IN3 : IN1, backward = side ? IN4 : IN2;
  digitalWrite(forward, signedPercent > 0);
  digitalWrite(backward, signedPercent < 0);
  if (side) setEnb(pwm);
  else analogWrite(ENA_PIN, pwm);
}

void stopWheels() {
  speedLeft = speedRight = 0;
  setWheel(0, 0);
  setWheel(1, 0);
  holding = false;
  correction = headingError = 0;
}

void disarm() {
  armed = false;
  cmdLeft = cmdRight = 0;
  stopWheels();
}

// Move `current` toward `wanted`, at most RAMP_UP / RAMP_DOWN percent per second.
float ramp(float current, float wanted, float dt) {
  float diff = wanted - current;
  float limit = (fabsf(wanted) > fabsf(current) ? RAMP_UP : RAMP_DOWN) * dt;
  if (diff > limit) return current + limit;
  if (diff < -limit) return current - limit;
  return wanted;
}

// ---------------------------------------------------------------- servos
// The Servo library makes the pulses on Timer 1 interrupts; a servo is "limp" (no pulses) until it is first commanded.
// 0..180 degrees = 0.5..2.4 ms pulse in a 20 ms frame.
Servo servoDriver[2];
bool servoAttached[2];
const uint8_t SERVO_PIN[2] = {SERVO1_PIN, SERVO2_PIN};

void servoPulse(int i, int degrees) {
  if (!servoAttached[i]) {
    servoDriver[i].attach(SERVO_PIN[i], 500, 2400);
    servoAttached[i] = true;
  }
  servoDriver[i].writeMicroseconds(500 + (int)(1900L * degrees / 180));
}

// The limits servo i really uses. Saved limits that cannot work (outside 0..180, upside down, or
// almost the same number: the servo could not move at all) are replaced by the safe ones.
void servoLimits(int i, int* low, int* high) {
  int a = constrain((int)(i ? lo2 : lo1), 0, 180);
  int b = constrain((int)(i ? hi2 : hi1), 0, 180);
  if (a > b) {
    int t = a;
    a = b;
    b = t;
  }
  if (b - a < SERVO_MIN_SPAN) {
    a = SERVO_SAFE_LOW;
    b = SERVO_SAFE_HIGH;
  }
  *low = a;
  *high = b;
}

// Ask servo i to go to an angle (kept inside its limits; reached at SERVO_DPS).
void servoGoto(int i, int degrees) {
  int low, high;
  servoLimits(i, &low, &high);
  servoTarget[i] = constrain(degrees, low, high);
  if (servoAngle[i] < 0) {  // first command after power-up: the real position is unknown, start there
    servoPosition[i] = servoTarget[i];
    servoAngle[i] = servoTarget[i];
    servoPulse(i, servoAngle[i]);
  }
}

// Move the servos toward their targets, SERVO_DPS at most.
void servoStep(float dt) {
  for (int i = 0; i < 2; i++) {
    if (servoAngle[i] < 0 || servoPosition[i] == servoTarget[i]) continue;
    float diff = servoTarget[i] - servoPosition[i], most = SERVO_DPS * dt;
    servoPosition[i] += diff > most ? most : diff < -most ? -most : diff;
    int angle = (int)(servoPosition[i] + 0.5f);
    if (angle != servoAngle[i]) {
      servoAngle[i] = angle;
      servoPulse(i, angle);
    }
  }
}
