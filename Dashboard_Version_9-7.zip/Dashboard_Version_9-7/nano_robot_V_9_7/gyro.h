// gyro.h - MPU6050 (GY-521) on I2C (SDA = A4, SCL = A5), only the Z-axis rate is used.
#pragma once
#include <Wire.h>

const uint8_t MPU_ADDRESS = 0x68;

void gyroInit() {
  Wire.begin();
  Wire.setClock(400000);
#ifdef WIRE_HAS_TIMEOUT
  Wire.setWireTimeout(3000, true);  // a stuck bus must not freeze the robot: give up after 3 ms and reset the bus
#endif
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(0x6B);  // power management: wake up
  Wire.write(0);
  imuOk = Wire.endTransmission() == 0;
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(0x1B);  // gyro range, see GYRO_RANGE_REG in config.h
  Wire.write(GYRO_RANGE_REG);
  Wire.endTransmission();
}

// Z-axis rate in deg/s. Returns false if the sensor did not answer.
bool readGyroZ(float& dps) {
  Wire.beginTransmission(MPU_ADDRESS);
  Wire.write(0x47);
  if (Wire.endTransmission(false) || Wire.requestFrom((uint8_t)MPU_ADDRESS, (uint8_t)2) != 2) return false;
  uint8_t high = Wire.read();
  uint8_t low = Wire.read();
  dps = (int16_t)((high << 8) | low) / GYRO_LSB_PER_DPS;
  return true;
}

// Measure the zero-rate offset: the robot must stand still for one second.
void startCalibration() {
  gyroCalibrating = true;
  calSamples = 0;
  calSum = 0;
  calStartMs = millis();
}

// Call every loop: reads the sensor at 200 Hz and integrates the yaw angle.
void updateGyro(uint32_t now) {
  if (!imuOk || now - lastGyroMs < GYRO_PERIOD_MS) return;
  float dt = (now - lastGyroMs) * 1e-3f, dps;
  lastGyroMs = now;
  if (!readGyroZ(dps)) return;
  if (gyroCalibrating) {
    calSum += dps;
    calSamples++;
    yawRate = 0;
    if (now - calStartMs > 1000 && calSamples > 20) {
      gyroBias = calSum / calSamples;
      gyroCalibrating = false;
      yaw = 0;
    }
  } else {
    yawRate = (dps - gyroBias) * gsign * constrain(gscale, 0.8f, 1.2f);
    if (fabsf(yawRate) > GYRO_DEADBAND) yaw += yawRate * dt;
  }
}
