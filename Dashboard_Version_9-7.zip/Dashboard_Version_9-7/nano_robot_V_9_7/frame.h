// frame.h - the rec1 text protocol on the one serial port of the Arduino Nano ($TYPE,field,field*HH).
//
// The Nano has no float printf or scanf and only 2 KB of RAM, so numbers are written and read by hand
// here, and outgoing frames wait in a queue that is sent as the serial port has room: the control loop
// never waits for the serial port.
//
// This file is the same in nano_robot and nano_tune.
#pragma once

// ---------------------------------------------------------------- writing frames
const uint8_t FRAME_MAX = 120;  // longest frame body
const uint8_t TX_SIZE = 200;    // queue of frames waiting for the serial port
uint8_t txBuf[TX_SIZE];
uint8_t txHead, txTail;         // write here / send from here (a ring: one slot stays empty)
uint16_t txDropped;             // frames that did not fit (the dashboard just misses one report)

uint8_t txFree() { return (uint8_t)((txTail + TX_SIZE - txHead - 1) % TX_SIZE); }

// Send what the serial port has room for. Call every loop.
void txPump() {
  while (txTail != txHead && Serial.availableForWrite() > 0) {
    Serial.write(txBuf[txTail]);
    txTail = (txTail + 1) % TX_SIZE;
  }
}

// Number to text. Returns the end of what was written.
char* putInt(char* p, long v) {
  unsigned long u = v;
  if (v < 0) {
    *p++ = '-';
    u = -v;
  }
  char digits[11];
  uint8_t n = 0;
  do {
    digits[n++] = '0' + u % 10;
    u /= 10;
  } while (u);
  while (n) *p++ = digits[--n];
  return p;
}

char* putFloat(char* p, float v, uint8_t decimals) {
  if (isnan(v)) v = 0;
  if (v > 2000000.0f) v = 2000000.0f;
  if (v < -2000000.0f) v = -2000000.0f;
  unsigned long scale = 1;
  for (uint8_t i = 0; i < decimals; i++) scale *= 10;
  unsigned long scaled = (unsigned long)(fabsf(v) * scale + 0.5f);
  if (v < 0 && scaled) *p++ = '-';
  p = putInt(p, (long)(scaled / scale));
  if (decimals) {
    *p++ = '.';
    unsigned long fraction = scaled % scale;
    for (unsigned long d = scale / 10; d; d /= 10) *p++ = '0' + (fraction / d) % 10;
  }
  return p;
}

// One frame being built:  Frame f(F("TEL")); f.i(5).f(1.5, 1); f.send();   gives  $TEL,5,1.5*HH
class Frame {
 public:
  char b[FRAME_MAX + 6];
  uint8_t n;

  explicit Frame(const __FlashStringHelper* type) {
    b[0] = '$';
    n = 1;
    appendFlash(type);
  }
  Frame& i(long v) {
    if (room(12)) {
      b[n++] = ',';
      n = putInt(b + n, v) - b;
    }
    return *this;
  }
  Frame& f(float v, uint8_t decimals) {
    if (room(20)) {
      b[n++] = ',';
      n = putFloat(b + n, v, decimals) - b;
    }
    return *this;
  }
  Frame& txt(const __FlashStringHelper* s) {  // a text field kept in flash
    if (room(1)) b[n++] = ',';
    appendFlash(s);
    return *this;
  }
  Frame& ram(const char* s) {  // a text field in RAM
    if (room(1)) b[n++] = ',';
    while (*s && room(1)) b[n++] = *s++;
    return *this;
  }
  // Add the checksum and queue the frame. A frame that does not fit is dropped.
  void send() {
    uint8_t sum = 0;
    for (uint8_t k = 1; k < n; k++) sum ^= (uint8_t)b[k];
    b[n++] = '*';
    b[n++] = "0123456789ABCDEF"[sum >> 4];
    b[n++] = "0123456789ABCDEF"[sum & 15];
    b[n++] = '\n';
    if (txFree() < n) {
      txDropped++;
      return;
    }
    for (uint8_t k = 0; k < n; k++) {
      txBuf[txHead] = b[k];
      txHead = (txHead + 1) % TX_SIZE;
    }
  }

 private:
  bool room(uint8_t more) { return n + more < FRAME_MAX; }
  void appendFlash(const __FlashStringHelper* s) {
    const char* p = (const char*)s;
    char c;
    while ((c = pgm_read_byte(p++)) && room(1)) b[n++] = c;
  }
};

// ---------------------------------------------------------------- reading frames
// Text to number. They skip spaces and return where reading stopped (nullptr: no number there).
const char* getLong(const char* p, long* out) {
  while (*p == ' ') p++;
  bool negative = *p == '-';
  if (*p == '-' || *p == '+') p++;
  if (*p < '0' || *p > '9') return nullptr;
  long v = 0;
  while (*p >= '0' && *p <= '9') v = v * 10 + (*p++ - '0');
  *out = negative ? -v : v;
  return p;
}

const char* getFloat(const char* p, float* out) {
  while (*p == ' ') p++;
  bool negative = *p == '-';
  if (*p == '-' || *p == '+') p++;
  if ((*p < '0' || *p > '9') && *p != '.') return nullptr;
  float v = 0;
  while (*p >= '0' && *p <= '9') v = v * 10 + (*p++ - '0');
  if (*p == '.') {
    p++;
    float place = 0.1f;
    while (*p >= '0' && *p <= '9') {
      v += (*p++ - '0') * place;
      place *= 0.1f;
    }
  }
  *out = negative ? -v : v;
  return p;
}

// "1,2,-3" -> v[0..n-1]. Returns how many numbers were read (at most `max`).
uint8_t getLongs(const char* p, long* v, uint8_t max) {
  uint8_t n = 0;
  while (n < max) {
    p = getLong(p, &v[n]);
    if (!p) break;
    n++;
    if (*p != ',') break;
    p++;
  }
  return n;
}

// Check "$body*HH" and return the body, or nullptr for a damaged frame. The line is changed (the * becomes 0).
int8_t hexValue(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

char* openFrame(char* line) {
  if (line[0] != '$') return nullptr;
  char* star = strrchr(line, '*');
  if (!star || hexValue(star[1]) < 0 || hexValue(star[2]) < 0) return nullptr;
  uint8_t want = (hexValue(star[1]) << 4) | hexValue(star[2]), sum = 0;
  *star = 0;
  for (const char* q = line + 1; *q; q++) sum ^= (uint8_t)*q;
  return sum == want ? line + 1 : nullptr;
}

// Collect characters into lines; every complete line goes to `onLine`. Call every loop.
const uint8_t RX_LINE = 72;
char rxLine[RX_LINE];
uint8_t rxLength;

void readLink(void (*onLine)(char*)) {
  while (Serial.available()) {
    int c = Serial.read();
    if (c < 0) break;
    if (c == '\n') {
      rxLine[rxLength] = 0;
      if (rxLength) onLine(rxLine);
      rxLength = 0;
    } else if (c != '\r') {
      if (rxLength < RX_LINE - 1) rxLine[rxLength++] = c;
      else rxLength = 0;  // line too long: drop it
    }
  }
}
