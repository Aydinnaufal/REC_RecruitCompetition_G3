// protocol.h - the rec1 text protocol over the serial port (HC-05 Bluetooth or the USB cable).
//
// A frame is one line:  $TYPE,field,field*HH\n   (HH = XOR of everything between $ and *, in hex)
//
// Dashboard -> robot
//   CMD,seq,vl,vr,grip,lift,enable[,hdg[,steer]]
//        sent 30 times a second, it is also the heartbeat. Nothing moves unless enable = 1.
//        hdg   = target yaw in tenths of a degree; the robot turns to it with its gyro.
//        steer = 1: reach that heading while DRIVING (the straight-line PID steers there, used by auto-tune).
//   PING,n   HELLO?   STOP   ZERO   CAL   CFG,name,value
// Robot -> dashboard
//   HELLO,proto,fw,robot,version   RST,reason,seconds   PONG,n,ms   ACK,...
//   TEL,seq,ack,ms,yaw,gz,vl,vr,grip,lift,vbat_mv,flags
//   HLD,mode,target,err,corr,bal,gl,gr,ml,mr,kp,ki,kd,hold,gsign,skp,skd,gscale
#pragma once

// ---------------------------------------------------------------- reports
// HLD: what the gyro control is doing and its settings.
void sendControlState() {
  float target = holding ? holdYaw : (turnActive ? turnTarget : yaw);
  Frame f(F("HLD"));
  f.i(controlMode).f(target, 1).f(headingError, 1).f(correction, 1).f(bal, 2).f(gl, 2).f(gr, 2);
  f.i((int)ml).i((int)mr).f(kp, 2).f(ki, 2).f(kd, 2).i((int)hold).i((int)gsign).f(skp, 2).f(skd, 2).f(gscale, 3);
  f.send();
}

// Battery in millivolts, or 0 when no divider is fitted.
int batteryMillivolts() {
  if (!BATTERY_FITTED) return 0;
  long sum = 0;
  for (int i = 0; i < 4; i++) sum += analogRead(BATTERY_PIN);
  return (int)(sum / 4 * 5000L / 1023 * ratio);
}

// TEL: heading, turn rate, wheel speeds, battery and status flags.
void sendTelemetry() {
  int batteryMv = batteryMillivolts();
  bool failsafe = millis() - lastCmdMs > FAILSAFE_MS;
  int flags = (armed ? 1 : 0) | (failsafe ? 2 : 0) | (imuOk && !gyroCalibrating ? 4 : 0) |
              (gyroCalibrating ? 8 : 0) | (batteryMv > 1000 && batteryMv < 6400 ? 16 : 0);
  Frame f(F("TEL"));
  f.i(++telemetrySeq).i(lastCmdSeq).i((long)millis()).f(yaw, 1).f(yawRate, 1);
  f.i((int)lroundf(speedLeft)).i((int)lroundf(speedRight)).i(cmdGrip).i((int)liftPosition).i(batteryMv).i(flags);
  f.send();
}

// ---------------------------------------------------------------- incoming frames
void handleCmd(const char* fields) {
  long v[8];
  uint8_t n = getLongs(fields, v, 8);
  if (n < 6) return;
  lastCmdSeq = (uint16_t)v[0];
  cmdLeft = constrain(v[1], -100, 100);
  cmdRight = constrain(v[2], -100, 100);
  cmdGrip = constrain(v[3], 0, 100);
  cmdLift = constrain(v[4], -100, 100);
  armed = v[5] == 1;
  lastCmdMs = millis();
  if (n >= 7 && armed) {  // field 7: turn to this yaw (tenths of a degree)
    float target = v[6] / 10.0f;
    if (!turnActive) {
      turnSinceMs = millis();
      snapDone = false;
      turnStartError = fabsf(target - yaw);
    }
    turnActive = true;
    turnTarget = target;
    steerWhileDriving = n == 8 && v[7] == 1;  // field 8: reach it while driving
  } else {
    turnActive = false;
    steerWhileDriving = false;
  }
}

// CFG,name,value: change a setting and keep it in the EEPROM.
void handleCfg(const char* fields) {
  char name[8];
  uint8_t length = 0;
  while (*fields && *fields != ',' && length < 7) name[length++] = *fields++;
  name[length] = 0;
  float value;
  if (*fields != ',' || !getFloat(fields + 1, &value)) return;
  int k = settingIndex(name);
  if (k < 0) return;
  float* setting = SETTING_VALUE[k];
  if (setting == &gsign) {
    value = value < 0 ? -1 : 1;
    if (value != gsign) {  // the other gyro direction: mirror the angle so nothing jumps
      yaw = -yaw;
      holding = false;
    }
  }
  if (setting == &bal) balSavedInEeprom = value;
  *setting = value;
  saveSetting(k);
  Frame ack(F("ACK"));
  ack.txt(F("CFG")).ram(name);
  ack.send();
  sendControlState();
}

void handleLine(char* line) {
  const char* body = openFrame(line);
  if (!body) {  // not a frame (typed text) or a damaged one: typed text lights the LED, a damaged frame is ignored
    if (line[0] != '$') {
      ledUntilMs = millis() + 2000;
      blinkCount = 3;
      Frame(F("ACK")).txt(F("TEXT")).send();
    }
    return;
  }
  lastRxMs = millis() | 1;  // |1: never 0, which means "never heard"

  if (!strncmp_P(body, PSTR("CMD,"), 4)) {
    handleCmd(body + 4);
  } else if (!strncmp_P(body, PSTR("PING,"), 5)) {
    Frame f(F("PONG"));
    f.ram(body + 5).i((long)millis());
    f.send();
  } else if (!strncmp_P(body, PSTR("HELLO?"), 6)) {
    Frame hello(F("HELLO"));
    hello.i(1).txt(F("rec-robot")).ram(ROBOT_TYPE).ram(FW_VERSION);
    hello.send();
    Frame rst(F("RST"));
    rst.txt(F("reset")).i((long)(millis() / 1000));
    rst.send();
    sendControlState();
  } else if (!strncmp_P(body, PSTR("STOP"), 4)) {
    disarm();
    Frame(F("ACK")).txt(F("STOP")).send();
  } else if (!strncmp_P(body, PSTR("ZERO"), 4)) {
    yaw = 0;
    holding = false;
    Frame(F("ACK")).txt(F("ZERO")).send();
  } else if (!strncmp_P(body, PSTR("CAL"), 3)) {
    stopWheels();
    startCalibration();
    Frame(F("ACK")).txt(F("CAL")).send();
  } else if (!strncmp_P(body, PSTR("CFG,"), 4)) {
    handleCfg(body + 4);
  }
}
