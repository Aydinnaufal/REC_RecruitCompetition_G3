// settings.h - values that are kept in the EEPROM and can be changed from the dashboard (CFG,name,value).
//
// The first eight are the values of the Tune page (nano_tune writes them), the rest belong to the full robot
// firmware. Both sketches use the same table in the same order, so what was tuned is used by the robot.
// An EEPROM slot that was never written reads as "not a number": then the default below is used.
#pragma once
#include <EEPROM.h>

// ---- shared with the tuning firmware
float minpwm = 0;          // lowest PWM that still turns a wheel (the per-wheel ml / mr start from it)
float invl = 0, invr = 0;  // 1 = this wheel is wired the other way round
float lo1 = SERVO_SAFE_LOW, hi1 = SERVO_SAFE_HIGH;  // servo 1 (grip) limits in degrees
float lo2 = SERVO_SAFE_LOW, hi2 = SERVO_SAFE_HIGH;  // servo 2 (lift) limits
float ratio = DEFAULT_VBAT_RATIO;                   // battery divider ratio
float go = 90, gc = 30;    // grip servo angle when open / closed
float hold = 1;            // 1 = keep a straight line with the gyro

// ---- straight-line hold: PID on the heading error
float kp = 1.2f;   // hold strength
float ki = 1.0f;   // hold learning: how fast the wheel balance is learned
float kd = 0.15f;  // hold damping (uses the turn rate)

// ---- wheel corrections
float gl = 1, gr = 1;   // wheel gain: one wheel is a bit stronger or weaker
float ml = 0, mr = 0;   // start PWM per wheel
float bal = 0;          // learned balance: how much more the weaker wheel needs, in percent

// ---- gyro
float gsign = GYRO_SIGN;  // gyro direction, +1 or -1
float gscale = 1.0f;      // gyro scale: the measured angle is multiplied by this (a turn that reads 90 but really is 92 needs 1.022)

// ---- snap turn: PD on the heading error
float skp = 1.4f;  // turn strength
float skd = 0.2f;  // turn damping

// Name -> variable. THE ORDER IS THE EEPROM LAYOUT and the first eight are the order of the TCFG frame: do not change it.
const uint8_t SETTING_COUNT = 23;
const char SETTING_NAME[SETTING_COUNT][8] PROGMEM = {
    "minpwm", "invl", "invr", "lo1", "hi1", "lo2", "hi2", "ratio", "go",   "gc",     "hold", "kp",
    "ki",     "kd",   "gl",   "gr",  "ml",  "mr",  "bal", "gsign", "gscale", "skp", "skd"};
float* const SETTING_VALUE[SETTING_COUNT] = {&minpwm, &invl, &invr, &lo1, &hi1, &lo2, &hi2, &ratio,
                                             &go,     &gc,   &hold, &kp,  &ki,  &kd,  &gl,  &gr,
                                             &ml,     &mr,   &bal,  &gsign, &gscale, &skp, &skd};

const int EEPROM_MAGIC_ADDRESS = 0;  // 2 bytes: tells that the layout is this one
const uint16_t EEPROM_MAGIC = 0xEC01;
const int EEPROM_FIRST = 2;          // setting k lives at EEPROM_FIRST + 4 * k

int settingIndex(const char* name) {
  for (uint8_t k = 0; k < SETTING_COUNT; k++)
    if (!strcmp_P(name, SETTING_NAME[k])) return k;
  return -1;
}

void saveSetting(int k) { EEPROM.put(EEPROM_FIRST + 4 * k, *SETTING_VALUE[k]); }  // writes only the bytes that changed

float balSavedInEeprom;  // the balance last written (it is rewritten only when it changed)

void loadSettings() {
  uint16_t magic;
  EEPROM.get(EEPROM_MAGIC_ADDRESS, magic);
  if (magic != EEPROM_MAGIC) {  // first start, or another layout: start clean
    for (int a = EEPROM_FIRST; a < EEPROM_FIRST + 4 * SETTING_COUNT; a++) EEPROM.update(a, 0xFF);
    EEPROM.put(EEPROM_MAGIC_ADDRESS, EEPROM_MAGIC);
  }
  bool haveMl = false, haveMr = false;
  for (uint8_t k = 0; k < SETTING_COUNT; k++) {
    float v;
    EEPROM.get(EEPROM_FIRST + 4 * k, v);
    if (isnan(v) || isinf(v)) continue;  // never saved: keep the default
    *SETTING_VALUE[k] = v;
    if (SETTING_VALUE[k] == &ml) haveMl = true;
    if (SETTING_VALUE[k] == &mr) haveMr = true;
  }
  // The per-wheel start PWM begins as the value found on the dashboard's Tune page.
  if (!haveMl) ml = minpwm;
  if (!haveMr) mr = minpwm;
  balSavedInEeprom = bal;
}
