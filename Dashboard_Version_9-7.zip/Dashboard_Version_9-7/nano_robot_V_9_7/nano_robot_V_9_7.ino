// REC robot - FULL ROBOT firmware V_9_7 for the ARDUINO NANO, for Robot Station V 9.7.
//
// Xbox controller -> dashboard -> HC-05 Bluetooth (or the USB cable) -> this board: wheels, grip / lift servos,
// gyro feedback, gyro PID, snap turns and the steering used by auto-tune. The same features and the same
// protocol as the ESP32 version (esp32_robot_V_9_7), made to fit the Nano.
//
// Board "Arduino Nano", processor "ATmega328P" (try "ATmega328P (Old Bootloader)" if the upload fails).
// Libraries: Servo, Wire, EEPROM (all come with the Arduino IDE).
// Link: HC-05 on D0 / D1 at 115200 baud, or the USB cable. THE HC-05 MUST BE DISCONNECTED FROM D0 / D1 WHILE UPLOADING.
//
// Files of this sketch (they are included below in this order):
//   config.h      settings you may change, pins, limits
//   frame.h       numbers, frames and the serial queue (no printf on the Nano)
//   settings.h    values kept in the EEPROM, changeable from the dashboard
//   state.h       everything that changes while running
//   motors.h      wheels (L298N), servos, speed ramp
//   gyro.h        MPU6050 and calibration
//   protocol.h    the text protocol: reports and commands
//   control.h     the gyro control (snap turn, straight hold, steering)
//
// Safety: nothing moves until the dashboard arms the output. No command for 400 ms stops the wheels,
// and after 3 s without any frame the output is disarmed.
//
// NOT TESTED on the real robot: wheels in the air first, then on the floor at a low speed.
#include <Arduino.h>
#include <Wire.h>

#include "config.h"
#include "frame.h"
#include "settings.h"
#include "state.h"
#include "motors.h"
#include "gyro.h"
#include "protocol.h"
#include "control.h"

// ---------------------------------------------------------------- setup
void setup() {
  pinMode(LED_PIN, OUTPUT);
  isTower = !strcmp(ROBOT_TYPE, "tower");
  motorsInit();  // motors off; the servos stay limp until the first armed command

  Serial.begin(LINK_BAUD);
  loadSettings();
  gyroInit();
  startCalibration();
  blinkCount = 3;
}

// ---------------------------------------------------------------- loop pieces
// Armed and the dashboard is talking: drive. Otherwise the wheels stop at once and the servos hold.
void updateOutputs(float dt, bool live) {
  if (!live) {
    controlMode = hold > 0 && imuOk && !gyroCalibrating ? 1 : 0;
    if (speedLeft != 0 || speedRight != 0 || holding) stopWheels();
    return;
  }
  drive(dt);
  servoGoto(0, (int)map(cmdGrip, 0, 100, (int)go, (int)gc));
  if (isTower) {
    liftPosition = constrain(liftPosition + cmdLift * LIFT_RATE * dt, 0.0f, 100.0f);
    servoGoto(1, (int)map((int)liftPosition, 0, 100, LIFT_MIN_DEG, LIFT_MAX_DEG));
  }
}

// The learned balance is written to the EEPROM when the robot stands still (and only when it changed).
void saveBalanceIfStill() {
  if (speedLeft == 0 && speedRight == 0 && fabsf(bal - balSavedInEeprom) > 0.3f) {
    saveSetting(settingIndex("bal"));
    balSavedInEeprom = bal;
  }
}

// The link talks when a valid frame came in the last 3 s.
bool linkAlive(uint32_t now) { return lastRxMs && now - lastRxMs < LINK_LOST_MS; }

void sendReports(uint32_t now) {
  if (!linkAlive(now)) return;
  if (now - lastTelemetryMs >= 100) {
    lastTelemetryMs = now;
    sendTelemetry();
  }
  uint32_t holdPeriod = turnActive ? HOLD_REPORT_FAST_MS : HOLD_REPORT_MS;
  if (now - lastHoldReportMs >= holdPeriod) {
    lastHoldReportMs = now;
    sendControlState();
  }
}

// LED: on while the dashboard is talking; fast blink = armed but no commands; a few blinks for events.
void updateLed(uint32_t now, bool failsafe) {
  static uint32_t lastStepMs;
  static int step;
  if (blinkCount && now - lastStepMs > 150) {
    lastStepMs = now;
    step++;
    if (step >= blinkCount * 2) blinkCount = step = 0;
  }
  bool on;
  if (blinkCount) on = step % 2 == 0;
  else if (armed && failsafe) on = (now / 100) % 2;
  else on = (int32_t)(ledUntilMs - now) > 0 || linkAlive(now);
  digitalWrite(LED_PIN, on);
}

// ---------------------------------------------------------------- loop
void loop() {
  static uint32_t lastControlMs;
  uint32_t now = millis();

  readLink(handleLine);

  bool failsafe = now - lastCmdMs > FAILSAFE_MS;
  if (armed && !linkAlive(now)) disarm();  // the link is gone: do not stay armed
  bool live = armed && !failsafe;

  updateGyro(now);
  if (now - lastControlMs >= CONTROL_PERIOD_MS) {
    float dt = (now - lastControlMs) * 1e-3f;
    if (dt > 0.1f) dt = 0.1f;  // after a long pause (start-up) take one normal step
    lastControlMs = now;
    updateOutputs(dt, live);
    servoStep(dt);
  }
  saveBalanceIfStill();
  sendReports(now);
  txPump();
  updateLed(now, failsafe);
}
