"""Settings that are remembered between runs (which robot, auto-reconnect, speed without RT)."""

import json

from robot_station import simulation
from robot_station.config import TRANSPORTS


class SettingsMixin:
    """Settings that are remembered between runs (which robot, auto-reconnect, speed without RT)."""

    def load_settings(self):
        """Read the remembered settings; a missing or damaged file is ignored."""
        try:
            with open(self.settings_path) as f:
                d = json.load(f)
        except Exception:
            return
        if d.get('transport') in dict(TRANSPORTS):
            self.transport_kind = d['transport']
        for k in ('port', 'ble_addr', 'ble_name'):
            if isinstance(d.get(k), str):
                setattr(self, k, d[k])
        if isinstance(d.get('auto_reconnect'), bool):
            self.auto_reconnect = d['auto_reconnect']
        if isinstance(d.get('lift_invert'), bool):
            self.lift_invert = d['lift_invert']
        if isinstance(d.get('slow_cm'), (int, float)):
            self.sim.slow_cm = max(10.0, min(simulation.MAX_SPEED, float(d['slow_cm'])))

    def save_settings(self):
        """Write the remembered settings (failure is ignored: they are only a convenience)."""
        try:
            with open(self.settings_path, 'w') as f:
                json.dump(
                    dict(
                        transport=self.transport_kind,
                        port=self.port,
                        ble_addr=self.ble_addr,
                        ble_name=self.ble_name,
                        auto_reconnect=self.auto_reconnect,
                        lift_invert=self.lift_invert,
                        slow_cm=self.sim.slow_cm,
                    ),
                    f,
                )
        except Exception:
            pass
