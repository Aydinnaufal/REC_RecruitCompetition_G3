"""Driving: what the sticks ask of the wheels, the picture data, and the per-frame update of the link."""

import math

from robot_station import comms
from robot_station.config import MONITOR


class DriveMixin:
    """Driving: what the sticks ask of the wheels, the picture data, and the per-frame update of the link."""

    def command_from_sim(self):
        """What the sticks ask of the wheels, straight (the simulated robot's lag is NOT in the way). During a snap turn the target heading goes to
        the robot, which turns to it with its own gyro."""
        s, t = self.sim, self.sim.tower
        lift = -t.lift_cmd if self.lift_invert else t.lift_cmd  # the lift servo may be mounted the other way round
        hdg = math.degrees(s.snap_target) if (s.follow and s.snapping) else None
        cmd = comms.Command(
            s.raw_l * 100, s.raw_r * 100, t.pad_cmd * 100, lift * 100, True, hdg
        )
        if self.pid_test is not None:  # a step test from the PID page overrides the wheels
            self.apply_step_test(cmd)
        return cmd

    def tick_snap_timeout(self):
        """Tell the person when a snap turn was given up because it took too long."""
        if self.sim.snap_timed_out:
            self.sim.snap_timed_out = False
            self.link.say('err', 'turn timed out: it did not reach the angle, the controls are free again')

    def pre_drive(self):
        """Call before sim.drive each frame: with fresh telemetry the picture and the compass follow the real robot's gyro."""
        self.tick_snap_timeout()
        t = self.link.telemetry
        if self.telemetry_ok():
            self.sim.follow_robot(
                True, t.get('yaw', 0.0), t.get('gz', 0.0), t.get('vl', 0), t.get('vr', 0)
            )
        else:
            self.sim.follow_robot(False)

    def tick_link(self, dt=1 / 60.0):
        """One frame of link work: send the command, run the Tune page, read the robot, reconnect, sample the PID history."""
        self.link.set_command(self.command_from_sim())
        self.tick_tune(dt)
        self.link.update()
        self.tick_reconnect()
        self.sample_hist()
        self.tick_autotune()
        self.tick_scan()

    def using_robot(self):
        """True when the Monitor picture comes from the real robot instead of the simulation."""
        return self.mode == MONITOR and self.source == 'robot'

    def telemetry_ok(self):
        """True when the robot is connected and its telemetry is fresh (under a second old)."""
        return (
            bool(self.link.telemetry)
            and self.link.connected
            and (self.link.telemetry_age() or 0) < 1.0
        )

    def state(self):
        """The picture data: from the simulation, or built from the robot's telemetry."""
        if not self.using_robot():
            return self.sim.snapshot()
        l = self.link
        tel = (
            dict(l.telemetry)
            if l.telemetry and l.connected
            else dict(yaw=0.0, gz=0.0, vl=0, vr=0, grip=0, lift=0)
        )
        age = l.telemetry_age()
        if age is not None and age > 0.5:
            tel['vl'] = tel['vr'] = 0
        return self.pose.snapshot(tel, self.clock())
