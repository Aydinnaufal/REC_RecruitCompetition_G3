"""Auto-tune on the PID page: the dashboard side of ``robot_station.autotune``.

The tuner itself (``autotune/tuner.py``) only decides what to test and which gains to try. This
mixin is the part that touches the robot. It repeats, once per test::

    rest   wait until the robot stands still
    apply  send the gains for the next test (CFG frames) and wait until the robot reports them
    run    run the test (a step test of the PID page); the robot moves
    ...    when it ends, give the recorded rows to the tuner, which measures them and picks the
           next gains

It stops at once, and leaves the best gains measured so far in the robot, when the output is
disarmed, E-STOP is pressed, a stick is moved, the page is left or the robot stops reporting.
"""

from robot_station.autotune import AutoTuner, TuneSettings
from robot_station.config import PID

REST_RATE_DPS = 4.0  # the robot counts as standing still below this turn rate ...
REST_TIME_S = 0.4  # ... for this long
APPLY_TIMEOUT_S = 2.0  # the robot must report the new gains within this time
GAIN_TOLERANCE = 0.006  # the robot reports gains with 2 decimals

# What the "Tune:" button cycles through: (key, label).
WHAT_OPTIONS = [('all', 'TURN + HOLD'), ('turn', 'TURN only'), ('hold', 'HOLD only')]
MIN_CYCLES, MAX_CYCLES = 1, 12


class AutotuneMixin:
    """Runs an AutoTuner on the real robot from the PID page."""

    def _init_autotune(self):
        self.autotune = None  # the AutoTuner of the current or the last run
        self.autotune_phase = 'idle'  # idle, rest, apply or run
        self.autotune_cycles = 4  # tests per stage (chosen on the page)
        self.autotune_what = 'all'  # 'all', 'turn' or 'hold'
        self.autotune_last = ''  # the tuner's last message
        self._at_request = None  # the TestRequest being prepared or run
        self._at_rest_since = None
        self._at_applied_at = None
        self._at_sent_keys = []
        self._at_test = None  # (start time, start heading) of the running test

    # ---------------------------------------------------------------- the page's controls
    @property
    def autotune_running(self):
        """True from pressing Auto-tune until it finishes or is stopped."""
        return self.autotune_phase != 'idle'

    def set_autotune_cycles(self, value):
        """Spin box: tests per stage."""
        self.autotune_cycles = int(max(MIN_CYCLES, min(MAX_CYCLES, round(value))))

    def next_autotune_what(self):
        """Button: cycle through TURN + HOLD, TURN only, HOLD only."""
        keys = [k for k, _ in WHAT_OPTIONS]
        self.autotune_what = keys[(keys.index(self.autotune_what) + 1) % len(keys)]

    def autotune_what_label(self):
        """Text of the button that chooses what to tune."""
        return dict(WHAT_OPTIONS)[self.autotune_what]

    def autotune_toggle(self):
        """Start button: start, or stop when already running."""
        if self.autotune_running:
            self.autotune_stop('stopped by the person')
        else:
            self.autotune_start()

    # ---------------------------------------------------------------- start / stop
    def autotune_start(self):
        """Begin. The output must be armed, the robot must send PID data and the gyro hold must be on."""
        link = self.link
        if self.mode != PID:
            return
        if not (link.armed and self.hold_fresh()):
            link.say('err', 'auto-tune: connect and ARM OUTPUT first')
            return
        if not self.hcfg('hold'):
            link.say('err', 'auto-tune: switch Gyro hold ON first')
            return
        if self.pid_test is not None:
            link.say('err', 'auto-tune: wait for the step test to end')
            return
        gains = {key: self.hcfg(key) for key in ('skp', 'skd', 'kp', 'kd', 'ki')}
        if any(value is None for value in gains.values()):
            link.say(
                'err', 'auto-tune: the robot did not report its gains: flash esp32_robot_V_9_7'
            )
            return

        settings = TuneSettings(
            cycles=self.autotune_cycles,
            tune_turn=self.autotune_what in ('all', 'turn'),
            tune_hold=self.autotune_what in ('all', 'hold'),
        )
        self.autotune = AutoTuner(settings, gains)
        self.autotune_phase = 'rest'
        self._at_request = self._at_rest_since = None
        self.autotune_last = ''
        link.say(
            'sys',
            'auto-tune started: %s, %d cycles per stage. Keep clear: the robot will turn and drive about half a metre.'
            % (self.autotune_what_label(), settings.cycles),
        )

    def autotune_stop(self, reason='stopped'):
        """Stop at once. The robot keeps the best gains measured so far."""
        if not self.autotune_running:
            return
        self.autotune.abort(reason)
        self._autotune_finish()

    def _autotune_finish(self):
        """Put the best gains in the robot, say what changed, go back to idle."""
        tuner = self.autotune
        if self.pid_test is not None:
            self.pid_cancel('stopped')
        self._apply_gains(tuner.final_gains(), force=())
        self.autotune_phase = 'idle'
        self._at_request = None
        self.autotune_last = tuner.summary()
        if tuner.aborted:
            self.link.say('err', 'auto-tune stopped: ' + tuner.aborted)
        self.link.say('sys', 'auto-tune: ' + tuner.summary())

    # ---------------------------------------------------------------- every frame
    def tick_autotune(self):
        """Call every frame; does nothing unless an auto-tune is running."""
        if not self.autotune_running:
            return
        link, tuner = self.link, self.autotune
        if not link.armed:
            return self.autotune_stop('the output was disarmed')
        if not self.hold_fresh():
            return self.autotune_stop('lost the robot')
        if self.mode != PID:
            return self.autotune_stop('left the PID page')
        if tuner.finished:
            return self._autotune_finish()

        if self.autotune_phase == 'rest':
            self._autotune_rest()
        elif self.autotune_phase == 'apply':
            self._autotune_apply()
        elif self.autotune_phase == 'run':
            self._autotune_run()

    def _robot_is_still(self):
        """True when the wheels are stopped and the robot is not turning."""
        t = self.link.telemetry
        return not t.get('vl') and not t.get('vr') and abs(t.get('gz', 0.0)) < REST_RATE_DPS

    def _autotune_rest(self):
        """Wait until the robot stands still, then send the gains of the next test."""
        now = self.link.clock()
        if not self._robot_is_still():
            self._at_rest_since = None
            return
        if self._at_rest_since is None:
            self._at_rest_since = now
        if now - self._at_rest_since < REST_TIME_S:
            return
        self._at_request = self.autotune.next_test()
        self._at_sent_keys = self._apply_gains(self._at_request.gains, force=self._at_request.force)
        self._at_applied_at = now
        self.autotune_phase = 'apply'
        self.link.say('sys', 'auto-tune: ' + self._at_request.description)

    def _autotune_apply(self):
        """Wait until the robot reports the new gains, then start the test."""
        link, request = self.link, self._at_request
        report = link.hold
        reported = report['at'] > self._at_applied_at + 0.02
        if reported and all(
            abs(report[k] - request.gains[k]) <= GAIN_TOLERANCE for k in self._at_sent_keys
        ):
            started = self.pid_start(
                request.kind,
                deg=request.deg,
                speed=request.speed,
                duration=request.duration,
                auto=True,
            )
            if not started:
                return self.autotune_stop('the test could not start')
            self._at_test = (self.pid_test['t0'], self.pid_test['y0'])
            self.autotune_phase = 'run'
        elif link.clock() - self._at_applied_at > APPLY_TIMEOUT_S:
            self.autotune_stop(
                'the robot did not take the new gains (is esp32_robot_V_9_7 flashed?)'
            )

    def _autotune_run(self):
        """While the test runs do nothing; when it ended give the rows to the tuner."""
        if self.pid_test is not None:
            return
        if self.pid_ended != 'done':
            return self.autotune_stop(
                'the test was interrupted (stick moved, output disarmed or page left)'
            )
        t0, start_yaw = self._at_test
        message = self.autotune.report(list(self.hist), t0, start_yaw)
        self.autotune_last = message
        self.link.say('sys', 'auto-tune: ' + message)
        self.autotune_phase = 'rest'
        self._at_rest_since = None
        if self.autotune.finished:
            self._autotune_finish()

    # ---------------------------------------------------------------- talking to the robot
    def _apply_gains(self, gains, force):
        """Send every gain that differs from what the robot reports (and those in ``force``). Returns the keys sent."""
        sent = []
        for key, value in gains.items():
            current = self.hcfg(key)
            if key in force or current is None or abs(current - value) > 1e-6:
                self.set_hcfg(key, value)
                sent.append(key)
        return sent

    # ---------------------------------------------------------------- what the page shows
    def autotune_status_lines(self):
        """(headline, detail) for the PID page: what the tuner is doing and what it said last."""
        tuner = self.autotune
        if tuner is None:
            return (
                'Auto-tune: arm the output, then press the button. The robot turns and drives a little.',
                '',
            )
        done, planned = tuner.progress
        if self.autotune_running:
            doing = {
                'rest': 'waiting for the robot to stand still',
                'apply': 'sending the new gains',
                'run': 'testing',
            }[self.autotune_phase]
            head = 'AUTO-TUNE  %s  test %d of at most %d: %s' % (
                tuner.stage_name,
                done + 1,
                planned,
                doing,
            )
        else:
            head = 'AUTO-TUNE finished.  ' + tuner.summary()
        return head, (
            self.autotune_last
            if self.autotune_running
            else (tuner.messages[-2] if len(tuner.messages) > 1 else '')
        )
