"""The run timer in the top bar: it waits for the first touch of any control, then runs."""


class TimerMixin:
    """The run timer in the top bar: it waits for the first touch of any control, then runs."""

    def _init_timer(self):
        self.timer_on = False  # shown in the top bar
        self.timer_state = 'armed'  # armed (waits for any input), running, paused
        self.timer_t = 0.0  # seconds

    def timer_toggle(self):
        """Show or hide the timer; showing it arms it."""
        self.timer_on = not self.timer_on
        self.timer_reset()

    def timer_reset(self):
        """Zero the timer and wait for the first touch of a control."""
        self.timer_state, self.timer_t = 'armed', 0.0

    def timer_restart(self):
        """Zero the timer and start it at once."""
        self.timer_state, self.timer_t = 'running', 0.0

    def timer_pause(self):
        """Pause or resume a running timer (P key)."""
        if self.timer_on and self.timer_state in ('running', 'paused'):
            self.timer_state = 'paused' if self.timer_state == 'running' else 'running'

    def timer_update(self, dt, st):
        """Call every frame: the first input starts an armed timer; a running one counts."""
        if not self.timer_on:
            return
        if self.timer_state == 'armed' and st.any_input():
            self.timer_state = 'running'
        if self.timer_state == 'running':
            self.timer_t += dt

    def timer_text(self):
        """The time as m:ss.t."""
        return '%d:%02d.%d' % (
            int(self.timer_t // 60),
            int(self.timer_t % 60),
            int((self.timer_t * 10) % 10),
        )
