"""The App: owns all state of the dashboard and combines the mixins that each handle one part of it."""

import time

from robot_station import comms
from robot_station import rendering
from robot_station import simulation
from robot_station.config import GAME, MONITOR, PID, SETTINGS_FILE, TUNE, VP
from .autotune import AutotuneMixin
from .connection import ConnectionMixin
from .drive import DriveMixin
from .pid_page import PidPageMixin
from .settings import SettingsMixin
from .timer import TimerMixin
from .tune_page import TunePageMixin


class App(
    SettingsMixin,
    TimerMixin,
    TunePageMixin,
    ConnectionMixin,
    DriveMixin,
    PidPageMixin,
    AutotuneMixin,
):
    """Everything the screen shows and does: the simulator, mode and views, the timer, and the link to the robot."""

    def __init__(self, clock=time.monotonic, settings_path=SETTINGS_FILE):
        """Create the simulator, the link and all page state; load the remembered settings."""
        self.clock = clock
        self.settings_path = settings_path

        # The parts every page uses.
        self.sim = simulation.Robot()  # the simulated robot
        self.link = comms.Link(clock)  # the connection to the real robot
        self.pose = comms.TelemetryPose()  # position of the real robot, dead-reckoned
        self.look = rendering.Look()  # camera and overlay options

        # Which page and view is shown.
        self.mode = GAME
        self.view = {GAME: 'arena', MONITOR: 'iso'}  # the picture view chosen in each mode
        self.tab = 'link'  # tab of the right column
        self.source = 'sim'  # Monitor: picture from the simulation or from the robot
        self.fullscreen = False

        # Each mixin sets up its own state.
        self._init_timer()
        self._init_tune_page()
        self._init_pid_page()
        self._init_connection()
        self._init_autotune()

        self.load_settings()
        self.refresh_ports()

    def views(self):
        """The picture views that exist in the current mode."""
        return rendering.VIEWS_GAME if self.mode == GAME else rendering.VIEWS_MONITOR

    def set_mode(self, m):
        """Switch page. Leaving Tune stops the motors, and any running step test is cancelled."""
        if m != self.mode:
            if self.mode == TUNE:
                self.tune_stop()
            self.autotune_stop('left the PID page')
            self.pid_cancel()
            self.mode = m
            self.sim.set_arena(m == GAME)  # Monitor: no arena, no cubes, no collisions
            if m == MONITOR:
                self.sim.reset_robot()

    def cur_view(self):
        """The picture view of the current mode."""
        return self.view[self.mode]

    def set_view(self, v):
        """Choose the picture view of the current mode."""
        self.view[self.mode] = v

    def next_view(self):
        """Cycle to the next picture view (V key)."""
        v = self.views()
        self.set_view(v[(v.index(self.cur_view()) + 1) % len(v)])

    def next_drive_mode(self):
        """Cycle the drive mode (T key)."""
        self.sim.mode = simulation.MODES[
            (simulation.MODES.index(self.sim.mode) + 1) % len(simulation.MODES)
        ]

    def in_scene(self, pos):
        """True when the canvas position is inside the 3D picture (Game and Monitor only)."""
        return (
            self.mode not in (TUNE, PID)
            and pos is not None
            and VP[0] <= pos[0] < VP[0] + VP[2]
            and VP[1] <= pos[1] < VP[1] + VP[3]
        )

    def drag(self, dx, dy):
        """Mouse drag in the picture: switch to the free camera and turn it."""
        if self.cur_view() != 'free':
            self.set_view('free')
        self.look.drag(dx, dy)

    def toggle_fullscreen(self):
        """Replaced by main() with the real window switch."""
        self.fullscreen = not self.fullscreen  # main() replaces this with the real window switch

    def zero(self):
        """Re-zero the heading of the simulation and of the robot picture."""
        self.sim.zero()
        if self.link.telemetry:
            self.pose.zero(self.link.telemetry)
        self.pose.reset()
