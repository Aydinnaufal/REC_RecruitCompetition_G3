"""Finding the robot, opening and keeping the link, and arming the output (button, BACK on the controller, E-STOP)."""

from robot_station import comms


STALE_DROP_S = 0.8  # a link silent for 0.6 s is STALE; after this much longer it is dropped and reconnected
NO_REPLY_DROP_S = 3.0  # connected but the robot never answered the handshake
RETRY_S = 0.5  # pause before the reconnect try


class ConnectionMixin:
    """Finding the robot, opening and keeping the link, and arming the output (button, BACK on the controller, E-STOP)."""

    def _init_connection(self):
        self.transport_kind = 'ble'  # 'ble' or 'serial'
        self.port = ''  # chosen COM port
        self.ports = []  # COM ports found
        self.ble_addr = ''  # chosen Bluetooth device
        self.ble_name = ''
        self.ble = None  # the running Bluetooth scan
        self.ble_msg = ''  # what the last scan found
        self._ble_done = True  # the scan result was already handled
        self.auto_reconnect = True
        self.lift_invert = True  # reverse the lift stick direction (the robot's lift servo is mounted the other way round)
        self.want_link = False  # the person wants a link (so a drop is reconnected)
        self.retries = 0
        self._retry_at = None  # when the next reconnect try is due
        self._stuck_at = None  # since when the link has been silent
        self._back_prev = False  # BACK button state of the last frame

    def refresh_ports(self):
        """Re-list the COM ports and keep the chosen one if it is still there."""
        self.ports = comms.list_serial_ports()
        names = [p.device for p in self.ports]
        if self.port not in names:
            self.port = names[0] if names else ''

    def scanning(self):
        """True while a Bluetooth scan is running."""
        return bool(self.ble and self.ble.running)

    def refresh(self):
        """Refresh / Scan: re-list the COM ports, or scan for Bluetooth LE devices."""
        if self.transport_kind == 'serial':
            self.refresh_ports()
        elif not self.scanning() and not self.link.active:
            self.ble = comms.BleScanner(5.0)
            self._ble_done, self.ble_msg = False, ''
            self.ble.start()

    def tick_scan(self):
        """Call every frame: when a scan has finished, remember the robot it found and tell the person."""
        b = self.ble
        if not b or b.running or self._ble_done:
            return
        self._ble_done = True
        if b.error:
            self.ble_msg = b.error
            self.link.say('err', 'scan: ' + b.error)
            return
        robot = b.robot()
        if robot:
            self.ble_addr, self.ble_name = robot.address, robot.name
            self.ble_msg = 'found %s: press Connect' % robot.name
        else:
            self.ble_msg = (
                '%d device(s), none named %s...: is the robot on and flashed with BT_MODE = BT_BLE?'
                % (len(b.devices), comms.ROBOT_NAME_PREFIX)
            )
        self.link.say('sys', 'scan: ' + self.ble_msg)

    def target_options(self):
        """The (value, label) list for the device dropdown: COM ports, or the Bluetooth devices found."""
        if self.transport_kind == 'serial':
            return [
                (p.device, ('%s  %s' % (p.device, p.description))[:40]) for p in self.ports
            ] or [('', 'no ports found')]
        opts = [
            (d.address, '%s %s' % (d.name or '?', '' if d.rssi is None else '%d dBm' % d.rssi))
            for d in (self.ble.devices if self.ble else [])
        ]
        if self.ble_addr and self.ble_addr not in [a for a, _ in opts]:
            opts.insert(
                0, (self.ble_addr, self.ble_name or self.ble_addr)
            )  # the robot used last time, no scan needed
        return opts or [('', 'press Scan')]

    def target_value(self):
        """The port or Bluetooth address that Connect will use."""
        return self.port if self.transport_kind == 'serial' else self.ble_addr

    def set_target(self, v):
        """Choose the port or Bluetooth device in the dropdown."""
        if self.transport_kind == 'serial':
            self.port = v
        else:
            self.ble_addr = v
            self.ble_name = next(
                (d.name for d in (self.ble.devices if self.ble else []) if d.address == v),
                self.ble_name,
            )

    def set_transport(self, k):
        """Switch between Bluetooth LE and the USB cable."""
        self.transport_kind = k
        if k == 'serial':
            self.refresh_ports()

    def toggle_connection(self):
        """Connect, or disconnect when already linked. Disconnecting by hand also stops auto-reconnect."""
        if self.link.active:
            self.want_link = False  # the person disconnected: do not reconnect
            self.link.disconnect()
            return
        self.want_link = True
        self.start_link()

    def start_link(self):
        """Open the link to the chosen robot (does nothing but explain if nothing is chosen)."""
        if not self.target_value():
            msg = (
                'no COM port: plug the USB cable in and press Refresh'
                if self.transport_kind == 'serial'
                else 'no device selected: press Scan, the robot is called REC-Robot'
            )
            self.link.say('err', msg)
            self.link.last_error = msg
            self.link.state = comms.Link.ERROR
            self.want_link = False
            return
        k = self.transport_kind
        self.link.connect(
            lambda: (
                comms.BleTransport(self.ble_addr, self.ble_name)
                if k == 'ble'
                else comms.SerialTransport(self.port)
            )
        )
        self.pose = comms.TelemetryPose()
        self.save_settings()

    def tick_reconnect(self):
        """The link dropped (robot reset, out of range, Bluetooth hiccup) and the person did not disconnect: try again after a short pause. A new link is always disarmed."""
        l, now = self.link, self.link.clock()
        if not (self.auto_reconnect and self.want_link):
            self._retry_at = self._stuck_at = None
            return
        if l.state in (
            comms.Link.STALE,
            comms.Link.NO_REPLY,
        ):  # silent link: drop it at once so the retry below starts clean (a stale link rarely comes back by itself)
            self._stuck_at = now if self._stuck_at is None else self._stuck_at
            limit = STALE_DROP_S if l.state == comms.Link.STALE else NO_REPLY_DROP_S
            if now - self._stuck_at > limit:
                l.say('sys', 'link stale: disconnecting and reconnecting')
                l.disconnect(quiet=True)
                self._stuck_at = None
            return
        self._stuck_at = None
        if l.state in (comms.Link.DISCONNECTED, comms.Link.ERROR) and not self.scanning():
            if self._retry_at is None:
                self._retry_at = now + RETRY_S
                self.retries += 1
            if now >= self._retry_at:
                self._retry_at = None
                l.say('sys', 'auto-reconnect, attempt %d' % self.retries)
                self.start_link()
        else:
            self._retry_at = None
            if l.state == comms.Link.CONNECTED and self.retries:
                self.retries = 0
                l.say('sys', 'reconnected: the output is DISARMED, press BACK to arm')

    def tick_pad(self, st):
        """Call every frame: a fresh press of BACK on the controller arms or disarms the output."""
        back = bool(st.buttons.get('BACK'))
        if back and not self._back_prev:
            self.back_pressed(st)
        self._back_prev = back

    def cancel_turns(self):
        """Stop every turning process: a snap turn, a PID step test, an auto-tune, and the Tune page's wheel sliders and start-power search."""
        self.sim.cancel_snap()
        self.autotune_stop('BACK')
        self.pid_cancel('stopped')
        self.tune_stop()

    def back_pressed(self, st):
        """BACK stops every turn in progress, then arms or disarms. It arms only when connected and the sticks and D-pad are released; disarming always works."""
        l = self.link
        self.cancel_turns()
        if l.armed:
            self.toggle_arm()  # disarming is always allowed
        elif not (l.connected and self.telemetry_ok()):
            l.say('err', 'BACK: not connected to the robot yet')
        elif abs(st.lx) + abs(st.ly) + abs(st.rx) + abs(st.ry) > 0.2 or st.dpad != (0, 0):
            l.say('err', 'BACK: release the sticks and D-pad first, then press BACK')
        else:
            self.toggle_arm()

    def toggle_arm(self):
        """Arm or disarm the output. Arming starts with zero speed on the Tune page."""
        if not self.link.armed:
            self.tune['vl'] = self.tune['vr'] = 0.0
            self.ramp = None
        self.link.armed = not self.link.armed
        self.link.say(
            'sys',
            (
                'output ARMED: the robot now receives drive commands'
                if self.link.armed
                else 'output disarmed: the robot receives zeros'
            ),
        )

    def estop(self):
        """Emergency stop: cancel tests, zero everything and disarm."""
        self.autotune_stop('E-STOP')
        self.tune_stop()
        self.pid_cancel()
        self.link.estop()

    def hint(self):
        """One or two short lines telling the person what to do next."""
        l = self.link
        if self.scanning():
            return 'scanning for Bluetooth LE devices... %d%%' % round(self.ble.progress() * 100)
        if (
            self.auto_reconnect
            and self.want_link
            and l.state in (comms.Link.DISCONNECTED, comms.Link.ERROR)
            and self._retry_at is not None
        ):
            return 'link lost: reconnecting in %.0f s (attempt %d). Press Disconnect to stop.' % (
                max(0.0, self._retry_at - l.clock()),
                self.retries,
            )
        if l.state == comms.Link.CONNECTING:
            return 'opening the link... Bluetooth can take up to 10 seconds'
        if l.state == comms.Link.HANDSHAKE:
            return 'link open, asking the robot to say HELLO...'
        if l.state == comms.Link.NO_REPLY:
            return 'open but the robot is silent: powered on? V_5_0 firmware running?'
        if l.state == comms.Link.ERROR:
            return l.last_error
        if l.state == comms.Link.STALE:
            return 'nothing heard for a moment: out of range, or the robot restarted?'
        if l.state == comms.Link.DISCONNECTED:
            if self.transport_kind == 'serial':
                return (
                    'press Connect'
                    if self.port
                    else 'no COM ports found: plug the USB cable in and press Refresh'
                )
            return self.ble_msg or (
                'press Connect (robot: %s)' % (self.ble_name or self.ble_addr)
                if self.ble_addr
                else 'press Scan: the robot shows up as REC-Robot'
            )
        return ''
