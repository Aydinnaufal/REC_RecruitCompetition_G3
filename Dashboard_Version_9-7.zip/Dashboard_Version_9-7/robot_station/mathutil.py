"""Small maths helpers shared by the simulation and the 3D drawing."""

import math


def clamp(v, lo, hi):
    """Limit v to lo..hi."""
    return max(lo, min(hi, v))


def wrap_pi(a):
    """Wrap an angle in radians to -pi..pi."""
    a = (a + math.pi) % (2 * math.pi) - math.pi
    return math.pi if a <= -math.pi + 1e-12 else a
