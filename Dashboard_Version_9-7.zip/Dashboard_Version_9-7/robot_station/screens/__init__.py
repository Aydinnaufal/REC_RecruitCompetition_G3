"""Drawing and widget layout of every page."""

from .text_utils import mmss, wrap_hint
from .top_bar import draw_topbar
from .controller_panel import draw_left
from .arena_page import draw_centre
from .tune_page import draw_tune
from .plots import plot, draw_orient
from .pid_page import draw_pid
from .link_panel import draw_right, draw_link
from .compose import refresh_dynamic, render
from .widget_screen import Screen
