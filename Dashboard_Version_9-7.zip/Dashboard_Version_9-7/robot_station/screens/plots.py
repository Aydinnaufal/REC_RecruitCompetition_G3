"""Reusable drawings for the PID page: a scrolling time plot and the orientation picture."""

import math

import pygame

from robot_station import ui
from robot_station.config import AMBER
from robot_station.ui.canvas import text
from robot_station.ui.theme import ACCENT, MUTED


def plot(canvas, fonts, rect, series, now, win, lo=None, hi=None, labels=None, minspan=10.0):
    """A scrolling line graph. series = [(colour, [(t, v), ...])]; the newest sample is at the right edge. lo / hi fixed, or None = automatic."""
    x, y, w, h = rect
    pygame.draw.rect(canvas, (22, 26, 32), rect, border_radius=4)
    pts = [(c, [(t, v) for t, v in data if now - win <= t <= now + 0.05]) for c, data in series]
    vals = [v for _, p in pts for _, v in p]
    if lo is None:
        a, b = (min(vals), max(vals)) if vals else (-1.0, 1.0)
        a, b = min(a, 0.0), max(b, 0.0)
        if b - a < minspan:
            m = (a + b) / 2
            a, b = m - minspan / 2, m + minspan / 2
        pad = (b - a) * 0.08
        lo, hi = a - pad, b + pad
    Y = lambda v: y + h - (max(lo, min(hi, v)) - lo) / (hi - lo) * h
    for k in range(5):  # horizontal grid with the value on the left
        gy = y + h * k / 4.0
        pygame.draw.line(canvas, (44, 50, 58), (x, gy), (x + w, gy), 1)
        v = hi - (hi - lo) * k / 4.0
        lab = labels[k] if labels else ('%+.0f' % v if abs(hi - lo) >= 8 else '%+.1f' % v)
        text(
            canvas,
            fonts['s'],
            lab,
            (x - 6 - fonts['s'].render(lab, True, MUTED).get_width(), gy),
            MUTED,
            'mid',
        )
    for sec in range(0, int(win) + 1, 2):  # vertical grid every 2 s
        gx = x + w - sec / win * w
        pygame.draw.line(canvas, (36, 42, 50), (gx, y), (gx, y + h), 1)
    if lo < 0 < hi:
        pygame.draw.line(canvas, (110, 120, 132), (x, Y(0)), (x + w, Y(0)), 1)
    for c, p in pts:
        xy = [(x + w - (now - t) / win * w, Y(v)) for t, v in p]
        for a, b in zip(xy, xy[1:]):
            pygame.draw.line(canvas, c, a, b, 2)
    text(canvas, fonts['s'], 'last %d s' % win, (x + w - 4, y + h - 15), MUTED, 'tr')
    if not vals:
        text(canvas, fonts['s'], 'no data yet', (x + w // 2, y + h // 2), MUTED, 'center')


def draw_orient(canvas, fonts, cx, cy, R, yaw, target, mode, vl, vr, live):
    """Top view of the robot at its real heading. Up = where it faced at power-up (yaw 0), turning LEFT raises yaw. Amber = the heading the PID wants."""
    pygame.draw.circle(canvas, (26, 30, 36), (cx, cy), R)
    pygame.draw.circle(canvas, ui.LINE, (cx, cy), R, 2)
    P = lambda a, r: (cx - r * math.sin(math.radians(a)), cy - r * math.cos(math.radians(a)))
    for a in range(0, 360, 15):
        pygame.draw.line(
            canvas,
            (150, 160, 172) if a % 45 == 0 else (84, 92, 104),
            P(a, R - 1),
            P(a, R - (11 if a % 45 == 0 else 6)),
            2 if a % 90 == 0 else 1,
        )
    for a, lab in ((0, '0'), (90, '+90'), (180, '180'), (270, '-90')):
        text(canvas, fonts['s'], lab, P(a, R - 24), MUTED, 'center')
    if live and mode > 0:
        err = (target - yaw + 180) % 360 - 180
        n = max(2, int(abs(err) / 4))
        wedge = [(cx, cy)] + [P(yaw + err * k / n, R - 30) for k in range(n + 1)]
        pygame.draw.polygon(canvas, (86, 62, 28), wedge)
        pygame.draw.line(canvas, AMBER, (cx, cy), P(target, R - 8), 2)
        pygame.draw.circle(canvas, AMBER, [int(v) for v in P(target, R - 8)], 6)
    a = math.radians(yaw)
    fx, fy, rx, ry = -math.sin(a), -math.cos(a), math.cos(a), -math.sin(a)
    L = lambda lx, ly: (cx + lx * rx + ly * fx, cy + lx * ry + ly * fy)
    for side, v in (
        (-1, vl),
        (1, vr),
    ):  # the wheels glow with their speed: green forward, amber reverse
        col = (60, 70, 80) if abs(v) < 2 else ((60, 200, 140) if v > 0 else AMBER)
        pygame.draw.polygon(
            canvas,
            col,
            [
                L(side * 21 - 4, -16),
                L(side * 21 + 4, -16),
                L(side * 21 + 4, 16),
                L(side * 21 - 4, 16),
            ],
        )
    pygame.draw.polygon(
        canvas,
        (88, 100, 114) if live else (60, 66, 74),
        [L(-17, -22), L(17, -22), L(17, 22), L(-17, 22)],
    )
    pygame.draw.polygon(canvas, ACCENT if live else MUTED, [L(0, 36), L(-12, 14), L(12, 14)])
    pygame.draw.circle(canvas, (255, 255, 255), [int(v) for v in P(yaw, R - 4)], 4)
