"""The strip along the top: title, link light, ARMED sign, round-trip time and timer."""

import pygame

from robot_station import comms
from robot_station import ui
from robot_station.config import CW, M, STATE_COL, VERSION
from robot_station.ui.canvas import text
from robot_station.ui.theme import ACCENT, MUTED, PANEL


def draw_topbar(canvas, fonts, app):
    """The strip along the top."""
    pygame.draw.rect(canvas, PANEL, (M, 6, CW - 2 * M, 48), border_radius=8)
    text(canvas, fonts['l'], 'Robot Station', (24, 10))
    text(canvas, fonts['s'], VERSION, (24, 38), MUTED)
    l = app.link
    ui.led(canvas, (762, 34), l.state != comms.Link.DISCONNECTED, STATE_COL.get(l.state, ui.OK))
    if l.connected and l.stats['rtt_avg'] is not None:
        text(canvas, fonts['s'], '%.0f ms' % l.stats['rtt_avg'], (870, 28), MUTED, 'tr')
    if l.armed:
        pygame.draw.rect(canvas, ui.DANGER, (890, 18, 92, 32), border_radius=8)
        text(canvas, fonts['s'], 'ARMED', (936, 34), (255, 220, 215), 'center')
    if app.timer_on:
        col = {'armed': (240, 200, 90), 'running': ACCENT, 'paused': (240, 150, 90)}[
            app.timer_state
        ]
        text(canvas, fonts['l'], app.timer_text(), (CW - M - 188, 12), col, 'tr')
        text(
            canvas,
            fonts['s'],
            {'armed': 'move any control', 'running': 'running (P)', 'paused': 'paused (P)'}[
                app.timer_state
            ],
            (CW - M - 188, 38),
            MUTED,
            'tr',
        )
