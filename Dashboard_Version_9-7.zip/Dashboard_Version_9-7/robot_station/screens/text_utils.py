"""Small text helpers used by the pages."""

import textwrap


def mmss(t):
    """Seconds as m:ss."""
    return '%d:%02d' % (int(t // 60), int(t % 60))


def wrap_hint(msg, width=44, lines=3):
    """At most `lines` lines; when the text is longer the last line ends in '...' so nothing is cut silently."""
    out = textwrap.wrap(msg or '', width)
    if len(out) > lines:
        out = out[:lines]
        out[-1] = out[-1][: width - 3].rstrip() + '...'
    return out
