"""The PID page: orientation, three live graphs, the tuning controls and the step-test result."""

import textwrap

import pygame

from robot_station import ui
from robot_station.config import AMBER, LX, PAGE, TOP
from robot_station.ui.canvas import text
from robot_station.ui.theme import ACCENT, MUTED, PANEL, TEXT
from .plots import draw_orient, plot
from .text_utils import wrap_hint


def draw_pid(canvas, fonts, app):
    """The PID page. Positions must match the widgets built in Screen.build."""
    pygame.draw.rect(canvas, PANEL, PAGE, border_radius=8)
    text(canvas, fonts['m'], 'PID  |  gyro heading control', (LX + 14, TOP + 8), ACCENT)
    msg, col = app.pid_status()
    text(canvas, fonts['s'], msg, (LX + PAGE[2] - 14, TOP + 10), col, 'tr')
    l = app.link
    h = l.hold if app.hold_fresh() else None
    t = l.telemetry if app.telemetry_ok() else {}
    live = h is not None and bool(t)
    now = l.clock()
    yaw, gz = t.get('yaw', 0.0), t.get('gz', 0.0)
    ui.card(canvas, (LX, 92, 330, 300), 'ORIENTATION  (the real robot, from its gyro)', fonts)
    ui.card(canvas, (LX, 400, 330, 426), 'PID SETTINGS  (kept in the robot)', fonts)
    ui.card(canvas, (354, 92, 690, 190), 'HEADING  (deg)', fonts)
    ui.card(
        canvas,
        (354, 290, 690, 150),
        'ERROR and CORRECTION  (full scale: error +-20 deg, correction +-25 %)',
        fonts,
    )
    ui.card(canvas, (354, 448, 690, 150), 'WHEELS  commanded speed (%)', fonts)
    ui.card(
        canvas, (354, 606, 690, 220), 'STEP TESTS and AUTO-TUNE  (move any stick to stop)', fonts
    )
    mode = int(h['mode']) if h else 0
    tgt = h['target'] if h else yaw
    draw_orient(
        canvas, fonts, LX + 165, 226, 96, yaw, tgt, mode, t.get('vl', 0), t.get('vr', 0), live
    )
    word = ('OFF', 'READY', 'HOLDING THE LINE', 'TURNING TO TARGET')[mode] if h else 'no data'
    text(
        canvas,
        fonts['m'],
        word,
        (LX + 165, 340),
        (MUTED, ui.OK, ui.OK, AMBER)[mode] if h else MUTED,
        'center',
    )
    text(
        canvas,
        fonts['s'],
        'yaw %+7.1f   target %+7.1f   error %+5.1f deg' % (yaw, tgt, (yaw - tgt) if h else 0.0),
        (LX + 165, 362),
        TEXT,
        'center',
    )
    text(
        canvas,
        fonts['s'],
        'turn rate %+6.1f deg/s    balance %s' % (gz, ('%+.2f %%' % h['bal']) if h else '-'),
        (LX + 165, 380),
        MUTED,
        'center',
    )
    W = 12.0
    H = list(app.hist)
    S = lambda key, k=1.0: [(r['t'], r[key] * k) for r in H]
    CY, WH = (90, 200, 230), (240, 150, 60)
    plot(canvas, fonts, (406, 124, 626, 148), [(AMBER, S('target')), (CY, S('yaw'))], now, W)
    text(canvas, fonts['s'], 'yaw', (940, 98), CY)
    text(canvas, fonts['s'], 'target', (980, 98), AMBER)
    plot(
        canvas,
        fonts,
        (406, 322, 626, 108),
        [((235, 235, 240), S('err', 1 / 20.0)), (AMBER, S('corr', 1 / 25.0))],
        now,
        W,
        -1.0,
        1.0,
        ('+20/+25', '', '0', '', '-20/-25'),
    )
    text(canvas, fonts['s'], 'error', (910, 296), (235, 235, 240))
    text(canvas, fonts['s'], 'correction', (960, 296), AMBER)
    plot(
        canvas,
        fonts,
        (406, 480, 626, 108),
        [((60, 200, 140), S('vl')), (WH, S('vr'))],
        now,
        W,
        minspan=40.0,
    )
    text(canvas, fonts['s'], 'left', (940, 454), (60, 200, 140))
    text(canvas, fonts['s'], 'right', (985, 454), WH)
    recent = [x for x in H if x['t'] >= now - 10]
    biggest = '%.1f deg' % max(abs(x['err']) for x in recent) if recent else '-'
    text(canvas, fonts['s'], 'biggest error in the last 10 s: %s' % biggest, (366, 672), TEXT)
    text(
        canvas,
        fonts['s'],
        app.pid_result or 'no test run yet',
        (366, 688),
        AMBER if app.pid_test else TEXT,
    )
    tip = 'Wobble: less Kp, more Kd.  Lean: more Ki.  Overshoot: more Turn damping.  Runs away: Flip gyro.'
    for k, line in enumerate(textwrap.wrap(tip, 98)):
        text(canvas, fonts['s'], line, (366, 708 + k * 15), MUTED)
    draw_autotune_status(canvas, fonts, app)


def draw_autotune_status(canvas, fonts, app):
    """Under the Auto-tune buttons: what the tuner is doing, and what it found last."""
    headline, detail = app.autotune_status_lines()
    text(canvas, fonts['s'], headline[:96], (366, 768), AMBER if app.autotune_running else TEXT)
    for k, line in enumerate(wrap_hint(detail, 94, 3)):
        text(canvas, fonts['s'], line, (366, 785 + k * 14), MUTED)
