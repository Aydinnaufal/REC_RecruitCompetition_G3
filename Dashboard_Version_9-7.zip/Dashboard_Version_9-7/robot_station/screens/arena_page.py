"""The centre column of Game and Monitor: the 3D picture, compass, wheel bars and indicator tiles."""

import math

import pygame

from robot_station import comms
from robot_station import rendering
from robot_station import simulation
from robot_station import ui
from robot_station.config import AMBER, BOT, CWD, CX, GAME, MONITOR, OFF_RED, TOP, VP
from robot_station.ui.canvas import text
from robot_station.ui.theme import ACCENT, MUTED, PANEL, TEXT


def draw_centre(canvas, fonts, cam, scene, app):
    """The centre column of Game and Monitor."""
    sim = app.sim
    pygame.draw.rect(canvas, PANEL, (CX, TOP, CWD, BOT - TOP), border_radius=8)
    d = app.state()
    robot_live = d['source'] == 'robot'
    text(
        canvas,
        fonts['m'],
        (
            'GAME  |  tower robot'
            if app.mode == GAME
            else 'MONITOR  |  tower robot  |  %s' % ('robot' if robot_live else 'sim')
        ),
        (CX + 14, TOP + 8),
        ACCENT if app.mode == MONITOR else MUTED,
    )
    text(
        canvas,
        fonts['s'],
        'drive: %s' % simulation.MODE_LABEL[sim.mode],
        (CX + 14, TOP + 30),
        MUTED,
    )
    if app.mode == GAME:
        rendering.draw_scene(scene, cam, sim, app.cur_view(), app.look)
    else:
        rendering.draw_monitor(scene, cam, d, app.cur_view(), app.look)
    canvas.blit(scene, (VP[0], VP[1]))
    if app.using_robot() and not app.telemetry_ok():
        pygame.draw.rect(
            canvas, (20, 23, 28), (VP[0] + VP[2] // 2 - 150, VP[1] + 14, 300, 28), border_radius=6
        )
        text(
            canvas,
            fonts['s'],
            'NO TELEMETRY: connect on the LINK tab',
            (VP[0] + VP[2] // 2, VP[1] + 28),
            ui.WARN,
            'center',
        )
    y0 = VP[1] + VP[3] + 10
    ui.compass(canvas, fonts, CX + 110, y0 + 92, 78, d['heading'], math.degrees(d['omega']))
    text(
        canvas,
        fonts['s'],
        'ROBOT GYRO' if sim.follow else 'SIMULATION  (no robot data)',
        (CX + 110, y0 + 240),
        ui.OK if sim.follow else MUTED,
        'center',
    )
    x, w = CX + 232, CWD - 244
    ui.labelled_bar(
        canvas,
        fonts,
        x,
        y0 + 2,
        w,
        d['vl'],
        'L wheel',
        '%+4.0f cm/s' % (d['vl'] * simulation.MAX_SPEED),
        centre=True,
    )
    ui.labelled_bar(
        canvas,
        fonts,
        x,
        y0 + 22,
        w,
        d['vr'],
        'R wheel',
        '%+4.0f cm/s' % (d['vr'] * simulation.MAX_SPEED),
        centre=True,
    )
    ui.labelled_bar(
        canvas,
        fonts,
        x,
        y0 + 42,
        w,
        (d['lift'] - simulation.LIFT_MIN) / (simulation.LIFT_MAX - simulation.LIFT_MIN),
        'Box lift',
        '%4.1f cm' % d['lift'],
        color=(60, 200, 190),
    )
    state = 'HOLDING cube' if d['holding'] else ('touching' if d['touching'] else 'free')
    ui.labelled_bar(
        canvas,
        fonts,
        x,
        y0 + 62,
        w,
        d['cmd'],
        'Pad',
        '%3.0f%% %s' % (d['cmd'] * 100, state),
        color=AMBER,
        vw=150,
    )
    ui.labelled_bar(
        canvas,
        fonts,
        x,
        y0 + 82,
        w,
        d['rt'],
        'Speed RT',
        (
            'not reported'
            if robot_live
            else 'cap %2.0f cm/s' % (d['speed_scale'] * simulation.MAX_SPEED)
        ),
        color=(90, 170, 240),
        vw=150,
    )
    text(
        canvas,
        fonts['s'],
        'speed %+5.1f cm/s     x %+7.1f   y %+7.1f' % (d['speed'], d['x'], d['y']),
        (x, y0 + 108),
        TEXT,
    )
    # ---- square indicators: what the controller has switched, readable at a glance
    ty, gap = y0 + 128, 108
    ui.tile(
        canvas,
        fonts,
        x,
        ty,
        'TURN  (LT)',
        sim.turn_on,
        'ON' if sim.turn_on else 'OFF',
        ui.OK,
        OFF_RED,
    )
    snap_on = sim.mode == 'arcade_snap'
    ui.tile(
        canvas,
        fonts,
        x + gap,
        ty,
        'SNAP',
        snap_on,
        ('SPIN' if sim.snapping else 'READY') if snap_on else 'OFF',
        AMBER if sim.snapping else ui.OK,
    )
    hd = app.link.hold if app.hold_fresh() else None  # straight-line hold of the real robot
    if hd is None:
        ui.tile(canvas, fonts, x + 2 * gap, ty, 'GYRO HOLD', False, '--')
    else:
        mode = int(hd['mode'])
        word = ('OFF', 'READY', 'LOCK', 'TURN')[mode]
        ui.tile(
            canvas,
            fonts,
            x + 2 * gap,
            ty,
            'GYRO HOLD',
            mode > 0,
            word,
            AMBER if (mode == 3 or (mode == 2 and abs(hd['corr']) > 12)) else ui.OK,
        )
    fl = app.link.telemetry.get('flags', 0) if app.telemetry_ok() else None  # the gyro itself
    if fl is None:
        ui.tile(canvas, fonts, x + 3 * gap, ty, 'GYRO', False, '--')
    elif fl & comms.F_GYRO_OK:
        ui.tile(canvas, fonts, x + 3 * gap, ty, 'GYRO', True, 'OK', ui.OK)
    elif fl & comms.F_GYRO_CAL:
        ui.tile(canvas, fonts, x + 3 * gap, ty, 'GYRO', True, 'CAL', AMBER)
    else:
        ui.tile(canvas, fonts, x + 3 * gap, ty, 'GYRO', True, 'LOST', ui.BAD)
