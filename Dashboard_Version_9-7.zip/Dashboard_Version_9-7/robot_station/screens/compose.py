"""Draws one whole frame: picks the pages for the current mode."""

from robot_station import rendering
from robot_station.config import CH, M, PID, TUNE
from robot_station.ui.canvas import text
from robot_station.ui.theme import BG, MUTED
from .arena_page import draw_centre
from .controller_panel import draw_left
from .link_panel import draw_right
from .pid_page import draw_pid
from .top_bar import draw_topbar
from .tune_page import draw_tune


def refresh_dynamic(app):
    """Update the dropdown lists that depend on the mode and the link."""
    app.dd_view.options[:] = [(v, rendering.VIEW_LABEL[v]) for v in app.views()]
    app.dd_target.title = 'COM PORT' if app.transport_kind == 'serial' else 'BLE DEVICE'
    app.dd_target.options[:] = app.target_options()


def render(canvas, fonts, big, cam, scene, app, S, st, log_lines):
    """Draw one whole frame."""
    canvas.fill(BG)
    refresh_dynamic(app)
    draw_topbar(canvas, fonts, app)
    if app.mode == TUNE:
        draw_tune(canvas, fonts, app)
    elif app.mode == PID:
        draw_pid(canvas, fonts, app)
    else:
        draw_left(canvas, fonts, big, st, log_lines)
        draw_centre(canvas, fonts, cam, scene, app)
    draw_right(canvas, fonts, app)
    text(
        canvas,
        fonts['s'],
        (
            'Space E-STOP   F11 fullscreen   ARM OUTPUT is on the LINK tab   ESC quit'
            if app.mode in (TUNE, PID)
            else 'Space E-STOP   BACK arm/disarm   F11 fullscreen   V view   T drive mode   L turn   0 re-zero   P timer   C cubes   ESC quit'
        ),
        (M + 4, CH - 22),
        MUTED,
    )
    S.draw(app, canvas, fonts)
