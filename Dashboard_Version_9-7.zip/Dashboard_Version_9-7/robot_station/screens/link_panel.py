"""The right column: the LINK tab (connection, arm, log) and the SETTINGS tab."""

import textwrap

import pygame

from robot_station import comms
from robot_station import simulation
from robot_station import ui
from robot_station.config import BOT, RW, RX, STATE_COL, TOP, WW, X0
from robot_station.ui.canvas import text
from robot_station.ui.theme import MUTED, PANEL, TEXT
from .text_utils import mmss, wrap_hint


def draw_right(canvas, fonts, app):
    """The right column: the tab strip and the selected tab."""
    pygame.draw.rect(canvas, PANEL, (RX, TOP, RW, BOT - TOP), border_radius=8)
    if app.tab == 'link':
        draw_link(canvas, fonts, app)
    else:
        for y, h, t in (
            (104, 74, 'DRIVE'),
            (184, 96, 'VIEW OVERLAYS   (switch + opacity)'),
            (288, 98, 'ACTIONS'),
            (394, 68, 'WINDOW'),
            (470, 136, 'ROBOT  (BACK button = arm / disarm)'),
        ):
            ui.card(canvas, (X0, y, WW, h), t, fonts)
        text(
            canvas,
            fonts['s'],
            'RT = full speed %d cm/s. Raise this to go faster' % simulation.MAX_SPEED,
            (X0 + 10, 572),
            MUTED,
        )
        text(canvas, fonts['s'], 'without holding RT (30 = RT not needed).', (X0 + 10, 588), MUTED)


def draw_link(canvas, fonts, app):
    """The LINK tab: connection, state, arm, statistics and the log."""
    l, s, x0, w = app.link, app.link.stats, X0, WW
    ui.card(canvas, (x0, 104, w, 116), 'CONNECTION', fonts)
    ui.card(canvas, (x0, 228, w, 156), 'LINK STATUS', fonts)
    ui.card(canvas, (x0, 392, w, 62), 'OUTPUT TO ROBOT', fonts)
    ui.card(canvas, (x0, 462, w, 116), 'ROBOT TELEMETRY', fonts)
    ui.card(canvas, (x0, 586, w, 242), 'MESSAGES  (type a message to the robot below)', fonts)
    col = STATE_COL.get(l.state, MUTED)
    ui.led(canvas, (x0 + 20, 262), l.state != comms.Link.DISCONNECTED, col, 7)
    text(canvas, fonts['m'], l.state, (x0 + 34, 254), col)
    ui.signal_bars(canvas, x0 + w - 40, 250, l.quality())
    text(
        canvas,
        fonts['s'],
        (l.transport.name if l.transport else '-')[:26],
        (x0 + w - 50, 254),
        MUTED,
        'tr',
    )
    now = l.clock()
    ui.led(
        canvas, (x0 + 22, 286), l.connected and s['tx_rate'] > 0 and int(now * 8) % 2 == 0, ui.OK
    )
    text(canvas, fonts['s'], 'TX %4.1f/s' % s['tx_rate'], (x0 + 32, 279), TEXT)
    ui.led(
        canvas,
        (x0 + 122, 286),
        l.connected and s['rx_rate'] > 0 and int(now * 8) % 2 == 0,
        (90, 170, 240),
    )
    text(canvas, fonts['s'], 'RX %4.1f/s' % s['rx_rate'], (x0 + 132, 279), TEXT)
    text(
        canvas,
        fonts['s'],
        'bad %d  loss %.1f%%' % (s['bad'], l.loss_percent()),
        (x0 + 224, 279),
        ui.BAD if s['bad'] else TEXT,
    )
    if s['rtt'] is None:
        text(canvas, fonts['s'], 'latency: -', (x0 + 10, 298), MUTED)
    else:
        text(
            canvas,
            fonts['s'],
            'latency %3.0f ms  avg %3.0f  min %3.0f  max %3.0f'
            % (s['rtt'], s['rtt_avg'], s['rtt_min'], s['rtt_max']),
            (x0 + 10, 298),
            TEXT,
        )
    age = s['since_rx']
    text(
        canvas,
        fonts['s'],
        'last data %s     up %s' % ('-' if age is None else '%.2f s ago' % age, mmss(l.uptime())),
        (x0 + 10, 316),
        MUTED,
    )
    hcol = (
        ui.BAD
        if l.state == comms.Link.ERROR
        else (
            ui.WARN
            if (app.scanning() or l.state in (comms.Link.NO_REPLY, comms.Link.STALE))
            else MUTED
        )
    )
    for i, ln in enumerate(wrap_hint(app.hint())):
        text(canvas, fonts['s'], ln, (x0 + 10, 338 + i * 14), hcol)
    text(
        canvas,
        fonts['s'],
        'LIVE: robot gets drive commands' if l.armed else 'safe: robot gets zeros',
        (x0 + w - 10, 398),
        ui.BAD if l.armed else MUTED,
        'tr',
    )
    t, h = l.telemetry, l.hello
    text(
        canvas,
        fonts['s'],
        (
            ('%s  %s  (%s)' % (h.get('fw', '?'), h.get('version', ''), h.get('robot', '?')))[:42]
            if h
            else 'no HELLO yet'
        ),
        (x0 + 10, 482),
        TEXT if h else MUTED,
    )
    if t:
        low = bool(t['flags'] & comms.F_LOWBAT)
        ui.labelled_bar(
            canvas,
            fonts,
            x0 + 10,
            502,
            w - 20,
            (t['vbat_mv'] - 6000) / 2400.0,
            'Battery',
            '%.2f V' % (t['vbat_mv'] / 1000.0),
            ui.BAD if low else ui.OK,
            vw=72,
        )
        text(
            canvas,
            fonts['s'],
            'yaw %+7.1f deg   gyro %+6.1f deg/s' % (t['yaw'], t['gz']),
            (x0 + 10, 522),
            TEXT,
        )
        cx = x0 + 12
        for bit, lab, c in (
            (comms.F_ARMED, 'ARMED', ui.BAD),
            (comms.F_FAILSAFE, 'FAILSAFE', ui.WARN),
            (comms.F_GYRO_OK, 'GYRO', ui.OK),
            (comms.F_GYRO_CAL, 'CAL', ui.WARN),
            (comms.F_LOWBAT, 'LOW BAT', ui.BAD),
        ):
            on = bool(t['flags'] & bit)
            ui.led(canvas, (cx, 556), on, c, 5)
            text(canvas, fonts['s'], lab, (cx + 9, 549), TEXT if on else MUTED)
            cx += 20 + len(lab) * 7
    else:
        text(canvas, fonts['s'], 'no telemetry', (x0 + 10, 506), MUTED)
    colmap = {'tx': (120, 190, 255), 'rx': TEXT, 'err': ui.BAD, 'sys': MUTED}
    rows = []  # newest messages, long ones wrapped onto a second line
    for ts, kind, msg in list(l.log)[-8:]:
        for j, part in enumerate(
            textwrap.wrap(
                '%s %s %s'
                % (mmss(ts % 3600), {'tx': '>', 'rx': '<', 'err': '!', 'sys': '*'}[kind], msg),
                44,
            )
            or ['']
        ):
            rows.append(((part if j == 0 else '     ' + part)[:46], colmap[kind]))
    for i, (line, c) in enumerate(rows[-8:]):
        text(canvas, fonts['s'], line, (x0 + 10, 608 + i * 16), c)
