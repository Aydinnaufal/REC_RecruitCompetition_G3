"""The Tune page: speedometers, servo dials, gyro board, battery and the robot's tuning values."""

import math

import pygame

from robot_station import comms
from robot_station import ui
from robot_station.config import AMBER, LX, PAGE, TOP
from robot_station.ui.canvas import text
from robot_station.ui.theme import ACCENT, BAD, MUTED, PANEL, TEXT


def narrow_servo_limits(c):
    """True when a servo's limits leave it less than 30 degrees (or are upside down): it can hardly move."""
    return any(c[hi] - c[lo] < 30 for lo, hi in (('lo1', 'hi1'), ('lo2', 'hi2')))


def draw_tune(canvas, fonts, app):
    """The Tune page. Positions must match the widgets built in Screen.build."""
    pygame.draw.rect(canvas, PANEL, PAGE, border_radius=8)
    text(canvas, fonts['m'], 'TUNE  |  wireless test and tuning', (LX + 14, TOP + 8), ACCENT)
    msg, col = app.tune_status()
    text(canvas, fonts['s'], msg, (LX + PAGE[2] - 14, TOP + 10), col, 'tr')
    t, l = app.tune_tel(), app.link
    live = bool(t)
    ui.card(
        canvas, (LX, 92, 520, 284), 'MOTORS  (needle = PWM duty the robot is really sending)', fonts
    )
    ui.card(canvas, (544, 92, 500, 284), 'SERVOS', fonts)
    ui.card(canvas, (LX, 384, 520, 442), 'GYRO + ACCELEROMETER  (MPU6050)', fonts)
    ui.card(canvas, (544, 384, 150, 442), 'BATTERY', fonts)
    ui.card(canvas, (706, 384, 338, 442), 'TUNING VALUES', fonts)
    # ---- motors: two speedometers
    for side, cx, name in ((0, LX + 140 + 12, 'LEFT'), (1, LX + 390 + 12, 'RIGHT')):
        pwm = t.get('pwm_l' if side == 0 else 'pwm_r', 0)
        pct = pwm * 100.0 / 255
        ui.speedo(
            canvas,
            fonts,
            cx,
            204,
            78,
            pct,
            -100,
            100,
            ui.OK if pct >= 0 else AMBER,
            name,
            ('%+d%%' % round(pct)) if live else '--',
            (
                ('PWM %+4d  %s' % (pwm, 'FWD' if pwm > 0 else 'REV' if pwm < 0 else 'STOP'))
                if live
                else 'no data'
            ),
            live=live,
        )
        ask = app.tune['vl' if side == 0 else 'vr']
        text(
            canvas,
            fonts['s'],
            'asked %+d%%' % round(ask),
            (cx, 298),
            MUTED if not ask else TEXT,
            'center',
        )
    # ---- servos: two dials
    for i, cx in ((1, 544 + 130), (2, 544 + 370)):
        a = t.get('s%d' % i) if live else False
        lo, hi = app.cfg('lo%d' % i), app.cfg('hi%d' % i)
        ui.servo_dial(
            canvas,
            fonts,
            cx,
            228,
            78,
            (None if a is not None and a < 0 else a) if live else False,
            0 if lo is None else lo,
            180 if hi is None else hi,
            (240, 170, 70),
            'SERVO %d  (GPIO %d)' % (i, 18 if i == 1 else 19),
        )
        v = app.tune['s%d' % i]
        text(
            canvas,
            fonts['s'],
            'asked %s' % ('limp' if v is None else '%d deg' % v),
            (cx, 298),
            MUTED if v is None else TEXT,
            'center',
        )
    # ---- gyro
    gx0, gy0 = LX, 384
    if live:
        ax, ay, az = t['ax'], t['ay'], t['az']
        roll = math.degrees(math.atan2(ay, az))
        pitch = math.degrees(math.atan2(-ax, math.hypot(ay, az)))
        yaw = t['yaw']
    else:
        ax = ay = az = roll = pitch = yaw = 0.0
    ui.board3d(canvas, fonts, gx0 + 170, gy0 + 150, 42, yaw, pitch, roll, live)
    x = gx0 + 332
    for k, (lab, v) in enumerate((('YAW', yaw), ('PITCH', pitch), ('ROLL', roll))):
        text(canvas, fonts['s'], lab, (x, gy0 + 44 + k * 38), MUTED)
        text(
            canvas,
            fonts['l'],
            ('%+6.1f' % v + chr(176)) if live else '   --',
            (x + 54, gy0 + 38 + k * 38),
            TEXT if live else MUTED,
        )
    ok = live and bool(t['who'])
    ui.led(canvas, (x + 6, gy0 + 168), ok, ui.OK, 6)
    text(
        canvas,
        fonts['s'],
        ('chip id 0x%02X' % t['who']) if ok else 'chip NOT FOUND' if live else 'chip -',
        (x + 20, gy0 + 161),
        TEXT if ok else (ui.BAD if live else MUTED),
    )
    text(
        canvas,
        fonts['s'],
        ('temp %.1f C' % t['temp']) if live else 'temp -',
        (x, gy0 + 186),
        TEXT if live else MUTED,
    )
    cal = live and bool(l.telemetry.get('flags', 0) & comms.F_GYRO_CAL)
    text(
        canvas,
        fonts['s'],
        'zeroing... keep still' if cal else ('yaw zero set at power-up' if live else ''),
        (x, gy0 + 206),
        ui.WARN if cal else MUTED,
    )
    bx, bw = gx0 + 14, 520 - 28
    text(canvas, fonts['s'], 'ANGULAR RATE  (deg/s)', (bx, gy0 + 246), MUTED)
    for k, (lab, key, col) in enumerate(
        (
            ('X roll', 'gx', (235, 80, 70)),
            ('Y pitch', 'gy', (80, 210, 100)),
            ('Z yaw', 'gz', (90, 150, 245)),
        )
    ):
        ui.labelled_bar(
            canvas,
            fonts,
            bx,
            gy0 + 266 + k * 21,
            bw,
            (t[key] / 250.0) if live else 0,
            lab,
            ('%+7.1f' % t[key]) if live else '     --',
            col,
            True,
            74,
            80,
        )
    text(canvas, fonts['s'], 'ACCELERATION  (g)', (bx, gy0 + 338), MUTED)
    for k, (lab, key, col) in enumerate(
        (('X', 'ax', (235, 80, 70)), ('Y', 'ay', (80, 210, 100)), ('Z', 'az', (90, 150, 245)))
    ):
        ui.labelled_bar(
            canvas,
            fonts,
            bx,
            gy0 + 358 + k * 21,
            bw,
            (t[key] / 2.0) if live else 0,
            lab,
            ('%+6.2f' % t[key]) if live else '    --',
            col,
            True,
            74,
            80,
        )
    text(
        canvas,
        fonts['s'],
        'flat on the table: Z about +1.00 g, X and Y about 0',
        (bx, gy0 + 420),
        MUTED,
    )
    # ---- battery
    vb = l.telemetry.get('vbat_mv') if live else None
    volts = (
        None if vb is None else vb / 1000.0
    )  # shown whatever it is: a wrong reading tells you what to check
    bcx = 544 + 75
    ui.battery(canvas, fonts, 544 + 14, gy0 + 34, 56, 270, volts)
    low = bool(live and l.telemetry['flags'] & comms.F_LOWBAT)
    text(
        canvas,
        fonts['l'],
        '--' if volts is None else '%.2f V' % volts,
        (bcx, gy0 + 330),
        (ui.BAD if low else TEXT) if volts else MUTED,
        'center',
    )
    if (
        volts is not None and volts < 4.0
    ):  # a 2S pack is never below 6 V: nothing is feeding the sense wire
        ratio = app.cfg('ratio') or 3.0
        text(canvas, fonts['m'], 'NO BATTERY?', (bcx, gy0 + 362), ui.WARN, 'center')
        for k, ln in enumerate(
            (
                'pin 34 reads %d mV' % round(volts * 1000 / ratio),
                'Is the battery on and',
                'the divider wired to',
                'GPIO 34 and 7.4 V?',
            )
        ):
            text(canvas, fonts['s'], ln, (bcx, gy0 + 384 + k * 16), MUTED, 'center')
    elif volts is not None:
        text(
            canvas,
            fonts['m'],
            '%d %%' % round(max(0, min(1, (volts - 6.0) / 2.4)) * 100),
            (bcx, gy0 + 358),
            TEXT,
            'center',
        )
        text(canvas, fonts['s'], 'cell %.2f V' % (volts / 2), (bcx, gy0 + 382), MUTED, 'center')
        text(
            canvas,
            fonts['m'],
            'LOW BATTERY' if low else 'OK',
            (bcx, gy0 + 408),
            ui.BAD if low else ui.OK,
            'center',
        )
    else:
        text(canvas, fonts['s'], 'no reading', (bcx, gy0 + 358), MUTED, 'center')
    # ---- tuning values: what the robot holds now
    c = l.tune_cfg if l.connected else {}
    y = gy0 + 308
    text(canvas, fonts['s'], 'IN THE ROBOT NOW  (kept after power off)', (706 + 12, y), MUTED)
    lines = (
        [
            'MIN_PWM = %d;' % c['minpwm'],
            'INVERT_LEFT = %s;  INVERT_RIGHT = %s;'
            % ('true' if c['invl'] else 'false', 'true' if c['invr'] else 'false'),
            'servo 1: %d .. %d deg    servo 2: %d .. %d deg'
            % (c['lo1'], c['hi1'], c['lo2'], c['hi2']),
            'VBAT_RATIO = %.3f;' % c['ratio'],
        ]
        if c
        else ['-']
    )
    for k, ln in enumerate(lines):
        text(canvas, fonts['s'], ln, (706 + 12, y + 22 + k * 18), TEXT if c else MUTED)
    if c and narrow_servo_limits(c):
        text(canvas, fonts['s'], 'A servo has almost no room to move:', (706 + 12, y + 96), BAD)
        text(canvas, fonts['s'], 'press Reset all (twice) or widen its limits.', (706 + 12, y + 112), BAD)
        return
    text(
        canvas, fonts['s'], 'Find start power: arm, press it, the wheel', (706 + 12, y + 96), MUTED
    )
    text(
        canvas,
        fonts['s'],
        'speeds up slowly; press again when it moves.',
        (706 + 12, y + 112),
        MUTED,
    )
