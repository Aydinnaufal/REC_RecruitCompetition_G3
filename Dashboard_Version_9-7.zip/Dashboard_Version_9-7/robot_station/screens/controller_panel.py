"""The left column: the controller picture, raw values and the event list."""

import pygame

from robot_station import ui
from robot_station.config import BOT, LW, LX, TOP
from robot_station.ui.canvas import text
from robot_station.ui.theme import ACCENT, MUTED, PANEL, TEXT


def draw_left(canvas, fonts, big, st, log_lines):
    """The left column."""
    pygame.draw.rect(canvas, PANEL, (LX, TOP, LW, BOT - TOP), border_radius=8)
    text(canvas, fonts['m'], 'CONTROLLER', (LX + 12, TOP + 8), MUTED)
    text(
        canvas,
        fonts['s'],
        (st.name if st.connected else 'NOT FOUND')[:20],
        (LX + LW - 12, TOP + 10),
        ACCENT if st.connected else (240, 120, 100),
        'tr',
    )
    img = pygame.Surface((ui.CTRL_W, ui.CTRL_H))
    img.fill(PANEL)
    ui.draw_controller(img, big, 0, 0, st)
    w = LW - 20
    scaled = pygame.transform.smoothscale(img, (w, int(w * ui.CTRL_H / ui.CTRL_W)))
    canvas.blit(scaled, (LX + 10, TOP + 30))
    y = ui.raw_compact(canvas, fonts, LX + 12, TOP + 30 + scaled.get_height() + 8, LW - 24, st) + 4
    text(canvas, fonts['s'], 'EVENTS', (LX + 12, y), MUTED)
    for k, line in enumerate(log_lines[: max(2, (BOT - y - 26) // 15)]):
        text(canvas, fonts['s'], line[:40], (LX + 12, y + 18 + k * 15), TEXT if k == 0 else MUTED)
