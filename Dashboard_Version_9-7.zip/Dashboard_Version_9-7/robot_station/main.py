"""The program: window, event loop and the order in which one frame is processed.

One frame (60 per second) does, in this order:

1. handle the mouse and keyboard events,
2. read the Xbox controller,
3. let the robot's telemetry steer the picture (``pre_drive``), then step the simulation,
4. talk to the robot (``tick_link``: heartbeat, telemetry, reconnect, tests),
5. draw everything.
"""

import pygame

from robot_station import inputs
from robot_station import rendering
from robot_station import ui
from robot_station.app import App
from robot_station.config import CH, CW, GAME, VERSION, VP
from robot_station.screens import Screen, render

START_WINDOW_SIZE = (1440, 860)
MIN_WINDOW_SIZE = (480, 300)
FRAMES_PER_SECOND = 60
MAX_FRAME_SECONDS = 0.05  # a slow frame is simulated as at most this long


def make_window(fullscreen, size):
    """Create the window (windowed and resizable, or fullscreen)."""
    if fullscreen:
        return pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    return pygame.display.set_mode(size, pygame.RESIZABLE)


class Dashboard:
    """Owns the window and runs the event loop around one App."""

    def __init__(self):
        self.app = App()
        pygame.init()
        self.windowed_size = START_WINDOW_SIZE
        self.window = make_window(False, self.windowed_size)
        pygame.display.set_caption('Robot Station ' + VERSION)

        self.fonts, self.big_font = ui.make_fonts()
        self.canvas = pygame.Surface((CW, CH))
        self.picture = pygame.Surface((VP[2], VP[3]))
        self.camera = rendering.Camera(VP[2], VP[3], 400)

        self.gamepad = inputs.XboxController()
        self.event_log = inputs.EventLog()
        self.screen = Screen(self.app)

        self.dragging_picture = False
        self.running = True
        self.app.toggle_fullscreen = self.toggle_fullscreen

    # ---------------------------------------------------------------- window
    def toggle_fullscreen(self):
        """Switch between the window and fullscreen, remembering the window size."""
        if not self.app.fullscreen:
            self.windowed_size = self.window.get_size()
        self.app.fullscreen = not self.app.fullscreen
        self.window = make_window(self.app.fullscreen, self.windowed_size)

    def quit(self):
        """Close the link (which disarms the robot), save the settings and stop the loop."""
        self.app.link.disconnect()
        self.app.save_settings()
        self.running = False

    def to_canvas(self, window_position):
        """A position in the window -> the same place on the design canvas."""
        return ui.to_canvas(window_position, self.window.get_size(), CW, CH)

    # ---------------------------------------------------------------- events
    def handle_event(self, event):
        """Dispatch one pygame event."""
        app, screen = self.app, self.screen

        if event.type == pygame.QUIT:
            self.quit()

        elif event.type == pygame.VIDEORESIZE and not app.fullscreen:
            self.windowed_size = (
                max(MIN_WINDOW_SIZE[0], event.w),
                max(MIN_WINDOW_SIZE[1], event.h),
            )
            self.window = pygame.display.set_mode(self.windowed_size, pygame.RESIZABLE)

        elif event.type == pygame.MOUSEMOTION:
            screen.motion(app, self.to_canvas(event.pos))
            if self.dragging_picture:
                scale = ui.fit_scale(*self.window.get_size(), CW, CH)[0]
                app.drag(event.rel[0] / scale, event.rel[1] / scale)

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            position = self.to_canvas(event.pos)
            clicked_a_widget = screen.click(app, position)
            if not clicked_a_widget and app.in_scene(position):
                self.dragging_picture = True  # a click on the picture starts turning the camera
            screen.drop_focus(app, position)

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging_picture = False
            screen.release(app)

        elif event.type == pygame.MOUSEWHEEL:
            if app.in_scene(self.to_canvas(pygame.mouse.get_pos())):
                app.look.wheel(event.y)

        elif event.type == pygame.KEYDOWN:
            if screen.typing(app):
                screen.key(app, event)  # the text box has the keyboard
            else:
                self.handle_key(event.key)

    def handle_key(self, key):
        """The keyboard shortcuts (listed at the bottom of the window)."""
        app, screen, sim = self.app, self.screen, self.app.sim

        if key == pygame.K_ESCAPE:
            if screen.any_open(app):
                screen.close_all(app)
            elif app.fullscreen:
                self.toggle_fullscreen()
            else:
                self.quit()
        elif key == pygame.K_SPACE:
            app.estop()
        elif key in (pygame.K_F11, pygame.K_f):
            self.toggle_fullscreen()
        elif key == pygame.K_v:
            app.next_view()
        elif key == pygame.K_t:
            app.next_drive_mode()
        elif key == pygame.K_p:
            app.timer_pause()
        elif key == pygame.K_l:
            sim.turn_on = not sim.turn_on
        elif key == pygame.K_0:
            app.zero()
        elif key == pygame.K_z:
            sim.reset()
        elif key == pygame.K_x:
            sim.reset_robot()
        elif key == pygame.K_c and app.mode == GAME:
            sim.reset_cubes()

    # ---------------------------------------------------------------- one frame
    def update(self, dt):
        """Read the controller and advance the simulation, the link and the timer by dt seconds."""
        app = self.app
        pad_state = self.gamepad.poll()
        app.pre_drive()
        app.tick_pad(pad_state)
        app.sim.drive(pad_state, dt)
        app.tick_link(dt)
        self.event_log.update(pad_state)
        app.timer_update(dt, pad_state)
        return pad_state

    def draw(self, pad_state):
        """Draw the frame on the canvas and show it in the window."""
        render(
            self.canvas,
            self.fonts,
            self.big_font,
            self.camera,
            self.picture,
            self.app,
            self.screen,
            pad_state,
            self.event_log.lines,
        )
        ui.present(self.window, self.canvas)
        pygame.display.flip()

    def run(self):
        """The event loop; returns when the window is closed."""
        clock = pygame.time.Clock()
        while self.running:
            dt = min(clock.tick(FRAMES_PER_SECOND) / 1000.0, MAX_FRAME_SECONDS)
            for event in pygame.event.get():
                self.handle_event(event)
                if not self.running:
                    return
            pad_state = self.update(dt)
            self.draw(pad_state)


def main():
    """Run the dashboard until the window is closed."""
    Dashboard().run()
