"""A short list of the latest button presses, shown in the EVENTS box."""

import time


class EventLog:
    """One line whenever a control is pressed / released or a stick or trigger crosses the halfway mark. Newest first."""

    def __init__(self):
        """Keeps the latest events, newest first."""
        self.lines, self.prev = [], {}

    def update(self, st):
        """Call every frame with the controller state: new button presses and trigger moves become lines."""
        now = dict(st.buttons)
        for n, v in (('LX', st.lx), ('LY', st.ly), ('RX', st.rx), ('RY', st.ry)):
            now[n + ('+' if v >= 0 else '-')] = abs(v) > 0.5
        now['LT'], now['RT'] = st.lt > 0.5, st.rt > 0.5
        now.update(
            {
                'D-UP': st.dpad[1] > 0,
                'D-DOWN': st.dpad[1] < 0,
                'D-LEFT': st.dpad[0] < 0,
                'D-RIGHT': st.dpad[0] > 0,
            }
        )
        for n, v in now.items():
            if v != self.prev.get(n, False):
                self.lines.insert(
                    0,
                    '%s  %-8s %s' % (time.strftime('%H:%M:%S'), n, 'pressed' if v else 'released'),
                )
        self.prev = now
        del self.lines[40:]
