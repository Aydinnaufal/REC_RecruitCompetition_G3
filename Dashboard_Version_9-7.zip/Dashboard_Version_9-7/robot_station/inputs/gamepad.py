"""Reads the Xbox controller (wired or wireless receiver) through pygame."""

import time

from .mapping import ControllerState, apply_mapping, load_mapping


class XboxController:
    """Finds the first joystick, finds it again after unplug / replug, and returns a ControllerState from poll()."""

    def __init__(self, mapping=None):
        """Uses the default mapping for this system unless one is given."""
        import pygame

        self.pg = pygame
        if not pygame.get_init():
            pygame.init()
        pygame.joystick.init()
        self.mapping = mapping or load_mapping()
        self.joy, self._last_scan = None, 0.0

    def _scan(self):
        """Look for a joystick (also after one is plugged in later)."""
        if time.time() - self._last_scan < 1.0:
            return
        self._last_scan = time.time()
        self.pg.joystick.quit()
        self.pg.joystick.init()
        if self.pg.joystick.get_count() > 0:
            self.joy = self.pg.joystick.Joystick(0)
            self.joy.init()

    def poll(self):
        """Read the controller now and return a ControllerState (not connected if none is found)."""
        self.pg.event.pump()
        if self.joy is None or self.pg.joystick.get_count() == 0:
            self.joy = None
            self._scan()
            if self.joy is None:
                return ControllerState()
        j = self.joy
        try:
            raw_axes = [j.get_axis(i) for i in range(j.get_numaxes())]
            raw_buttons = [j.get_button(i) for i in range(j.get_numbuttons())]
            raw_hats = [j.get_hat(i) for i in range(j.get_numhats())]
        except Exception:
            self.joy = None
            return ControllerState()
        return apply_mapping(self.mapping, raw_axes, raw_buttons, raw_hats, j.get_name())
