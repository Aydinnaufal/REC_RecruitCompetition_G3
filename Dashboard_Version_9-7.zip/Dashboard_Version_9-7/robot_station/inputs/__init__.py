"""Reading the Xbox controller and giving it the same named controls on every system."""

from .mapping import (
    BUTTON_NAMES,
    STICK_NAMES,
    TRIGGER_NAMES,
    MAPPING_FILE,
    DEADZONE,
    DEFAULTS,
    default_mapping,
    load_mapping,
    ControllerState,
    apply_mapping,
)
from .gamepad import XboxController
from .event_log import EventLog
