"""Auto-tuning of the gyro control gains (Kp, Ki, Kd and the turn gains).

* ``metrics``  measures a test run (overshoot, settling time, swinging ...)
* ``rules``    decides which gain to change after a run
* ``tuner``    the turn -> measure -> adjust -> turn again loop
"""

from .metrics import DriftMetrics, StepMetrics, analyze_drift, analyze_step
from .tuner import AutoTuner, TestRequest, TuneSettings
