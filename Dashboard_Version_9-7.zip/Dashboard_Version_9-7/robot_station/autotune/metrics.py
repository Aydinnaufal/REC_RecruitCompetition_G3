"""Measuring a test run: how well did the robot follow its target heading?

The inputs are the rows of the PID history (one row per report from the robot, 10-20 per second)::

    t       time of the report (dashboard clock, seconds)
    yaw     heading from the telemetry (deg)
    target  the heading the robot is trying to reach or hold (deg)
    err     heading error, yaw - target (deg)
    corr    correction the control adds to the wheels (percent): the ERROR / CORRECTION graph
    vl, vr  wheel speeds (percent): the WHEELS graph
    mode    0 off, 1 ready, 2 holding / steering, 3 turning in place

Everything here is plain arithmetic on lists, so it can be tested without a robot.
"""

from dataclasses import dataclass


def row_yaw(row):
    """The heading of a row, as accurately as the robot reported it.

    While the control is active the robot reports target and error in the same frame, so
    ``target + err`` is exact at that moment; the telemetry yaw can be up to 100 ms older.
    """
    if row['mode'] in (2, 3):
        return row['target'] + row['err']
    return row['yaw']


@dataclass
class StepMetrics:
    """How one step response (a turn or a steer to a new heading) went."""

    distance_deg: float  # size of the step
    overshoot_pct: float  # how far past the target it went, in percent of the step
    rise_s: float  # time to get 90 % of the way (window length if it never did)
    settle_s: float  # time after which it stayed inside the tolerance band
    final_error_deg: float  # average error in the last 0.3 s
    ringing: int  # how many times it swung across the target after arriving
    saturation: float  # share of the time the correction was at its limit (0..1)
    chatter: float  # how jumpy the correction was once settled (0 = smooth, 1 = very jumpy)
    reached: bool  # got within the tolerance band at all
    settled: bool  # was inside the band at the end
    cost: float  # one number to compare runs (smaller is better), see step_cost()
    samples: int = 0


def step_cost(settle_s, overshoot_pct, ringing, final_error_deg, tolerance_deg, reached):
    """One number that says how good a step response was (smaller is better).

    Time to settle counts one point per second. Overshoot costs 0.08 per percent, every swing
    across the target 0.4, and ending outside the band up to 0.3 per band width. Never reaching
    the target costs 2 extra seconds. So "fast but wobbly" and "slow but smooth" both lose to
    "fast and smooth", which is what we want.
    """
    cost = settle_s + 0.08 * overshoot_pct + 0.4 * ringing
    cost += 0.3 * min(5.0, abs(final_error_deg) / tolerance_deg)
    if not reached:
        cost += 2.0
    return cost


def analyze_step(rows, t0, start_yaw, target, tolerance_deg, correction_limit, window_s):
    """Measure a step from ``start_yaw`` to ``target``. Returns None if there is too little data."""
    rows = [r for r in rows if r['t'] >= t0]
    if len(rows) < 4:
        return None
    direction = 1.0 if target >= start_yaw else -1.0
    distance = abs(target - start_yaw)
    times = [r['t'] - t0 for r in rows]
    # Error measured along the direction of the step: positive = beyond the target.
    beyond = [(row_yaw(r) - start_yaw) * direction - distance for r in rows]

    overshoot = max(0.0, max(beyond))
    overshoot_pct = 100.0 * overshoot / distance if distance > 0 else 0.0

    reached_at = next((i for i, b in enumerate(beyond) if abs(b) <= tolerance_deg), None)
    reached = reached_at is not None
    rise_index = next((i for i, b in enumerate(beyond) if b >= -0.1 * distance), None)
    rise_s = times[rise_index] if rise_index is not None else window_s

    outside = [i for i, b in enumerate(beyond) if abs(b) > tolerance_deg]
    settled = bool(rows) and abs(beyond[-1]) <= tolerance_deg
    if not outside:
        settle_s = 0.0
    elif not settled:
        settle_s = window_s
    else:
        settle_s = min(window_s, times[outside[-1]])

    tail = [b for t, b in zip(times, beyond) if t >= times[-1] - 0.3]
    final_error = sum(tail) / len(tail)

    ringing = 0
    if reached:
        side = 0
        for b in beyond[reached_at:]:
            if abs(b) < tolerance_deg / 2:
                continue  # inside the quiet zone: not a swing
            new_side = 1 if b > 0 else -1
            if side and new_side != side:
                ringing += 1
            side = new_side

    limit = 0.98 * correction_limit
    saturation = sum(1 for r in rows if abs(r['corr']) >= limit) / len(rows)

    # Chatter: how much the correction jumps from report to report once the error is small.
    quiet = [r['corr'] for r, b in zip(rows, beyond) if abs(b) <= 2 * tolerance_deg]
    if len(quiet) >= 3:
        jumps = [abs(a - b) for a, b in zip(quiet, quiet[1:])]
        chatter = min(1.0, (sum(jumps) / len(jumps)) / correction_limit * 4.0)
    else:
        chatter = 0.0

    return StepMetrics(
        distance_deg=distance,
        overshoot_pct=overshoot_pct,
        rise_s=rise_s,
        settle_s=settle_s,
        final_error_deg=final_error,
        ringing=ringing,
        saturation=saturation,
        chatter=chatter,
        reached=reached,
        settled=settled,
        cost=step_cost(settle_s, overshoot_pct, ringing, final_error, tolerance_deg, reached),
        samples=len(rows),
    )


@dataclass
class DriftMetrics:
    """How a straight drive went while the robot learned its wheel balance (Ki)."""

    peak_error_deg: float  # biggest heading error during the run
    final_error_deg: float  # average absolute error in the last second
    settle_s: float  # time after which the error stayed small
    ringing: int  # how many times the error swung across zero
    balance_end: float  # the learned balance at the end (percent)
    cost: float
    samples: int = 0


def analyze_drift(rows, t0, tolerance_deg, window_s):
    """Measure a straight drive that started with the learned balance reset to zero."""
    rows = [r for r in rows if r['t'] >= t0 and r['mode'] == 2]
    if len(rows) < 6:
        return None
    times = [r['t'] - t0 for r in rows]
    errors = [r['err'] for r in rows]
    peak = max(abs(e) for e in errors)
    tail = [abs(e) for t, e in zip(times, errors) if t >= times[-1] - 1.0]
    final = sum(tail) / len(tail)
    outside = [i for i, e in enumerate(errors) if abs(e) > tolerance_deg]
    settle_s = (
        0.0
        if not outside
        else (window_s if abs(errors[-1]) > tolerance_deg else times[outside[-1]])
    )

    ringing, side = 0, 0
    for e in errors:
        if abs(e) < tolerance_deg / 2:
            continue
        new_side = 1 if e > 0 else -1
        if side and new_side != side:
            ringing += 1
        side = new_side

    cost = settle_s + 0.3 * peak + 0.4 * ringing + 2.0 * final
    return DriftMetrics(peak, final, settle_s, ringing, rows[-1]['bal'], cost, len(rows))


def combine_steps(results):
    """The worst case of several step responses (different turn sizes), as one StepMetrics.

    Every number is the worst of the set, so the rules react to the size that goes worst; the cost is
    halfway between the average and the worst, so one bad size cannot hide behind good ones.
    """
    costs = [m.cost for m in results]
    worst_final = max((m.final_error_deg for m in results), key=abs)
    return StepMetrics(
        distance_deg=max(m.distance_deg for m in results),
        overshoot_pct=max(m.overshoot_pct for m in results),
        rise_s=max(m.rise_s for m in results),
        settle_s=max(m.settle_s for m in results),
        final_error_deg=worst_final,
        ringing=max(m.ringing for m in results),
        saturation=sum(m.saturation for m in results) / len(results),
        chatter=max(m.chatter for m in results),
        reached=all(m.reached for m in results),
        settled=all(m.settled for m in results),
        cost=(sum(costs) / len(costs) + max(costs)) / 2.0,
        samples=sum(m.samples for m in results),
    )
