"""Numbers of the simulated arena and robot. Units: cm and seconds."""

import math

G = 981.0  # gravity, cm/s^2
CUBE_S = 3.0  # cube side: 30 mm
PILLAR_W, PILLAR_H = 4.0, 0.5
WALL_T, WALL_H = 1.2, 10.0
FIELD = 105.0  # half of the 210 cm field
FRICTION, RESTITUTION, Z_EPS = 0.35, 0.25, 0.01
PILLAR_XS, PILLAR_YS = (-95.0, -83.0), (-13.0, 0.0, 13.0)  # blue side; red side is the mirror image
DROP_HEIGHT = 10.0
TRACK = 15.0  # distance between the wheels
MAX_SPEED, SLOW_CM = 30.0, 20.0
TURN_GAIN = 0.55
ACCEL, DECEL, LAG = 150.0, 240.0, 9.0
W_MAX = 2.0 * MAX_SPEED / TRACK
SNAP_ACCEL = 30.0
SNAP_GIVE_UP_BASE_S = 2.5  # a snap turn is given up after this long plus ...
SNAP_GIVE_UP_S_PER_DEG = 0.015  # ... this much for every degree it had to turn (180 degrees: 5.2 s; the robot itself gives up 0.5 s earlier)
ALIGN_TOL = math.radians(0.3)
MAX_SUB = 1.0 / 60.0
DPAD_SPEED, DPAD_TURN, LT_TURN = 5.0, 0.6, 0.5
SPAWN = (-82.0, -92.0, 0.0)  # centre of the blue start box, facing up the map
MODES = ['arcade', 'arcade_snap']
MODE_LABEL = {'arcade': 'Arcade', 'arcade_snap': 'Arcade + Snap'}
BODY_Z = (4.2, 8.0)  # chassis underside clears a cube on a pillar
PARTS = [
    (0.0, 5.25, 6.0, 2.75, *BODY_Z),
    (0.0, -5.95, 6.0, 2.05, *BODY_Z),
    (-4.25, -0.7, 1.75, 3.2, *BODY_Z),
    (4.25, -0.7, 1.75, 3.2, *BODY_Z),
    (0.0, -3.3, 1.0, 0.6, 8.0, 20.0),  # rack column
    (-7.5, 0.0, 1.2, 3.0, 0.0, 6.0),
    (7.5, 0.0, 1.2, 3.0, 0.0, 6.0),
]  # wheels
# tower: a box on a rack and pinion, one servo pad inside it
BOX_IN, BOX_WALL = 3.8, 0.25
BOX_OUT = BOX_IN + 2 * BOX_WALL
BOX_H = 8.0
LIFT_MIN, LIFT_MAX, LIFT_START, LIFT_RATE = 0.6, 12.0, 7.0, 7.0
PAD_MAX, PAD_RATE, PAD_Y_HALF, PAD_Z0, PAD_Z1 = 3.0, 14.0, 1.0, 0.3, 2.7
TOWER_RELEASE_EPS = 0.10
FAR_X = -BOX_IN / 2 + CUBE_S / 2
