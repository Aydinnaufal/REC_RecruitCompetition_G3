"""The tower: a lifting box on a rack and pinion with one servo pad inside it."""

from robot_station.mathutil import clamp
from .constants import (
    BOX_H,
    BOX_IN,
    BOX_OUT,
    BOX_WALL,
    CUBE_S,
    FAR_X,
    LIFT_MAX,
    LIFT_MIN,
    LIFT_RATE,
    LIFT_START,
    PAD_MAX,
    PAD_RATE,
    PAD_Z0,
    PAD_Z1,
    TOWER_RELEASE_EPS,
)
from .geometry import OBB


class Tower:
    """A storage box that slides up and down on a rack, open at the top and the bottom, with one servo pad on its +x inner wall.
    The pad pushes a cube inside the box against the far wall: it is then HELD and goes up and down and drives with the box.
    """

    def __init__(self):
        """The tower starts at LIFT_START with the pad retracted."""
        self.pad_cmd = self.lift_cmd = 0.0
        self.reset()

    def reset(self):
        """Back to the start; drops any held cube."""
        self.lift, self.ext = LIFT_START, 0.0  # box bottom height, pad travel from the +x wall
        self.held = None
        self.rel = (
            0.0,
            0.0,
            0.0,
            0.0,
        )  # held cube in the robot frame: x, y, height above the box bottom, yaw
        self.contact = False

    @property
    def pad_face(self):
        """How far the pad face reaches into the box."""
        return BOX_IN / 2 - self.ext

    def parts(self, rob):
        """Collision boxes of the tower, in world coordinates."""
        o = BOX_IN / 2 + BOX_WALL / 2
        walls = (
            (0.0, o, BOX_OUT / 2, BOX_WALL / 2),
            (0.0, -o, BOX_OUT / 2, BOX_WALL / 2),
            (o, 0.0, BOX_WALL / 2, BOX_IN / 2),
            (-o, 0.0, BOX_WALL / 2, BOX_IN / 2),
        )
        return [
            OBB(*rob.to_world(cx, cy), hx, hy, rob.th, self.lift, self.lift + BOX_H, 'boxwall')
            for cx, cy, hx, hy in walls
        ]

    def set_cmd(self, pad, lift):
        """Pad and lift commands from the right stick."""
        self.pad_cmd, self.lift_cmd = clamp(pad, 0.0, 1.0), clamp(lift, -1.0, 1.0)

    def move(self, dt):
        """Move the lift and pad by dt seconds."""
        self.lift = clamp(self.lift + self.lift_cmd * LIFT_RATE * dt, LIFT_MIN, LIFT_MAX)
        new = self.ext + clamp(self.pad_cmd * PAD_MAX - self.ext, -PAD_RATE * dt, PAD_RATE * dt)
        if self.held is not None and new > self.ext:
            new = min(new, BOX_IN / 2 - (self.rel[0] + CUBE_S / 2))  # a held cube stops the pad
        self.ext = clamp(new, 0.0, PAD_MAX)

    def sync_held(self, rob):
        """Keep a held cube fixed to the tower."""
        if self.held is not None:
            c = self.held
            c.x, c.y = rob.to_world(self.rel[0], self.rel[1])
            c.th = rob.th + self.rel[3]
            c.z = self.lift + self.rel[2]

    def update_grip(self, rob, world):
        """Grab a cube that the pad squeezes, or release one when the pad opens."""
        if self.held is not None:
            if self.pad_face > self.rel[0] + CUBE_S / 2 + TOWER_RELEASE_EPS:
                self.release(rob)
            return
        self.contact = False
        for c in world.free_cubes():
            rx, ry = rob.to_robot(c.x, c.y)
            if abs(rx) > BOX_IN / 2 + 0.2 or abs(ry) > BOX_IN / 2 + 0.2:
                continue  # not in the box
            zrel = c.z - self.lift
            if (
                not (zrel < PAD_Z1 and zrel + CUBE_S > PAD_Z0)
                or self.pad_face > rx + CUBE_S / 2 + 0.02
            ):
                continue  # the pad does not reach it (height) / has not reached it yet
            self.contact = True
            nrx = min(rx, self.pad_face - CUBE_S / 2)  # the pad pushes the cube toward the far wall
            if nrx <= FAR_X + 0.02:  # squeezed against the far wall: held
                self.ext = BOX_IN / 2 - (FAR_X + CUBE_S / 2)
                self.grab(rob, c, FAR_X, ry, zrel)
                return
            c.x, c.y = rob.to_world(nrx, ry)
            c.vx = c.vy = 0.0

    def grab(self, rob, cube, rx, ry, zrel):
        """Hold `cube` at the given place inside the box."""
        self.held = cube
        cube.held = True
        cube.vx = cube.vy = cube.vz = 0.0
        self.rel = (rx, clamp(ry, -0.4, 0.4), zrel, cube.th - rob.th)
        self.sync_held(rob)

    def release(self, rob):
        """Let the held cube go."""
        c = self.held
        if c is None:
            return
        c.held = False
        c.vx, c.vy = rob.point_velocity(c.x, c.y)
        c.vz = 0.0
        self.held = None
