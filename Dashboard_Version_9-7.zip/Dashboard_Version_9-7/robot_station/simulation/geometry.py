"""Collision geometry: oriented boxes and the separating-axis test."""

import math

from .constants import Z_EPS


class OBB:
    """Oriented box: centre (cx, cy), half sizes hx / hy, rotation a, z range z0..z1."""

    __slots__ = ('cx', 'cy', 'hx', 'hy', 'ux', 'uy', 'z0', 'z1', 'ex', 'ey', 'tag')

    def __init__(self, cx, cy, hx, hy, a, z0, z1, tag=None):
        """A box centred at (cx, cy) with half sizes (hx, hy), turned by `a`, between heights z0 and z1."""
        self.cx, self.cy, self.hx, self.hy = cx, cy, hx, hy
        self.ux, self.uy = math.cos(a), math.sin(a)
        self.z0, self.z1, self.tag = z0, z1, tag
        self.ex = abs(self.ux) * hx + abs(self.uy) * hy
        self.ey = abs(self.uy) * hx + abs(self.ux) * hy


def z_overlap(a, b):
    """True when two boxes overlap in height."""
    return a.z0 < b.z1 - Z_EPS and b.z0 < a.z1 - Z_EPS


def aabb_apart(a, b):
    """Quick test: True when the boxes cannot touch."""
    return abs(a.cx - b.cx) > a.ex + b.ex or abs(a.cy - b.cy) > a.ey + b.ey


def sat(a, b):
    """Separating axis test. Returns (depth, nx, ny) with n pointing from a to b, or None when they do not overlap."""
    dx, dy = b.cx - a.cx, b.cy - a.cy
    best = None
    for ax, ay in ((a.ux, a.uy), (-a.uy, a.ux), (b.ux, b.uy), (-b.uy, b.ux)):
        ra = a.hx * abs(a.ux * ax + a.uy * ay) + a.hy * abs(-a.uy * ax + a.ux * ay)
        rb = b.hx * abs(b.ux * ax + b.uy * ay) + b.hy * abs(-b.uy * ax + b.ux * ay)
        d = dx * ax + dy * ay
        ov = ra + rb - abs(d)
        if ov < 0:
            return None
        if best is None or ov < best[0]:
            best = (ov, ax if d >= 0 else -ax, ay if d >= 0 else -ay)
    return best
