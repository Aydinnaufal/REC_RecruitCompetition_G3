"""The arena: walls, pillars and cubes, and what happens when they collide."""

import math

from .constants import (
    CUBE_S,
    DROP_HEIGHT,
    FIELD,
    FRICTION,
    G,
    PILLAR_H,
    PILLAR_W,
    PILLAR_XS,
    PILLAR_YS,
    RESTITUTION,
    WALL_H,
    WALL_T,
)
from .geometry import OBB, aabb_apart, sat, z_overlap


class Cube:
    """One 3 cm cube."""

    def __init__(self, cid, team, x, y, z=0.0):
        """A cube of team colour `team` at (x, y, z)."""
        self.id, self.team = cid, team
        self.x, self.y, self.z, self.th = x, y, z, 0.0
        self.vx = self.vy = self.vz = 0.0
        self.held = self.pinned = False
        self.dx = self.dy = 0.0  # how far it was pushed this step
        self.px, self.py = x, y  # position at the start of the step
        self.on, self.off = None, (0.0, 0.0)  # the cube it rests on, and where on it

    def obb(self):
        """Its collision box."""
        return OBB(self.x, self.y, CUBE_S / 2, CUBE_S / 2, self.th, self.z, self.z + CUBE_S, self)


class World:
    """Walls, pillars and 12 cubes (a cube released over another one lands on it)."""

    def __init__(self):
        """Build walls, pillars and cubes."""
        self.statics, self.pillars, self.cubes = [], [], []
        self._build()
        self.reset_cubes()

    def _build(self):
        """Place the walls and pillars."""
        S = self.statics

        def wall(x0, y0, x1, y1):
            hx = abs(x1 - x0) / 2 + WALL_T / 2 if y0 == y1 else WALL_T / 2
            hy = abs(y1 - y0) / 2 + WALL_T / 2 if x0 == x1 else WALL_T / 2
            S.append(OBB((x0 + x1) / 2, (y0 + y1) / 2, hx, hy, 0.0, 0.0, WALL_H, 'wall'))

        for a, b in WALLS:
            wall(a[0], a[1], b[0], b[1])
        big = FIELD + 20
        for cx, cy, hx, hy in (
            (-FIELD - 5, 0, 5, big),
            (FIELD + 5, 0, 5, big),
            (0, -FIELD - 5, big, 5),
            (0, FIELD + 5, big, 5),
        ):
            S.append(OBB(cx, cy, hx, hy, 0.0, 0.0, WALL_H, 'boundary'))
        for sgn in (1, -1):
            for px in PILLAR_XS:
                for py in PILLAR_YS:
                    p = OBB(
                        sgn * px, sgn * py, PILLAR_W / 2, PILLAR_W / 2, 0.0, 0.0, PILLAR_H, 'pillar'
                    )
                    S.append(p)
                    self.pillars.append(p)

    def reset_cubes(self):
        """Put the cubes back on their start positions."""
        self.cubes, n = [], 0
        for sgn, team in ((1, 'B'), (-1, 'R')):
            for py in PILLAR_YS:
                for px in PILLAR_XS:
                    n += 1
                    self.cubes.append(Cube(n, team, sgn * px, sgn * py, PILLAR_H + DROP_HEIGHT))

    def free_cubes(self):
        """The cubes nobody is holding."""
        return [c for c in self.cubes if not c.held]

    def support_height(self, x, y):
        """Height of the floor or pillar under (x, y)."""
        for p in self.pillars:
            if abs(x - p.cx) <= p.hx and abs(y - p.cy) <= p.hy:
                return PILLAR_H
        return 0.0

    def support_of(self, c):
        """(height, cube underneath or None): the floor, a pillar top, or the top of a cube under this one's centre."""
        h, base = self.support_height(c.x, c.y), None
        for o in self.cubes:
            if o is c or o.z + CUBE_S > c.z + 0.05:
                continue
            if abs(c.x - o.x) <= CUBE_S / 2 and abs(c.y - o.y) <= CUBE_S / 2 and o.z + CUBE_S > h:
                h, base = o.z + CUBE_S, o
        return h, base

    def mark(self):
        """Remember each cube's position so pushes can be measured."""
        for c in self.cubes:
            c.px, c.py = c.x, c.y

    def step_cubes(self, dt):
        """Gravity, friction and landing. Call after resolve(). A cube that was pushed already moved; its speed is taken from the push."""
        for c in sorted(self.free_cubes(), key=lambda q: q.z):
            pushed = bool(c.dx or c.dy)
            if (
                c.on is not None and c.on.held
            ):  # the cube under it is carried by the robot: it rides along
                c.x, c.y = c.on.x + c.off[0], c.on.y + c.off[1]
                c.z, c.vz = c.on.z + CUBE_S, 0.0
                c.dx = c.dy = c.vx = c.vy = 0.0
                continue
            sup, base = self.support_of(c)
            c.on = base
            if base is not None:
                c.off = (c.x - base.x, c.y - base.y)
            if (
                base is not None and c.z <= sup + 0.05 and c.vz >= -1e-9
            ):  # resting on a cube: moves with it
                if not pushed:
                    c.x += base.x - base.px
                    c.y += base.y - base.py
                c.z, c.vz = sup, 0.0
                c.dx = c.dy = c.vx = c.vy = 0.0
                continue
            if pushed:
                vx, vy = c.dx / dt, c.dy / dt
                sp = math.hypot(vx, vy)
                if sp > 90.0:
                    vx, vy = vx * 90.0 / sp, vy * 90.0 / sp
                c.vx, c.vy = vx, vy
            c.dx = c.dy = 0.0
            if c.z > sup + 1e-6 or c.vz != 0.0:  # in the air
                c.vz -= G * dt
                c.z += c.vz * dt
                if c.z <= sup:
                    c.z = sup
                    c.vz = -c.vz * RESTITUTION if c.vz < -25.0 else 0.0
            else:  # resting: friction
                c.z = sup
                sp = math.hypot(c.vx, c.vy)
                if sp > 0 and not pushed:
                    k = max(0.0, sp - FRICTION * G * dt) / sp
                    c.vx *= k
                    c.vy *= k
                    if sp * k < 0.05:
                        c.vx = c.vy = 0.0
            if not pushed:
                c.x += c.vx * dt
                c.y += c.vy * dt

    def resolve(self, robot_parts, shift_robot, iters=5):
        """Push apart everything that overlaps. The robot pushes cubes, walls and pillars stop both."""
        free = self.free_cubes()
        for c in free:
            c.pinned = False
        for _ in range(iters):
            moved = False
            for c in free:  # cubes against walls and pillars
                ob = c.obb()
                for s in self.statics:
                    if aabb_apart(ob, s) or not z_overlap(ob, s):
                        continue
                    r = sat(ob, s)
                    if r and r[0] > 1e-6:
                        d, nx, ny = r
                        c.x -= nx * d
                        c.y -= ny * d
                        c.dx -= nx * d
                        c.dy -= ny * d
                        c.pinned = moved = True
                        ob = c.obb()
            for part in robot_parts():  # robot against walls and pillars
                for s in self.statics:
                    if aabb_apart(part, s) or not z_overlap(part, s):
                        continue
                    r = sat(part, s)
                    if r and r[0] > 1e-6:
                        shift_robot(-r[1] * r[0], -r[2] * r[0])
                        moved = True
                        break
            for part in robot_parts():  # robot against cubes: the cube moves unless it is pinned
                for c in free:
                    ob = c.obb()
                    if aabb_apart(part, ob) or not z_overlap(part, ob):
                        continue
                    r = sat(part, ob)
                    if r and r[0] > 1e-6:
                        d, nx, ny = r
                        if c.pinned:
                            shift_robot(-nx * d, -ny * d)
                        else:
                            c.x += nx * d
                            c.y += ny * d
                            c.dx += nx * d
                            c.dy += ny * d
                        moved = True
            for i in range(len(free)):  # cubes against cubes
                a = free[i]
                for j in range(i + 1, len(free)):
                    b = free[j]
                    oa, ob = a.obb(), b.obb()
                    if aabb_apart(oa, ob) or not z_overlap(oa, ob):
                        continue
                    r = sat(oa, ob)
                    if r and r[0] > 1e-6:
                        d, nx, ny = r
                        wa = 0.0 if b.pinned and not a.pinned else 1.0
                        wb = 0.0 if a.pinned and not b.pinned else 1.0
                        tot = wa + wb
                        if tot == 0:
                            continue
                        a.x -= nx * d * wa / tot
                        a.y -= ny * d * wa / tot
                        a.dx -= nx * d * wa / tot
                        a.dy -= ny * d * wa / tot
                        b.x += nx * d * wb / tot
                        b.y += ny * d * wb / tot
                        b.dx += nx * d * wb / tot
                        b.dy += ny * d * wb / tot
                        moved = True
            if not moved:
                break


# the inner walls of the arena (also drawn by render_V_8_0_2)
WALLS = [
    ((-35, -105), (-35, -12.5)),
    ((-35, 12.5), (-35, 57.5)),
    ((-35, 82.5), (-35, 105)),
    ((35, -105), (35, -82.5)),
    ((35, -57.5), (35, -12.5)),
    ((35, 12.5), (35, 105)),
    ((-35, 35), (35, 35)),
    ((-35, -35), (35, -35)),
    ((-35, 105), (35, 105)),
    ((-35, -105), (35, -105)),
]
