"""The simulated robot: wheels, snap turns, controller input, and the follow-the-real-robot mode."""

import math
from collections import deque

from robot_station.mathutil import clamp, wrap_pi
from .constants import (
    SNAP_GIVE_UP_BASE_S,
    SNAP_GIVE_UP_S_PER_DEG,
    ACCEL,
    ALIGN_TOL,
    DECEL,
    DPAD_SPEED,
    DPAD_TURN,
    LAG,
    LT_TURN,
    MAX_SPEED,
    MAX_SUB,
    PARTS,
    SLOW_CM,
    SNAP_ACCEL,
    SPAWN,
    TRACK,
    TURN_GAIN,
    W_MAX,
)
from .geometry import OBB
from .tower import Tower
from .world import World


class Robot:
    """The simulated robot: pose, wheels, snap turns, controller input and the real-robot follow mode."""

    def __init__(self, arena=True):
        """With arena=True the world with cubes and walls is present."""
        self.arena = arena
        self.world, self.tower = World(), Tower()
        self.mode = 'arcade_snap'
        self.trail = deque(maxlen=500)
        self.reset_robot()

    # ---- state
    def reset_robot(self):
        """Back in the start box, tower in its start pose. The cubes stay where they are."""
        self.tower.release(self)
        self.tower.reset()
        self.x, self.y, self.th = SPAWN
        self.vl = self.vr = 0.0  # wheel speeds, -1 .. 1
        self.al = self.ar = 0.0  # wheel angles for the spokes
        self.speed = self.omega = self.vx = self.vy = 0.0
        self.snap_target, self.snap_w = None, 0.0
        self.snap_age = 0.0  # seconds the current snap turn has been running
        self.snap_limit = 0.0  # ... and how long it may take before it is given up
        self.snap_timed_out = False  # set when a turn was given up; the app reports it and clears this
        self.slow_cm = SLOW_CM  # speed with RT released, cm/s (RT raises it to MAX_SPEED): a setting in the dashboard
        self.follow = False  # True while a real robot's gyro drives the heading (Game / Monitor with the robot connected)
        self.raw_l = self.raw_r = (
            0.0  # what the sticks ask of each wheel, -1..1, with no simulated lag: this is what the real robot gets
        )
        self.turn_on, self._lt_prev = False, False
        self._prev, self.rt, self._t = {}, 0.0, 0.0
        self.trail.clear()
        self.zero()

    def reset(self):
        """Everything back to the start."""
        self.reset_robot()
        self.world.reset_cubes()

    def reset_cubes(self):
        """Put the cubes back (Game only)."""
        self.tower.release(self)
        self.world.reset_cubes()

    def set_arena(self, on):
        """Turn the arena on (Game) or off (Monitor)."""
        if on != self.arena:
            self.arena = on
            self.reset()

    def zero(self):
        """The current heading becomes the zero: Y / B / A / X face up / right / down / left from here."""
        self.ref_th = self.th

    @property
    def heading_deg(self):
        """The compass number: 0 at the zero direction, bigger when turning right."""
        return (-math.degrees(self.th - self.ref_th)) % 360

    @property
    def snapping(self):
        """True while a snap turn is running."""
        return self.snap_target is not None

    @property
    def speed_scale(self):
        """Fraction of full speed that the RT trigger allows (see slow_cm)."""
        return (self.slow_cm + (MAX_SPEED - self.slow_cm) * clamp(self.rt, 0.0, 1.0)) / MAX_SPEED

    # ---- frames
    def to_world(self, x, y):
        """Robot frame -> world frame."""
        c, s = math.cos(self.th), math.sin(self.th)
        return self.x + x * c - y * s, self.y + x * s + y * c

    def to_robot(self, wx, wy):
        """World frame -> robot frame."""
        dx, dy = wx - self.x, wy - self.y
        c, s = math.cos(self.th), math.sin(self.th)
        return dx * c + dy * s, -dx * s + dy * c

    def point_velocity(self, wx, wy):
        """Velocity of a world point that is fixed to the robot."""
        return self.vx - self.omega * (wy - self.y), self.vy + self.omega * (wx - self.x)

    def parts(self):
        """The collision boxes of body, wheels and tower."""
        out = [
            OBB(*self.to_world(cx, cy), hx, hy, self.th, z0, z1, 'body')
            for cx, cy, hx, hy, z0, z1 in PARTS
        ]
        out += self.tower.parts(self)
        if self.tower.held is not None:
            out.append(self.tower.held.obb())
        return out

    def _shift(self, dx, dy):
        """Move the robot (used to push it out of collisions)."""
        self.x += dx
        self.y += dy

    # ---- input
    def _edge(self, st, name):
        """True once when a button goes from released to pressed."""
        now, was = bool(st.buttons.get(name)), self._prev.get(name, False)
        self._prev[name] = now
        return now and not was

    def cancel_snap(self):
        """Drop a snap turn in progress (BACK on the controller). Without this a turn the robot cannot finish would wait for ever."""
        self.snap_target = None
        self.snap_w = 0.0

    def watch_snap(self, h):
        """Give up a snap turn that takes too long (the robot may be blocked, or its own turn timed out) so the controls are free again."""
        if self.snap_target is None:
            self.snap_age = 0.0
            return
        if self.snap_age == 0.0:  # first step of this turn: the limit follows the size of the turn
            err = abs(math.degrees(wrap_pi(self.snap_target - self.th)))
            self.snap_limit = SNAP_GIVE_UP_BASE_S + SNAP_GIVE_UP_S_PER_DEG * err
        self.snap_age += h
        if self.snap_age > self.snap_limit:
            self.cancel_snap()
            self.snap_age = 0.0
            self.snap_timed_out = True

    def face(self, ang):
        """Start a snap turn to `ang` relative to the zero heading."""
        err = wrap_pi(self.ref_th + ang - self.th)
        if abs(err) >= ALIGN_TOL:
            self.snap_target = self.th + err

    def _buttons(self, st):
        """Button actions: START = new zero, LB / RB / Y / B / A / X = snap turns."""
        edges = {n: self._edge(st, n) for n in ('START', 'LB', 'RB', 'Y', 'B', 'A', 'X')}
        if edges['START']:
            self.zero()
        if self.mode != 'arcade_snap':
            self.snap_target = None
            return
        if self.snapping:
            if abs(st.lx) + abs(st.ly) > 0.4 or st.dpad != (0, 0):
                self.cancel_snap()  # the driver takes over: a stick or the D-pad ends the turn at once
            return  # presses during a turn are ignored: one turn per press
        if edges['LB']:
            self.snap_target = self.th + math.pi / 2
        elif edges['RB']:
            self.snap_target = self.th - math.pi / 2
        elif edges['Y']:
            self.face(0.0)
        elif edges['B']:
            self.face(-math.pi / 2)
        elif edges['A']:
            self.face(math.pi)
        elif edges['X']:
            self.face(math.pi / 2)

    def _targets(self, st):
        """Wheel targets in cm/s. The D-pad nudges slowly (not affected by RT); otherwise the left stick, turning only while TURN is on."""
        dx, dy = st.dpad
        if dx or dy:
            v, w = dy * DPAD_SPEED, -dx * DPAD_TURN
            return v - w * TRACK / 2.0, v + w * TRACK / 2.0
        s = self.speed_scale
        turn = st.lx if self.turn_on else 0.0
        return (
            clamp(st.ly + TURN_GAIN * turn, -1, 1) * s * MAX_SPEED,
            clamp(st.ly - TURN_GAIN * turn, -1, 1) * s * MAX_SPEED,
        )

    @staticmethod
    def _approach(v, target, h):
        """One wheel: first-order lag toward the target, with limited acceleration and deceleration."""
        nv = v + (target - v) * min(1.0, h * LAG)
        lim = (ACCEL if abs(nv) > abs(v) else DECEL) * h
        return v + clamp(nv - v, -lim, lim)

    # ---- one frame
    def drive(self, st, dt):
        """Advance the simulation by dt seconds with the controller state `st`."""
        self._st = st
        self.rt = st.rt
        lt = st.lt >= LT_TURN
        if lt and not self._lt_prev:
            self.turn_on = not self.turn_on  # each press of LT switches turning on / off
        self._lt_prev = lt
        self.tower.set_cmd(clamp(st.rx, 0.0, 1.0), st.ry)
        self._buttons(st)
        self.watch_snap(dt)
        n = max(1, int(math.ceil(dt / MAX_SUB - 1e-9)))
        for _ in range(n):
            self._substep(st, dt / n)

    def _substep(self, st, h):
        """One small physics step."""
        self.world.mark()
        if self.follow:
            self._follow_step(h)
        elif self.snapping:
            self._snap_step(h)
        else:
            tl, tr = self._targets(st)
            self.raw_l, self.raw_r = tl / MAX_SPEED, tr / MAX_SPEED
            vl, vr = self._approach(self.vl * MAX_SPEED, tl, h), self._approach(
                self.vr * MAX_SPEED, tr, h
            )
            self.vl, self.vr = vl / MAX_SPEED, vr / MAX_SPEED
            self.speed = (vl + vr) / 2.0
            self.omega = (vr - vl) / TRACK
            self.th += self.omega * h
            self.vx, self.vy = -math.sin(self.th) * self.speed, math.cos(self.th) * self.speed
            self.x += self.vx * h
            self.y += self.vy * h
        self.al += self.vl * MAX_SPEED * h / 3.0
        self.ar += self.vr * MAX_SPEED * h / 3.0
        self.tower.move(h)
        self.tower.sync_held(self)
        if self.arena:
            self.world.resolve(self.parts, self._shift)
            self.tower.sync_held(self)
            self.world.step_cubes(h)
            self.tower.update_grip(self, self.world)
        self._t += h
        if self._t > 0.06 and abs(self.speed) > 0.5:
            self._t = 0.0
            self.trail.append((self.x, self.y))

    def follow_robot(self, on, yaw_deg=0.0, gz_dps=0.0, vl_pct=0.0, vr_pct=0.0):
        """Real robot connected: its gyro IS the heading (turning left raises yaw, same as th). Wheel speeds come from its telemetry."""
        self.follow = bool(on)
        if on:
            self.th, self.omega = math.radians(yaw_deg), math.radians(gz_dps)
            self.vl, self.vr = vl_pct / 100.0, vr_pct / 100.0
            self.speed = (self.vl + self.vr) / 2.0 * MAX_SPEED

    def _follow_step(self, h):
        """Step while following the real robot: heading comes from its gyro, position is dead reckoned."""
        tl, tr = self._targets(self._st) if getattr(self, '_st', None) is not None else (0.0, 0.0)
        self.raw_l, self.raw_r = (0.0, 0.0) if self.snapping else (tl / MAX_SPEED, tr / MAX_SPEED)
        if (
            self.snapping
            and abs(wrap_pi(self.snap_target - self.th)) < math.radians(1.5)
            and abs(self.omega) < math.radians(12)
        ):
            self.snap_target = None  # the robot arrived: its own gyro says so
        self.vx, self.vy = -math.sin(self.th) * self.speed, math.cos(self.th) * self.speed
        self.x += self.vx * h
        self.y += self.vy * h

    def _snap_step(self, h):
        """Spin in place about the wheel midpoint: accelerate, cruise, brake so the heading arrives exactly on target with zero speed."""
        err = self.snap_target - self.th
        w_des = math.copysign(min(W_MAX, math.sqrt(2.0 * 0.8 * SNAP_ACCEL * abs(err))), err)
        self.snap_w += clamp(w_des - self.snap_w, -SNAP_ACCEL * h, SNAP_ACCEL * h)
        step = self.snap_w * h
        if abs(step) >= abs(err) or (err != 0 and step * err < 0):
            self.th, self.snap_target, self.snap_w = self.snap_target, None, 0.0
        else:
            self.th += step
        self.raw_l = self.raw_r = 0.0
        w = self.snap_w
        self.vl, self.vr = -w * TRACK / 2.0 / MAX_SPEED, w * TRACK / 2.0 / MAX_SPEED
        self.speed, self.omega, self.vx, self.vy = 0.0, w, 0.0, 0.0

    # ---- what the picture and the panels need (a plain dict, so real robot data can fill the same shape)
    def snapshot(self):
        """Everything the pictures and panels need, as a plain dict."""
        t = self.tower
        return dict(
            x=self.x,
            y=self.y,
            th=self.th,
            ref_th=self.ref_th,
            heading=self.heading_deg,
            vl=self.vl,
            vr=self.vr,
            al=self.al,
            ar=self.ar,
            speed=self.speed,
            omega=self.omega,
            lift=t.lift,
            pad=t.ext,
            cmd=t.pad_cmd,
            holding=t.held is not None,
            touching=t.contact,
            turn_on=self.turn_on,
            snapping=self.snapping,
            mode=self.mode,
            rt=self.rt,
            speed_scale=self.speed_scale,
            source='sim',
        )
