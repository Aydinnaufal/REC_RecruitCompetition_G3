"""Drawing primitives: clipped polygons and lines seen through the camera."""

import pygame

from .palette import NEAR


def _clip_poly(pc):
    """Clip a polygon in camera space against the near plane."""
    out = []
    for i, a in enumerate(pc):
        b = pc[(i + 1) % len(pc)]
        ain, bin_ = a[2] >= NEAR, b[2] >= NEAR
        if ain:
            out.append(a)
        if ain != bin_:
            t = (NEAR - a[2]) / (b[2] - a[2])
            out.append(tuple(a[k] + (b[k] - a[k]) * t for k in range(3)))
    return out


def poly(surf, cam, color, pts, width=0):
    """Draw a filled or outlined polygon given in world coordinates."""
    pc = _clip_poly([cam.cam(p) for p in pts])
    if len(pc) >= 3:
        pygame.draw.polygon(surf, color, [cam.screen(c) for c in pc], width)


def line(surf, cam, color, a, b, width=1):
    """Draw a line given in world coordinates."""
    ca, cb = cam.cam(a), cam.cam(b)
    if ca[2] < NEAR and cb[2] < NEAR:
        return
    if ca[2] < NEAR:
        ca = tuple(ca[k] + (cb[k] - ca[k]) * (NEAR - ca[2]) / (cb[2] - ca[2]) for k in range(3))
    if cb[2] < NEAR:
        cb = tuple(cb[k] + (ca[k] - cb[k]) * (NEAR - cb[2]) / (ca[2] - cb[2]) for k in range(3))
    pygame.draw.line(surf, color, cam.screen(ca), cam.screen(cb), width)


def rect3(x0, y0, x1, y1, z=0.0):
    """Corners of an axis-aligned rectangle at height z."""
    return [(x0, y0, z), (x1, y0, z), (x1, y1, z), (x0, y1, z)]
