"""The camera and the person's display options (trail, shadow, arrow, zoom)."""

import math

from robot_station.mathutil import clamp


class Camera:
    """A simple pinhole camera."""

    def __init__(self, w, h, fl):
        """A viewport of w x h pixels with focal length fl."""
        self.cx, self.cy, self.fl = w / 2.0, h / 2.0, fl
        self.eye, self.f, self.r, self.u = (0, -100, 100), (0, 1, 0), (1, 0, 0), (0, 0, 1)

    @staticmethod
    def _norm(v):
        """Unit vector."""
        n = math.sqrt(sum(c * c for c in v)) or 1.0
        return tuple(c / n for c in v)

    def look(self, eye, target, up=(0, 0, 1)):
        """Point the camera from `eye` at `target`."""
        f = self._norm(tuple(t - e for t, e in zip(target, eye)))
        r = self._norm(
            (f[1] * up[2] - f[2] * up[1], f[2] * up[0] - f[0] * up[2], f[0] * up[1] - f[1] * up[0])
        )
        u = (r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0])
        self.eye, self.f, self.r, self.u = eye, f, r, u

    def cam(self, p):
        """World point -> camera coordinates (right, up, depth)."""
        d = (p[0] - self.eye[0], p[1] - self.eye[1], p[2] - self.eye[2])
        dot = lambda a, b: a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
        return (dot(d, self.r), dot(d, self.u), dot(d, self.f))

    def screen(self, c):
        """Camera coordinates -> pixel position."""
        return (self.cx + self.fl * c[0] / c[2], self.cy - self.fl * c[1] / c[2])


class Look:
    """The mouse camera and the three overlays. trail / shadow / arrow: a switch and an OPACITY from 0 (invisible) to 1 (solid)."""

    def __init__(self):
        """Default overlays and camera orbit."""
        self.reset_cam()
        self.trail_on, self.trail_i = True, 0.9
        self.shadow_on, self.shadow_i = True, 0.35
        self.arrow_on, self.arrow_i = True, 0.8

    def reset_cam(self):
        """Back to the default orbit and zoom."""
        self.yaw, self.pitch, self.dist, self.zoom = 0.5, 0.55, 80.0, 1.0

    def drag(self, dx, dy):
        """Mouse drag turns the free camera."""
        self.yaw -= dx * 0.008
        self.pitch = clamp(self.pitch + dy * 0.008, 0.05, 1.5)

    def wheel(self, n):
        """Mouse wheel zooms the free camera."""
        self.zoom = clamp(self.zoom * (0.88**n), 0.15, 5.0)
