"""Colours, view names and drawing constants of the 3D pictures."""

NEAR = 2.0
WHEEL_R, WHEEL_W = 3.0, 2.4
VIEWS_GAME = ['arena', 'chase', 'top', 'front', 'right', 'left', 'free']
VIEWS_MONITOR = ['iso', 'front', 'right', 'left', 'back', 'top', 'free']
VIEW_LABEL = {
    'arena': 'Arena',
    'chase': 'Chase (behind)',
    'top': 'Top',
    'front': 'Front',
    'right': 'Right side',
    'left': 'Left side',
    'iso': 'Angled',
    'back': 'Back',
    'free': 'Free (mouse)',
}
BACKGROUND = (20, 23, 28)
FLOOR = (34, 38, 44)
ZONES = [
    ((-105, -105, -35, 105), (44, 58, 108)),
    ((35, -105, 105, 105), (112, 52, 56)),
    ((-35, 35, 35, 105), (62, 72, 118)),
    ((-35, -35, 35, 35), (74, 78, 84)),
    ((-35, -105, 35, -35), (104, 64, 68)),
]
WALL_COL, PILLAR_COL = (196, 154, 108), (214, 216, 220)
CUBE_COL = {'B': (48, 96, 232), 'R': (226, 66, 62)}
BODY, DECK, NOSE = (96, 112, 138), (140, 156, 182), (0, 200, 170)
TOWER_COL, MAST_COL, SERVO_COL, POST_COL, ARM_COL = (
    (60, 200, 190),
    (74, 82, 98),
    (44, 48, 58),
    (64, 70, 82),
    (238, 168, 58),
)
TYRE, RIM, SPOKE = (62, 66, 76), (88, 94, 106), (0, 235, 195)
MARK_COL = (255, 200, 90)
LIGHT = (-0.35, -0.45, 0.82)
