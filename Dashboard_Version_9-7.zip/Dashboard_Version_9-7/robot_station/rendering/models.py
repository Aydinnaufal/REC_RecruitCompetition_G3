"""The 3D shapes of the tower robot, wheels and cubes, sorted and painted back to front."""

import math

from robot_station import simulation
from .palette import (
    ARM_COL,
    BODY,
    DECK,
    LIGHT,
    MAST_COL,
    NOSE,
    POST_COL,
    RIM,
    SERVO_COL,
    SPOKE,
    TOWER_COL,
    TYRE,
    WHEEL_R,
    WHEEL_W,
)
from .primitives import poly


def _box(x0, y0, z0, x1, y1, z1, color):
    """Faces of an axis-aligned box: (points, outward normal, colour)."""
    return [
        ([(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0)], (0, 0, -1), color),
        ([(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)], (0, 0, 1), color),
        ([(x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1)], (0, -1, 0), color),
        ([(x0, y1, z0), (x1, y1, z0), (x1, y1, z1), (x0, y1, z1)], (0, 1, 0), color),
        ([(x0, y0, z0), (x0, y1, z0), (x0, y1, z1), (x0, y0, z1)], (-1, 0, 0), color),
        ([(x1, y0, z0), (x1, y1, z0), (x1, y1, z1), (x1, y0, z1)], (1, 0, 0), color),
    ]


def _wheel(side, angle, n=14):
    """A wheel as an n-sided prism (axis = robot x) with four bright spokes and a hub, so its turning can be seen."""
    xc = side * simulation.TRACK / 2.0
    xi, xo = xc - WHEEL_W / 2, xc + WHEEL_W / 2
    cz = WHEEL_R
    ring = [
        (WHEEL_R * math.cos(2 * math.pi * k / n), cz + WHEEL_R * math.sin(2 * math.pi * k / n))
        for k in range(n)
    ]
    faces = []
    for k in range(n):
        (ya, za), (yb, zb) = ring[k], ring[(k + 1) % n]
        mid = 2 * math.pi * (k + 0.5) / n
        faces.append(
            (
                [(xi, ya, za), (xo, ya, za), (xo, yb, zb), (xi, yb, zb)],
                (0, math.cos(mid), math.sin(mid)),
                TYRE,
            )
        )
    for x, nx in ((xi, -1), (xo, 1)):
        faces.append(([(x, y, z) for y, z in ring], (nx, 0, 0), RIM))
    xs = xo + 0.06 if side > 0 else xi - 0.06
    for k in range(4):
        a = angle + k * math.pi / 2
        p = lambda r, w: (
            xs,
            r * math.cos(a) - w * math.sin(a),
            cz + r * math.sin(a) + w * math.cos(a),
        )
        faces.append(
            (
                [p(0, 0.55), p(WHEEL_R * 0.9, 0.55), p(WHEEL_R * 0.9, -0.55), p(0, -0.55)],
                (side, 0, 0),
                SPOKE,
            )
        )
    faces.append(
        (
            [
                (
                    xs + 0.01 * side,
                    0.9 * math.cos(2 * math.pi * k / 8),
                    cz + 0.9 * math.sin(2 * math.pi * k / 8),
                )
                for k in range(8)
            ],
            (side, 0, 0),
            (235, 240, 245),
        )
    )
    return faces


def _xform(faces, ang, ox, oy, oz=0.0):
    """Rotate faces by `ang` and move them to (ox, oy, oz)."""
    c, s = math.cos(ang), math.sin(ang)
    return [
        (
            [(ox + p[0] * c - p[1] * s, oy + p[0] * s + p[1] * c, oz + p[2]) for p in pts],
            (n[0] * c - n[1] * s, n[0] * s + n[1] * c, n[2]),
            col,
        )
        for pts, n, col in faces
    ]


def tower_faces(d):
    """The faces of the tower robot for a snapshot dict `d`."""
    lift, ext = d['lift'], d['pad']
    f = []
    for sx in (-1, 1):
        for sy in (-1, 1):
            f += _box(
                sx * 5.0 - 0.5,
                sy * 6.8 - 0.5,
                0.0,
                sx * 5.0 + 0.5,
                sy * 6.8 + 0.5,
                simulation.BODY_Z[0],
                POST_COL,
            )  # chassis posts
    for cx, cy, hx, hy, z0, z1 in simulation.PARTS[:4]:
        f += _box(cx - hx, cy - hy, z0, cx + hx, cy + hy, z1, BODY)  # chassis plates
    f += _wheel(-1, d['al']) + _wheel(1, d['ar'])
    f += _box(-1.0, -3.9, 8.0, 1.0, -2.7, 20.0, MAST_COL)  # rack column
    f += _box(-1.7, -4.5, 18.0, 1.7, -2.2, 20.0, SERVO_COL)  # lift servo
    f += _box(-1.0, -2.7, lift + 5.0, 1.0, -2.15, lift + 7.5, ARM_COL)  # carriage
    i, w, o = simulation.BOX_IN, simulation.BOX_WALL, simulation.BOX_OUT
    for cx, cy, hx, hy in (
        (0.0, i / 2 + w / 2, o / 2, w / 2),
        (0.0, -i / 2 - w / 2, o / 2, w / 2),
        (i / 2 + w / 2, 0.0, w / 2, i / 2),
        (-i / 2 - w / 2, 0.0, w / 2, i / 2),
    ):
        f += _box(
            cx - hx, cy - hy, lift, cx + hx, cy + hy, lift + simulation.BOX_H, ('wire', TOWER_COL)
        )  # the box, see-through
    f += _box(
        i / 2 - ext,
        -simulation.PAD_Y_HALF,
        lift + simulation.PAD_Z0,
        i / 2,
        simulation.PAD_Y_HALF,
        lift + simulation.PAD_Z1,
        ARM_COL,
    )  # the pad
    f += _box(o / 2, -1.4, lift + 0.8, o / 2 + 1.2, 1.4, lift + 3.6, SERVO_COL)  # pad servo
    f.append(
        ([(-2.5, -6.5, 8.02), (2.5, -6.5, 8.02), (0, -3.6, 8.02)], (0, 0, 1), DECK)
    )  # arrow on the chassis
    f += _box(-3.0, 7.2, 8.0, 3.0, 8.0, 8.4, NOSE)  # front marker
    return f


def _items(cam, faces, W, N, out):
    """Turn faces into sortable draw items."""
    for pts, n, col in faces:
        wire = isinstance(col[0], str)
        if wire:
            col = col[1]
        wp, wn = [W(p) for p in pts], N(n)
        ctr = tuple(sum(p[k] for p in wp) / len(wp) for k in range(3))
        if not wire:
            view = (cam.eye[0] - ctr[0], cam.eye[1] - ctr[1], cam.eye[2] - ctr[2])
            if wn[0] * view[0] + wn[1] * view[1] + wn[2] * view[2] <= 0:
                continue
        shade = 0.5 + 0.5 * max(0.0, wn[0] * LIGHT[0] + wn[1] * LIGHT[1] + wn[2] * LIGHT[2])
        out.append((cam.cam(ctr)[2], col if wire else tuple(int(v * shade) for v in col), wp, wire))


def _box_world(cx, cy, hx, hy, ang, z0, z1, col, cam, out, seg=None):
    """A box at a world position. With seg a long wall is cut into pieces so it depth-sorts correctly."""
    n = max(1, round(2 * hx / seg)) if seg else 1
    h = hx / n
    c, s = math.cos(ang), math.sin(ang)
    for k in range(n):
        off = -hx + (k + 0.5) * 2 * hx / n
        _items(
            cam,
            _box(-h, -hy, z0, h, hy, z1, col),
            lambda p: (cx + (p[0] + off) * c - p[1] * s, cy + (p[0] + off) * s + p[1] * c, p[2]),
            lambda nv: (nv[0] * c - nv[1] * s, nv[0] * s + nv[1] * c, nv[2]),
            out,
        )


def _robot_items(cam, d, ox, oy, out):
    """Draw items of the whole robot."""
    s, co = math.sin(d['th']), math.cos(d['th'])
    fwd, rgt = (-s, co), (co, s)
    _items(
        cam,
        tower_faces(d),
        lambda p: (ox + p[0] * rgt[0] + p[1] * fwd[0], oy + p[0] * rgt[1] + p[1] * fwd[1], p[2]),
        lambda n: (n[0] * rgt[0] + n[1] * fwd[0], n[0] * rgt[1] + n[1] * fwd[1], n[2]),
        out,
    )


def _paint(surf, cam, items):
    """Paint items far to near."""
    for _, col, wp, wire in sorted(items, key=lambda t: -t[0]):
        if wire:
            poly(surf, cam, col, wp, 1)
        else:
            poly(surf, cam, col, wp)
            poly(surf, cam, tuple(int(v * 0.6) for v in col), wp, 1)
