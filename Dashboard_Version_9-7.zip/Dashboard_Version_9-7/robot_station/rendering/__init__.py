"""The 3D pictures of the arena and the robot, drawn with pygame polygons."""

from .palette import (
    NEAR,
    WHEEL_R,
    WHEEL_W,
    VIEWS_GAME,
    VIEWS_MONITOR,
    VIEW_LABEL,
    BACKGROUND,
    FLOOR,
    ZONES,
    WALL_COL,
    PILLAR_COL,
    CUBE_COL,
    BODY,
    DECK,
    NOSE,
    TOWER_COL,
    MAST_COL,
    SERVO_COL,
    POST_COL,
    ARM_COL,
    TYRE,
    RIM,
    SPOKE,
    MARK_COL,
    LIGHT,
)
from .camera import Camera, Look
from .primitives import poly, line, rect3
from .models import tower_faces
from .scene import draw_floor, set_view, draw_scene, draw_monitor
