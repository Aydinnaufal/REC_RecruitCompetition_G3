"""The pictures: the arena (Game) and the robot alone (Monitor), with the view presets and overlays."""

import math

import pygame

from robot_station import simulation
from robot_station.mathutil import clamp
from .models import _box_world, _paint, _robot_items
from .palette import BACKGROUND, CUBE_COL, FLOOR, MARK_COL, NEAR, PILLAR_COL, WALL_COL, ZONES
from .primitives import line, poly, rect3


def draw_floor(surf, cam):
    """The field floor, zones and markings."""
    F = simulation.FIELD
    poly(surf, cam, FLOOR, rect3(-F, -F, F, F))
    for (x0, y0, x1, y1), c in ZONES:
        poly(surf, cam, c, rect3(x0, y0, x1, y1, 0.01))
    for g in range(-100, 101, 10):
        c = (58, 64, 72) if g % 30 else (74, 82, 92)
        line(surf, cam, c, (g, -F, 0.02), (g, F, 0.02), 1)
        line(surf, cam, c, (-F, g, 0.02), (F, g, 0.02), 1)
    for sx, sy, col in ((-82, -92, (120, 150, 255)), (82, 92, (255, 130, 130))):  # start boxes
        poly(surf, cam, col, rect3(sx - 10, sy - 10, sx + 10, sy + 10, 0.03), 2)
    for my in (90, 0, -90):  # markers
        poly(surf, cam, (10, 10, 10), rect3(-5, my - 5, 5, my + 5, 0.04))
        poly(surf, cam, (200, 205, 210), rect3(-2.5, my - 2.5, 2.5, my + 2.5, 0.05))
    for sgn, col in (
        (1, (120, 150, 255)),
        (-1, (255, 130, 130)),
    ):  # storing zones and pillar squares
        poly(surf, cam, col, rect3(sgn * -102, -20, sgn * -76, 20, 0.03), 1)
        for px in (-95, -83):
            for py in (-13, 0, 13):
                poly(
                    surf,
                    cam,
                    (235, 235, 235),
                    rect3(sgn * px - 2, sgn * py - 2, sgn * px + 2, sgn * py + 2, 0.06),
                )
    for a, b in simulation.WALLS:
        line(surf, cam, WALL_COL, (a[0], a[1], 0.08), (b[0], b[1], 0.08), 3)
    for a, b in (((-F, -F), (F, -F)), ((F, -F), (F, F)), ((F, F), (-F, F)), ((-F, F), (-F, -F))):
        line(surf, cam, (150, 160, 172), (a[0], a[1], 0.08), (b[0], b[1], 0.08), 2)


def _zl(cam, look, eye, target, up=(0, 0, 1)):
    """Aim the camera."""
    cam.look(tuple(t + (e - t) * look.zoom for e, t in zip(eye, target)), target, up=up)


def set_view(cam, view, x, y, th, look):
    """Place the camera for a named view (arena, top, follow, free ...)."""
    s, c = math.sin(th), math.cos(th)
    fwd, rgt = (-s, c), (c, s)
    zc = 9.0  # the camera looks at the middle of the tower
    if view == 'free':
        cam.fl, d = 400, look.dist
        _zl(
            cam,
            look,
            (
                x + d * math.cos(look.pitch) * math.sin(look.yaw),
                y - d * math.cos(look.pitch) * math.cos(look.yaw),
                zc + d * math.sin(look.pitch),
            ),
            (x, y, zc),
        )
    elif view in ('front', 'right', 'left', 'back'):
        cam.fl = 400
        v = {'front': fwd, 'back': (-fwd[0], -fwd[1]), 'right': rgt, 'left': (-rgt[0], -rgt[1])}[
            view
        ]
        _zl(cam, look, (x + v[0] * 50.0, y + v[1] * 50.0, zc + 24), (x, y, zc))
    elif view == 'chase':
        cam.fl = 430
        _zl(cam, look, (x + s * 52, y - c * 52, 34), (x - s * 14, y + c * 14, 3))
    elif view == 'top':
        cam.fl = 480
        _zl(cam, look, (0, 0, 265), (0, 0, 0), up=(0, 1, 0))
    elif view == 'iso':
        cam.fl = 400
        _zl(cam, look, (x + 46, y - 60, zc + 46), (x, y, zc))
    else:  # 'arena'
        cam.fl = 395
        _zl(cam, look, (0, -175, 205), (0, 0, 0))


def _overlays(surf, cam, look, trail, ref_th, ox, oy, shadow_pts):
    """Trail, robot shadow and zero arrow, all flat on the floor, on one transparent layer that is laid over the picture."""
    if not (look.trail_on or look.shadow_on or look.arrow_on):
        return
    layer = pygame.Surface((surf.get_width(), surf.get_height()), pygame.SRCALPHA)
    a255 = lambda k: int(255 * clamp(k, 0.0, 1.0))
    if look.shadow_on and look.shadow_i > 0:
        pts = [cam.cam(p) for p in shadow_pts]
        if all(p[2] > NEAR for p in pts):
            pygame.draw.polygon(layer, (0, 0, 0, a255(look.shadow_i)), [cam.screen(p) for p in pts])
    if look.trail_on and look.trail_i > 0:
        n = max(1, len(trail))
        for i, (tx, ty) in enumerate(trail):
            cc = cam.cam((tx, ty, 0.1))
            if cc[2] > NEAR:
                pygame.draw.circle(
                    layer,
                    (20, 200, 170, a255(look.trail_i * (0.25 + 0.75 * i / n))),
                    cam.screen(cc),
                    2,
                )
    if look.arrow_on and look.arrow_i > 0:
        col, z = MARK_COL + (a255(look.arrow_i),), 0.2
        zx, zy = -math.sin(ref_th), math.cos(ref_th)
        tip = (ox + zx * 30, oy + zy * 30, z)
        line(layer, cam, col, (ox, oy, z), tip, 2)
        line(layer, cam, col, tip, (ox + zx * 25 - zy * 3, oy + zy * 25 + zx * 3, z), 2)
        line(layer, cam, col, tip, (ox + zx * 25 + zy * 3, oy + zy * 25 - zx * 3, z), 2)
    surf.blit(layer, (0, 0))


def draw_scene(surf, cam, robot, view, look):
    """Game: floor, walls, pillars, cubes and the robot, depth sorted together."""
    surf.fill(BACKGROUND)
    d = robot.snapshot()
    set_view(cam, view, robot.x, robot.y, robot.th, look)
    draw_floor(surf, cam)
    _overlays(
        surf,
        cam,
        look,
        robot.trail,
        robot.ref_th,
        robot.x,
        robot.y,
        [robot.to_world(x, y) + (0.1,) for x, y in ((-8, -8), (8, -8), (8, 8), (-8, 8))],
    )
    w = robot.world
    for c in w.cubes:  # shadow of a raised cube
        sup = w.support_of(c)[0]
        if c.z > sup + 0.05:
            poly(
                surf,
                cam,
                (18, 20, 24),
                rect3(c.x - 1.5, c.y - 1.5, c.x + 1.5, c.y + 1.5, sup + 0.07),
            )
    items = []
    for st in w.statics:
        if st.tag == 'wall':
            _box_world(
                st.cx,
                st.cy,
                st.hx,
                st.hy,
                0.0,
                0.0,
                simulation.WALL_H,
                WALL_COL,
                cam,
                items,
                seg=8.0,
            )
        elif st.tag == 'pillar':
            _box_world(
                st.cx, st.cy, st.hx, st.hy, 0.0, 0.0, simulation.PILLAR_H, PILLAR_COL, cam, items
            )
    for c in w.cubes:
        _box_world(
            c.x,
            c.y,
            simulation.CUBE_S / 2,
            simulation.CUBE_S / 2,
            c.th,
            c.z,
            c.z + simulation.CUBE_S,
            CUBE_COL[c.team],
            cam,
            items,
        )
    _robot_items(cam, d, robot.x, robot.y, items)
    _paint(surf, cam, items)
    for c in w.cubes:  # far away a 3 cm cube is a pixel: keep it visible
        cc = cam.cam((c.x, c.y, c.z + simulation.CUBE_S / 2))
        if cc[2] > NEAR and cam.fl * simulation.CUBE_S / cc[2] < 7:
            sx, sy = cam.screen(cc)
            pygame.draw.rect(surf, CUBE_COL[c.team], (sx - 3, sy - 3, 7, 7))
            pygame.draw.rect(surf, (235, 235, 235), (sx - 3, sy - 3, 7, 7), 1)
        if c.held:
            cc = cam.cam((c.x, c.y, c.z + simulation.CUBE_S + 1.2))
            if cc[2] > NEAR:
                pygame.draw.circle(surf, (255, 235, 90), cam.screen(cc), 3)


def draw_monitor(surf, cam, d, view, look):
    """Monitor: the robot stays at the origin and turns in place; the grid under it slides as the robot moves. d is a snapshot() dict."""
    surf.fill(BACKGROUND)
    set_view(cam, view, 0.0, 0.0, d['th'], look)
    R = 64.0
    poly(surf, cam, (30, 34, 40), rect3(-R, -R, R, R, 0.0))
    for g in range(
        int(math.floor((d['x'] - R) / 10.0)) * 10, int(d['x'] + R) + 10, 10
    ):  # grid lines slide with the robot's x and y
        x = g - d['x']
        if -R <= x <= R:
            line(
                surf,
                cam,
                (92, 102, 114) if g % 50 == 0 else (52, 58, 66),
                (x, -R, 0.02),
                (x, R, 0.02),
                1,
            )
    for g in range(int(math.floor((d['y'] - R) / 10.0)) * 10, int(d['y'] + R) + 10, 10):
        y = g - d['y']
        if -R <= y <= R:
            line(
                surf,
                cam,
                (92, 102, 114) if g % 50 == 0 else (52, 58, 66),
                (-R, y, 0.02),
                (R, y, 0.02),
                1,
            )
    for a, b in (((-R, -R), (R, -R)), ((R, -R), (R, R)), ((R, R), (-R, R)), ((-R, R), (-R, -R))):
        line(surf, cam, (96, 106, 118), (a[0], a[1], 0.03), (b[0], b[1], 0.03), 2)
    line(
        surf, cam, (255, 120, 110), (0, R - 10, 0.05), (0, R, 0.05), 3
    )  # north mark: the zero direction of the map
    _overlays(
        surf,
        cam,
        look,
        (),
        d['ref_th'],
        0.0,
        0.0,
        [(-8, -8, 0.1), (8, -8, 0.1), (8, 8, 0.1), (-8, 8, 0.1)],
    )
    items = []
    _robot_items(cam, d, 0.0, 0.0, items)
    _paint(surf, cam, items)
