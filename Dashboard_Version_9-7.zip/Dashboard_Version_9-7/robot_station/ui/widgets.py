"""Clickable widgets (button, dropdown, stepper, tabs, text box, slider, spin box) and Group, which routes mouse and keys to a set of them."""

import pygame

from .canvas import text
from .theme import (
    ACCENT,
    BAR_BG,
    BTN,
    BTN_HOT,
    BTN_OFF,
    BTN_ON,
    DANGER,
    DANGER_HOT,
    DIM_TEXT,
    LINE,
    MUTED,
    TEXT,
)


class Widget:
    """Base class: a rectangle that can be hovered and clicked."""

    def __init__(self, rect):
        """Rectangle (x, y, w, h) on the design canvas."""
        self.rect = pygame.Rect(rect)
        self.hot = False

    def inside(self, pos):
        """True when the canvas position is inside the widget."""
        return pos is not None and self.rect.collidepoint(pos)


class Button(Widget):
    """A push button; `active` shows it switched on, `enabled` greys it out."""

    def __init__(self, rect, label, action, active=None, enabled=None, danger=False):
        """label and enabled/active can be text or functions."""
        super().__init__(rect)
        self.label, self.action, self.active, self.enabled, self.danger = (
            label,
            action,
            active,
            enabled,
            danger,
        )

    def is_enabled(self):
        """True unless the enabled test says otherwise."""
        return True if self.enabled is None else bool(self.enabled())

    def click(self, pos):
        """Run the action if the click is inside and the button is enabled."""
        if self.inside(pos) and self.is_enabled():
            self.action()
            return True
        return False

    def draw(self, surf, fonts):
        """Draw the button."""
        on, ok = bool(self.active()) if self.active else False, self.is_enabled()
        if self.danger:
            col = DANGER_HOT if self.hot else DANGER
        else:
            col = BTN_ON if on else (BTN_HOT if self.hot and ok else (BTN if ok else BTN_OFF))
        pygame.draw.rect(surf, col, self.rect, border_radius=7)
        pygame.draw.rect(surf, LINE if ok else (58, 64, 72), self.rect, 1, border_radius=7)
        lab = self.label() if callable(self.label) else self.label
        text(
            surf,
            fonts['s'],
            lab,
            self.rect.center,
            (255, 230, 225) if self.danger else (TEXT if ok else DIM_TEXT),
            'center',
        )


class Dropdown(Widget):
    """options: list of (value, label). get() returns the current value, set(value) changes it."""

    ITEM_H = 28

    def __init__(self, rect, title, options, get, set_, enabled=None):
        """Options are (value, label) pairs; get() and set_() read and change the value."""
        super().__init__(rect)
        self.title, self.options, self.get, self.set, self.enabled = (
            title,
            options,
            get,
            set_,
            enabled,
        )
        self.open, self.hot_item = False, -1

    def is_enabled(self):
        """True unless disabled."""
        return True if self.enabled is None else bool(self.enabled())

    def current_label(self):
        """The label of the selected option."""
        v = self.get()
        for val, lab in self.options:
            if val == v:
                return lab
        return str(v) if v not in (None, '') else '-'

    def item_rect(self, i):
        """Rectangle of list item i."""
        return pygame.Rect(
            self.rect.x, self.rect.bottom + 2 + i * self.ITEM_H, self.rect.w, self.ITEM_H
        )

    def click(self, pos):
        """Open, close or choose."""
        if self.open:
            for i, (val, _) in enumerate(self.options):
                if pos is not None and self.item_rect(i).collidepoint(pos):
                    self.set(val)
                    break
            self.open = False
            return True
        if self.inside(pos) and self.is_enabled() and self.options:
            self.open = True
            return True
        return False

    def draw(self, surf, fonts):
        """Draw the closed box."""
        ok = self.is_enabled()
        pygame.draw.rect(
            surf,
            BTN_HOT if (self.hot and ok) else (BTN if ok else BTN_OFF),
            self.rect,
            border_radius=7,
        )
        pygame.draw.rect(
            surf,
            ACCENT if self.open else (LINE if ok else (58, 64, 72)),
            self.rect,
            1,
            border_radius=7,
        )
        text(surf, fonts['s'], self.title, (self.rect.x + 8, self.rect.y - 14), MUTED)
        room = max(4, (self.rect.w - 34) // 8)  # characters that fit before the arrow
        text(
            surf,
            fonts['s'],
            self.current_label()[:room],
            (self.rect.x + 9, self.rect.centery - 7),
            TEXT if ok else DIM_TEXT,
        )
        cx, cy = self.rect.right - 14, self.rect.centery
        pygame.draw.polygon(surf, MUTED, [(cx - 5, cy - 2), (cx + 5, cy - 2), (cx, cy + 4)])

    def draw_list(self, surf, fonts):
        """Draw the open list (on top of everything else)."""
        if not self.open:
            return
        n = len(self.options)
        r = pygame.Rect(self.rect.x, self.rect.bottom + 2, self.rect.w, self.ITEM_H * n)
        pygame.draw.rect(surf, (36, 42, 50), r, border_radius=6)
        pygame.draw.rect(surf, ACCENT, r, 1, border_radius=6)
        cur, room = self.get(), max(4, (self.rect.w - 24) // 8)
        for i, (val, lab) in enumerate(self.options):
            ir = self.item_rect(i)
            if self.hot_item == i:
                pygame.draw.rect(surf, BTN_HOT, ir.inflate(-4, -2), border_radius=4)
            text(
                surf,
                fonts['s'],
                (('> ' if val == cur else '  ') + lab)[:room],
                (ir.x + 8, ir.centery - 7),
                ACCENT if val == cur else TEXT,
            )


class Stepper(Widget):
    """[ Label ] [-] 55% [+] : a switch for showing something, and its opacity in 5% steps. Fits in 160 x 24."""

    def __init__(self, rect, label, get_on, set_on, get_val, set_val, step=0.05):
        """A switch with a value that goes up and down."""
        super().__init__(rect)
        self.label, self.get_on, self.set_on, self.get_val, self.set_val, self.step = (
            label,
            get_on,
            set_on,
            get_val,
            set_val,
            step,
        )
        r = self.rect
        self.r_tog = pygame.Rect(r.x, r.y, 62, r.h)
        self.r_minus = pygame.Rect(r.x + 66, r.y, 24, r.h)
        self.r_plus = pygame.Rect(r.x + 66 + 24 + 38, r.y, 24, r.h)

    def click(self, pos):
        """Toggle the switch or step the value."""
        if pos is None:
            return False
        if self.r_tog.collidepoint(pos):
            self.set_on(not self.get_on())
        elif self.r_minus.collidepoint(pos):
            self.set_val(max(0.0, round(self.get_val() - self.step, 2)))
        elif self.r_plus.collidepoint(pos):
            self.set_val(min(1.0, round(self.get_val() + self.step, 2)))
        else:
            return False
        return True

    def draw(self, surf, fonts):
        """Draw the stepper."""
        on = self.get_on()
        pygame.draw.rect(surf, BTN_ON if on else BTN, self.r_tog, border_radius=7)
        pygame.draw.rect(surf, LINE, self.r_tog, 1, border_radius=7)
        text(surf, fonts['s'], self.label, self.r_tog.center, TEXT, 'center')
        for r, sym in ((self.r_minus, '-'), (self.r_plus, '+')):
            pygame.draw.rect(surf, BTN if on else BTN_OFF, r, border_radius=6)
            pygame.draw.rect(surf, LINE, r, 1, border_radius=6)
            text(surf, fonts['s'], sym, r.center, TEXT if on else MUTED, 'center')
        text(
            surf,
            fonts['s'],
            '%d%%' % round(self.get_val() * 100),
            (self.r_minus.right + 19, self.rect.centery),
            TEXT if on else MUTED,
            'center',
        )


class Tabs(Widget):
    """A row of tabs."""

    def __init__(self, rect, items, get, set_):
        """items are (key, label); get() and set_() read and change the selected key."""
        super().__init__(rect)
        self.items, self.get, self.set = items, get, set_
        w = self.rect.w // len(items)
        self.cells = [
            pygame.Rect(self.rect.x + i * w, self.rect.y, w, self.rect.h) for i in range(len(items))
        ]

    def click(self, pos):
        """Select the tab under the mouse."""
        for (key, _), r in zip(self.items, self.cells):
            if pos is not None and r.collidepoint(pos):
                self.set(key)
                return True
        return False

    def draw(self, surf, fonts):
        """Draw the tab strip."""
        for (key, label), r in zip(self.items, self.cells):
            on = key == self.get()
            pygame.draw.rect(surf, BTN_ON if on else BTN, r.inflate(-4, 0), border_radius=7)
            text(surf, fonts['m'], label, r.center, TEXT if on else MUTED, 'center')


class TextInput(Widget):
    """One line of text. Enter calls on_submit(text). Up / Down walk through what was sent before."""

    def __init__(self, rect, on_submit, hint='type a message, Enter to send'):
        """on_submit(text) is called on Enter."""
        super().__init__(rect)
        self.text, self.focus, self.on_submit, self.hint = '', False, on_submit, hint
        self.history, self.hi = [], 0

    def click(self, pos):
        """Take the keyboard when clicked."""
        self.focus = bool(pos is not None and self.rect.collidepoint(pos))
        return self.focus

    def key(self, event):
        """Handle a key press while focused."""
        if not self.focus:
            return False
        k = event.key
        if k == pygame.K_RETURN:
            if self.text:
                self.on_submit(self.text)
                self.history.append(self.text)
                self.hi = len(self.history)
            self.text = ''
        elif k == pygame.K_BACKSPACE:
            self.text = self.text[:-1]
        elif k == pygame.K_ESCAPE:
            self.focus = False
        elif k == pygame.K_UP and self.history:
            self.hi = max(0, self.hi - 1)
            self.text = self.history[self.hi]
        elif k == pygame.K_DOWN and self.history:
            self.hi = min(len(self.history), self.hi + 1)
            self.text = self.history[self.hi] if self.hi < len(self.history) else ''
        else:
            ch = getattr(event, 'unicode', '')
            if ch and ch.isprintable() and len(self.text) < 120:
                self.text += ch
        return True

    def draw(self, surf, fonts):
        """Draw the box."""
        pygame.draw.rect(surf, (24, 28, 33), self.rect, border_radius=6)
        pygame.draw.rect(surf, ACCENT if self.focus else LINE, self.rect, 1, border_radius=6)
        room = max(8, (self.rect.w - 20) // 8)
        if self.text or self.focus:
            text(
                surf,
                fonts['s'],
                '> ' + self.text[-room:] + ('_' if self.focus else ''),
                (self.rect.x + 8, self.rect.centery - 7),
                TEXT,
            )
        else:
            text(surf, fonts['s'], self.hint, (self.rect.x + 8, self.rect.centery - 7), MUTED)


class Slider(Widget):
    """Drag along the bar. get() / set(value); value goes from lo to hi in `step`s and sticks to `snap` (for example 0) when it is close."""

    def __init__(
        self, rect, get, set_, lo, hi, step=1, snap=None, enabled=None, color=ACCENT, fmt='%d'
    ):
        """A slider from lo to hi; snap > 0 pulls the value to 0 when it is that close."""
        super().__init__(rect)
        (
            self.get,
            self.set,
            self.lo,
            self.hi,
            self.step,
            self.snap,
            self.enabled,
            self.color,
            self.fmt,
        ) = (get, set_, lo, hi, step, snap, enabled, color, fmt)
        self.grab = False

    def is_enabled(self):
        """True unless disabled."""
        return True if self.enabled is None else bool(self.enabled())

    def _from(self, pos):
        """Set the value from a mouse position."""
        if pos is None:
            return
        f = max(0.0, min(1.0, (pos[0] - self.rect.x - 8) / float(self.rect.w - 16)))
        v = self.lo + f * (self.hi - self.lo)
        v = round(v / self.step) * self.step
        if self.snap is not None and abs(v) <= self.snap * (self.hi - self.lo):
            v = 0
        self.set(max(self.lo, min(self.hi, v)))

    def click(self, pos):
        """Start dragging."""
        if self.inside(pos) and self.is_enabled():
            self.grab = True
            self._from(pos)
            return True
        return False

    def drag(self, pos):
        """Follow the mouse."""
        if self.grab:
            self._from(pos)

    def release(self):
        """Stop dragging."""
        self.grab = False

    def draw(self, surf, fonts):
        """Draw the slider."""
        ok, r = self.is_enabled(), self.rect
        v = self.get()
        v = self.lo if v is None else v
        f = (v - self.lo) / float(self.hi - self.lo)
        y = r.centery
        pygame.draw.rect(surf, BAR_BG, (r.x + 8, y - 3, r.w - 16, 6), border_radius=3)
        mid = (
            r.x + 8 + (r.w - 16) * (-self.lo / float(self.hi - self.lo))
            if self.lo < 0 < self.hi
            else r.x + 8
        )
        kx = r.x + 8 + (r.w - 16) * f
        if ok:
            pygame.draw.rect(
                surf, self.color, (min(mid, kx), y - 3, max(2, abs(kx - mid)), 6), border_radius=3
            )
        if self.lo < 0 < self.hi:
            pygame.draw.line(surf, (96, 104, 115), (int(mid), y - 8), (int(mid), y + 8), 1)
        pygame.draw.circle(surf, (235, 240, 244) if ok else (92, 98, 106), (int(kx), y), 8)
        pygame.draw.circle(surf, self.color if ok else LINE, (int(kx), y), 8, 2)


class Spin(Widget):
    """label  [-] value [+]  : one tuning number changed in steps. get() may return None (unknown yet): then it is greyed out."""

    def __init__(self, rect, label, get, set_, step, lo, hi, fmt='%g', enabled=None):
        """A labelled number with minus and plus buttons."""
        super().__init__(rect)
        self.label, self.get, self.set, self.step, self.lo, self.hi, self.fmt, self.enabled = (
            label,
            get,
            set_,
            step,
            lo,
            hi,
            fmt,
            enabled,
        )
        r = self.rect
        self.r_minus = pygame.Rect(r.right - 24 - 64 - 24, r.y, 24, r.h)
        self.r_plus = pygame.Rect(r.right - 24, r.y, 24, r.h)

    def is_enabled(self):
        """True unless disabled."""
        return self.get() is not None and (True if self.enabled is None else bool(self.enabled()))

    def click(self, pos):
        """Step the value down or up."""
        if pos is None or not self.is_enabled():
            return False
        v = self.get()
        if self.r_minus.collidepoint(pos):
            self.set(max(self.lo, round(v - self.step, 3)))
        elif self.r_plus.collidepoint(pos):
            self.set(min(self.hi, round(v + self.step, 3)))
        else:
            return False
        return True

    def draw(self, surf, fonts):
        """Draw the number and its buttons."""
        ok, v = self.is_enabled(), self.get()
        text(
            surf,
            fonts['s'],
            self.label,
            (self.rect.x, self.rect.centery),
            TEXT if ok else MUTED,
            'mid',
        )
        for r, sym in ((self.r_minus, '-'), (self.r_plus, '+')):
            pygame.draw.rect(
                surf, BTN_HOT if (self.hot and ok) else (BTN if ok else BTN_OFF), r, border_radius=6
            )
            pygame.draw.rect(surf, LINE, r, 1, border_radius=6)
            text(surf, fonts['s'], sym, r.center, TEXT if ok else MUTED, 'center')
        text(
            surf,
            fonts['s'],
            '-' if v is None else self.fmt % v,
            (self.r_minus.right + 32, self.rect.centery),
            TEXT if ok else MUTED,
            'center',
        )


class Group:
    """A set of widgets that are shown together. Feed it canvas-space mouse events."""

    def __init__(self):
        """An empty group."""
        self.items = []

    def add(self, w):
        """Add a widget and return it."""
        self.items.append(w)
        return w

    def of(self, kind):
        """All widgets of a class."""
        return [w for w in self.items if isinstance(w, kind)]

    def motion(self, pos):
        """Mouse moved."""
        for w in self.items:
            w.hot = w.inside(pos)
            if isinstance(w, Slider):
                w.drag(pos)
        for d in self.of(Dropdown):
            d.hot_item = -1
            if d.open and pos is not None:
                for i in range(len(d.options)):
                    if d.item_rect(i).collidepoint(pos):
                        d.hot_item = i

    def click(self, pos):
        """True when a widget used the click. An open dropdown list takes the click first."""
        for d in self.of(Dropdown):
            if d.open:
                d.click(pos)
                return True
        used = False
        for t in self.of(TextInput):
            used = t.click(pos) or used
        for w in self.items:
            if not isinstance(w, TextInput) and w.click(pos):
                return True
        return used

    def release(self):
        """Mouse released."""
        for w in self.of(Slider):
            w.release()

    def close_all(self):
        """Close every open dropdown."""
        for d in self.of(Dropdown):
            d.open = False

    def typing(self):
        """True when a text box has the keyboard."""
        return any(t.focus for t in self.of(TextInput))

    def key(self, event):
        """Pass a key press to the text box."""
        return any(t.key(event) for t in self.of(TextInput))

    def drop_focus(self, pos):
        """Click outside the text box."""
        for t in self.of(TextInput):
            if not t.inside(pos):
                t.focus = False

    def draw_widgets(self, surf, fonts):
        """Draw all widgets."""
        for w in self.items:
            if not isinstance(w, Dropdown):
                w.draw(surf, fonts)
        for d in self.of(Dropdown):
            d.draw(surf, fonts)

    def draw_lists(self, surf, fonts):
        """Draw the open dropdown lists on top."""
        for d in self.of(Dropdown):
            d.draw_list(surf, fonts)
