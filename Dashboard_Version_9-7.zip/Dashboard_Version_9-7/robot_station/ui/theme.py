"""The dashboard's colours."""

BG, PANEL, PANEL2 = (22, 26, 31), (32, 38, 45), (40, 47, 56)
TEXT, MUTED, ACCENT = (226, 231, 236), (140, 150, 162), (0, 200, 170)
OK, WARN, BAD = (0, 200, 170), (240, 190, 70), (235, 95, 85)
BTN, BTN_HOT, BTN_ON, BTN_OFF, LINE = (
    (48, 55, 64),
    (66, 76, 88),
    (0, 150, 128),
    (38, 42, 48),
    (86, 96, 108),
)
BAR_BG = (48, 53, 60)
DANGER, DANGER_HOT = (150, 44, 40), (190, 58, 52)
DIM_TEXT = (110, 118, 128)
