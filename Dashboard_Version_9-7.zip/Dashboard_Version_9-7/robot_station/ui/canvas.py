"""Text, fonts, and the scaling between the fixed design canvas and the real window."""

import pygame

from .theme import TEXT


def text(surf, font, s, pos, color=TEXT, anchor='tl'):
    """Draw text; anchor is tl (default), center, tr or mid."""
    img = font.render(s, True, color)
    w, h = img.get_width(), img.get_height()
    x, y = pos
    if anchor == 'center':
        x, y = x - w // 2, y - h // 2
    elif anchor == 'tr':
        x -= w
    elif anchor == 'mid':
        y -= h // 2
    surf.blit(img, (x, y))


def make_fonts():
    """(small set for the dashboard, big set used to draw the controller picture before it is scaled down)."""
    mono = 'consolas,menlo,dejavusansmono,couriernew'
    f = lambda s, b=False: pygame.font.SysFont(mono, s, bold=b)
    return (
        {'s': f(13), 'm': f(16, True), 'l': f(24, True)},
        {'s': f(17), 'm': f(21, True), 'l': f(30, True)},
    )


def fit_scale(win_w, win_h, cw, ch):
    """Scale and offset that fit the design canvas in the window."""
    s = min(win_w / float(cw), win_h / float(ch))
    w, h = max(1, int(cw * s)), max(1, int(ch * s))
    return s, ((win_w - w) // 2, (win_h - h) // 2), (w, h)


def to_canvas(pos, win_size, cw, ch):
    """Window pixel -> canvas pixel, or None when the pointer is in the side bars."""
    s, (ox, oy), (w, h) = fit_scale(win_size[0], win_size[1], cw, ch)
    x, y = pos[0] - ox, pos[1] - oy
    if x < 0 or y < 0 or x >= w or y >= h:
        return None
    return int(x / s), int(y / s)


def present(window, canvas):
    """Scale the canvas into the window."""
    s, off, size = fit_scale(
        window.get_width(), window.get_height(), canvas.get_width(), canvas.get_height()
    )
    window.fill((10, 12, 14))
    window.blit(
        (
            canvas
            if size == (canvas.get_width(), canvas.get_height())
            else pygame.transform.smoothscale(canvas, size)
        ),
        off,
    )
