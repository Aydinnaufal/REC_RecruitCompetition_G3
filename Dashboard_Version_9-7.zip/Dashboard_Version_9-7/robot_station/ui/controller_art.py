"""The picture of the Xbox controller that lights up with the real one."""

import pygame

from .canvas import text
from .theme import ACCENT, MUTED, TEXT

CTRL_W, CTRL_H = 600, 430


EDGE, IDLE, BODY_COL, ON = (96, 104, 115), (74, 80, 90), (62, 68, 77), (255, 255, 255)


FACE = {'A': (70, 190, 80), 'B': (225, 65, 55), 'X': (65, 125, 225), 'Y': (238, 192, 45)}


def _dim(c, f=0.45):
    """A darker copy of a colour."""
    return tuple(int(v * f) for v in c)


def _shape(surf, kind, color, geom, edge=None, grow=3):
    """Draw one control of the picture (lit when pressed)."""

    def one(c, g):
        if kind == 'rrect':
            pygame.draw.rect(surf, c, g[:4], border_radius=g[4])
        else:
            pygame.draw.ellipse(surf, c, g)

    if edge:
        one(
            edge,
            (geom[0] - grow, geom[1] - grow, geom[2] + 2 * grow, geom[3] + 2 * grow)
            + ((geom[4] + grow,) if kind == 'rrect' else ()),
        )
    one(color, geom)


def draw_controller(surf, fonts, ox, oy, st):
    """Draw the whole controller at (ox, oy) for the state `st`."""
    P = lambda x, y: (ox + x, oy + y)
    _shape(surf, 'ellipse', BODY_COL, (ox + 52, oy + 150, 180, 265), EDGE)
    _shape(surf, 'ellipse', BODY_COL, (ox + 368, oy + 150, 180, 265), EDGE)
    _shape(surf, 'rrect', BODY_COL, (ox + 100, oy + 98, 400, 200, 80), EDGE)
    _shape(surf, 'ellipse', BODY_COL, (ox + 52, oy + 150, 180, 265))
    _shape(surf, 'ellipse', BODY_COL, (ox + 368, oy + 150, 180, 265))
    for name, x, v in (('LT', 118, st.lt), ('RT', 372, st.rt)):
        pygame.draw.rect(surf, EDGE, (ox + x - 2, oy + 6, 114, 60), border_radius=14)
        pygame.draw.rect(surf, (48, 53, 60), (ox + x, oy + 8, 110, 56), border_radius=12)
        if v > 0.01:
            h = int(56 * v)
            pygame.draw.rect(surf, ACCENT, (ox + x, oy + 8 + 56 - h, 110, h), border_radius=12)
        text(
            surf,
            fonts['m'],
            '%s  %.2f' % (name, v),
            P(x + 55, 36),
            ON if v > 0.5 else TEXT,
            'center',
        )
    for name, x in (('LB', 96), ('RB', 364)):
        on = st.buttons[name]
        pygame.draw.rect(surf, EDGE, (ox + x - 2, oy + 68, 144, 30), border_radius=11)
        pygame.draw.rect(surf, ACCENT if on else IDLE, (ox + x, oy + 70, 140, 26), border_radius=10)
        text(surf, fonts['m'], name, P(x + 70, 83), ON if on else TEXT, 'center')
    for name, cx, cy, vx, vy, click in (
        ('LS', 165, 172, st.lx, st.ly, st.buttons['L3']),
        ('RS', 365, 268, st.rx, st.ry, st.buttons['R3']),
    ):
        pygame.draw.circle(surf, (40, 44, 50), P(cx, cy), 42)
        pygame.draw.circle(surf, EDGE, P(cx, cy), 42, 2)
        pygame.draw.circle(surf, ACCENT if click else IDLE, P(cx + vx * 17, cy - vy * 17), 27)
        pygame.draw.circle(surf, ON if click else EDGE, P(cx + vx * 17, cy - vy * 17), 27, 2)
        text(surf, fonts['s'], name, P(cx, cy + 56), MUTED, 'center')
        text(
            surf,
            fonts['s'],
            '%+.2f %+.2f' % (vx, vy),
            P(cx, cy + 70),
            TEXT if (vx or vy) else MUTED,
            'center',
        )
    cx, cy = 235, 268
    pygame.draw.rect(surf, EDGE, (ox + cx - 15, oy + cy - 33, 30, 66), border_radius=6)
    pygame.draw.rect(surf, EDGE, (ox + cx - 33, oy + cy - 15, 66, 30), border_radius=6)
    dx, dy = st.dpad
    for x, y, w, h, on in (
        (cx - 13, cy - 31, 26, 31, dy > 0),
        (cx - 13, cy, 26, 31, dy < 0),
        (cx - 31, cy - 13, 31, 26, dx < 0),
        (cx, cy - 13, 31, 26, dx > 0),
    ):
        pygame.draw.rect(surf, ACCENT if on else IDLE, (ox + x, oy + y, w, h), border_radius=4)
    text(surf, fonts['s'], 'D-PAD', P(cx, cy + 50), MUTED, 'center')
    for name, x, y in (('Y', 435, 132), ('A', 435, 198), ('X', 402, 165), ('B', 468, 165)):
        on = st.buttons[name]
        pygame.draw.circle(surf, FACE[name] if on else _dim(FACE[name]), P(x, y), 18)
        pygame.draw.circle(surf, ON if on else EDGE, P(x, y), 18, 3 if on else 2)
        text(surf, fonts['m'], name, P(x, y), ON if on else TEXT, 'center')
    for name, x, y in (('BACK', 268, 172), ('START', 332, 172)):
        on = st.buttons[name]
        pygame.draw.circle(surf, ACCENT if on else IDLE, P(x, y), 10)
        pygame.draw.circle(surf, EDGE, P(x, y), 10, 2)
        text(surf, fonts['s'], name, P(x, y + 22), ON if on else MUTED, 'center')
    on = st.buttons['GUIDE']
    pygame.draw.circle(surf, ACCENT if on else IDLE, P(300, 128), 21)
    pygame.draw.circle(surf, EDGE, P(300, 128), 21, 2)
    text(surf, fonts['l'], 'X', P(300, 128), ON if on else MUTED, 'center')
