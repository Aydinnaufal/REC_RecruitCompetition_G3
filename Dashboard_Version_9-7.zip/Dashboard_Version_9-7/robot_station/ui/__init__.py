"""Everything the dashboard draws with: colours, text, widgets, gauges and the controller picture."""

from .theme import (
    BG,
    PANEL,
    PANEL2,
    TEXT,
    MUTED,
    ACCENT,
    OK,
    WARN,
    BAD,
    BTN,
    BTN_HOT,
    BTN_ON,
    BTN_OFF,
    LINE,
    BAR_BG,
    DANGER,
    DANGER_HOT,
    DIM_TEXT,
)
from .canvas import text, make_fonts, fit_scale, to_canvas, present
from .widgets import Widget, Button, Dropdown, Stepper, Tabs, TextInput, Slider, Spin, Group
from .gauges import (
    card,
    led,
    signal_bars,
    hbar,
    labelled_bar,
    tile,
    compass,
    raw_compact,
    arc,
    speedo,
    servo_dial,
    board3d,
    battery,
)
from .controller_art import CTRL_W, CTRL_H, EDGE, IDLE, BODY_COL, ON, FACE, draw_controller
