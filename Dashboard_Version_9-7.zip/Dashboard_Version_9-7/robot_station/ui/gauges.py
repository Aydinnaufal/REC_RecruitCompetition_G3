"""Read-only pictures: cards, LEDs, bars, tiles, compass, speedometer, servo dial, 3D gyro board, battery."""

import math

import pygame

from .canvas import text
from .theme import ACCENT, BAD, BAR_BG, LINE, MUTED, OK, PANEL2, TEXT, WARN


def card(surf, rect, title, fonts):
    """A titled box."""
    pygame.draw.rect(surf, PANEL2, rect, border_radius=8)
    text(surf, fonts['s'], title, (rect[0] + 10, rect[1] + 6), MUTED)


def led(surf, pos, on, color=OK, r=5):
    """A round light."""
    pygame.draw.circle(surf, color if on else (58, 64, 72), pos, r)
    pygame.draw.circle(surf, (20, 24, 28), pos, r, 1)


def signal_bars(surf, x, y, level, n=4):
    """Four signal-strength bars."""
    for i in range(n):
        h = 5 + 4 * i
        pygame.draw.rect(
            surf, OK if i < level else (58, 64, 72), (x + i * 7, y + 17 - h, 5, h), border_radius=1
        )


def hbar(surf, rect, frac, color=ACCENT, centre=False):
    """A horizontal bar, optionally centred on zero."""
    x, y, w, h = rect
    pygame.draw.rect(surf, BAR_BG, rect, border_radius=4)
    if centre:
        mid, n = x + w // 2, int(max(-1.0, min(1.0, frac)) * w / 2)
        if n:
            pygame.draw.rect(
                surf, color, (min(mid, mid + n), y, max(2, abs(n)), h), border_radius=4
            )
        pygame.draw.line(surf, (96, 104, 115), (mid, y - 1), (mid, y + h), 1)
    else:
        n = int(max(0.0, min(1.0, frac)) * w)
        if n:
            pygame.draw.rect(surf, color, (x, y, max(2, n), h), border_radius=4)


def labelled_bar(
    surf, fonts, x, y, w, frac, label, value, color=ACCENT, centre=False, lw=74, vw=96
):
    """A bar with a label on the left and a value on the right."""
    text(surf, fonts['s'], label, (x, y), TEXT)
    hbar(surf, (x + lw, y + 2, w - lw - vw, 11), frac, color, centre)
    text(surf, fonts['s'], value, (x + w - vw + 8, y), TEXT)


def tile(surf, fonts, x, y, label, on, state='', color=OK, off_color=(30, 34, 40), size=56):
    """A square indicator: lit in `color` with a white outline when ON, in `off_color` with a grey outline when OFF, a short word inside and
    the label below. Anything at all can be told at a glance by its colour."""
    r = pygame.Rect(x, y, size, size)
    pygame.draw.rect(surf, color if on else off_color, r, border_radius=9)
    pygame.draw.rect(surf, (255, 255, 255) if on else (74, 80, 90), r, 2, border_radius=9)
    text(surf, fonts['m'], state, r.center, (8, 24, 22) if on else (205, 210, 216), 'center')
    text(surf, fonts['s'], label, (x + size // 2, y + size + 10), TEXT if on else MUTED, 'center')


def compass(surf, fonts, cx, cy, r, heading, omega_dps=0.0):
    """A rotating compass card under a fixed pointer. heading = degrees from the zero direction, turning right makes it bigger.
    Zero is Y (up), then B right, A down, X left: the same face buttons that turn the robot."""
    pygame.draw.circle(surf, (26, 30, 36), (cx, cy), r)
    pygame.draw.circle(surf, LINE, (cx, cy), r, 2)
    P = lambda a, rad: (
        cx + rad * math.sin(math.radians(a - heading)),
        cy - rad * math.cos(math.radians(a - heading)),
    )
    for a in range(0, 360, 10):
        major = a % 30 == 0
        pygame.draw.line(
            surf,
            (150, 160, 172) if major else (84, 92, 104),
            P(a, r - 1),
            P(a, r - (11 if major else 6)),
            2 if a % 90 == 0 else 1,
        )
        if major and a % 90 != 0:
            text(surf, fonts['s'], str(a), P(a, r - 22), MUTED, 'center')
    for a, (col, lab) in {
        0: ((238, 192, 45), 'Y'),
        90: ((225, 65, 55), 'B'),
        180: ((70, 190, 80), 'A'),
        270: ((65, 125, 225), 'X'),
    }.items():
        p = P(a, r - 22)
        pygame.draw.circle(surf, col, (int(p[0]), int(p[1])), 9)
        text(surf, fonts['s'], lab, p, (10, 14, 18), 'center')
    pygame.draw.polygon(
        surf, ACCENT, [(cx, cy - 15), (cx - 10, cy + 12), (cx, cy + 6), (cx + 10, cy + 12)]
    )
    pygame.draw.polygon(
        surf, (255, 120, 100), [(cx, cy - r - 1), (cx - 6, cy - r - 11), (cx + 6, cy - r - 11)]
    )
    text(surf, fonts['m'], '%03.0f deg' % (heading % 360), (cx, cy + r + 16), TEXT, 'center')
    bw = int(r * 1.6)
    hbar(surf, (cx - bw // 2, cy + r + 30, bw, 9), omega_dps / 230.0, (240, 170, 70), centre=True)
    text(surf, fonts['s'], 'gyro %+.0f deg/s' % omega_dps, (cx, cy + r + 52), MUTED, 'center')


def raw_compact(surf, fonts, x, y, w, st):
    """Raw controller numbers, small: axis bars, then the buttons as numbered squares. Returns the y below it."""
    text(surf, fonts['s'], 'RAW INPUT', (x, y), MUTED)
    y += 18
    if not st.raw_axes:
        text(surf, fonts['s'], 'no controller: plug in, press Guide', (x, y), MUTED)
        y += 18
    for i, v in enumerate(st.raw_axes[:8]):
        text(surf, fonts['s'], 'axis %d' % i, (x, y), MUTED)
        hbar(surf, (x + 60, y + 2, w - 60 - 50, 9), v, ACCENT, centre=True)
        text(surf, fonts['s'], '%+.2f' % v, (x + w - 44, y), TEXT)
        y += 16
    y += 4
    nb, cell = len(st.raw_buttons[:20]), (w - 4) // 10
    for i, v in enumerate(st.raw_buttons[:20]):
        cx, cy = x + (i % 10) * cell, y + (i // 10) * 22
        pygame.draw.rect(surf, ACCENT if v else BAR_BG, (cx, cy, cell - 3, 19), border_radius=4)
        text(
            surf,
            fonts['s'],
            str(i),
            (cx + (cell - 3) // 2, cy + 10),
            (10, 20, 20) if v else MUTED,
            'center',
        )
    y += 22 * ((nb + 9) // 10) + 2
    text(
        surf,
        fonts['s'],
        '  '.join('hat%d %s' % (i, tuple(h)) for i, h in enumerate(st.raw_hats)) or 'no hat',
        (x, y),
        MUTED,
    )
    return y + 18


def arc(surf, color, cx, cy, r, a0, a1, width=8):
    """A curved line from angle a0 to a1 (degrees, 0 = straight up, clockwise)."""
    n = max(2, int(abs(a1 - a0) / 2.5))
    pts = [
        (
            cx + r * math.sin(math.radians(a0 + (a1 - a0) * i / n)),
            cy - r * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
        )
        for i in range(n + 1)
    ]
    for p, q in zip(pts, pts[1:]):
        pygame.draw.line(surf, color, p, q, width)
    for p in (pts[0], pts[-1]):
        pygame.draw.circle(surf, color, (int(p[0]), int(p[1])), width // 2)


def speedo(
    surf,
    fonts,
    cx,
    cy,
    r,
    value,
    vmin,
    vmax,
    color,
    label,
    big,
    small,
    ticks=(-100, -50, 0, 50, 100),
    live=True,
):
    """A car speedometer: 240 degree dial, zero at the top when the range crosses zero, coloured sweep from zero to the needle."""
    A = lambda v: -120 + 240.0 * (max(vmin, min(vmax, v)) - vmin) / (vmax - vmin)
    pygame.draw.circle(surf, (26, 30, 36), (cx, cy), r + 12)
    pygame.draw.circle(surf, LINE, (cx, cy), r + 12, 2)
    arc(surf, BAR_BG, cx, cy, r - 2, -120, 120, 10)
    zero = A(0 if vmin < 0 else vmin)
    if live and abs(A(value) - zero) > 0.5:
        arc(surf, color, cx, cy, r - 2, min(zero, A(value)), max(zero, A(value)), 10)
    for t in ticks:
        a = math.radians(A(t))
        pygame.draw.line(
            surf,
            (150, 160, 172),
            (cx + (r - 18) * math.sin(a), cy - (r - 18) * math.cos(a)),
            (cx + (r - 9) * math.sin(a), cy - (r - 9) * math.cos(a)),
            2,
        )
        text(
            surf,
            fonts['s'],
            '%d' % t,
            (cx + (r - 32) * math.sin(a), cy - (r - 32) * math.cos(a)),
            MUTED,
            'center',
        )
    a = math.radians(A(value if live else (vmin + vmax) / 2.0 if vmin < 0 else vmin))
    tip = (cx + (r - 14) * math.sin(a), cy - (r - 14) * math.cos(a))
    pygame.draw.line(surf, (255, 120, 100) if live else (90, 96, 104), (cx, cy), tip, 3)
    pygame.draw.circle(surf, (210, 214, 220), (cx, cy), 7)
    text(surf, fonts['m'], label, (cx, cy - r // 2 + 4), TEXT, 'center')
    text(surf, fonts['l'], big, (cx, cy + r // 2 - 2), TEXT if live else MUTED, 'center')
    text(surf, fonts['s'], small, (cx, cy + r // 2 + 22), MUTED, 'center')


def servo_dial(surf, fonts, cx, cy, r, angle, lo, hi, color, label):
    """A half dial, 0 degrees at the left, 90 at the top, 180 at the right, with a servo horn. angle None = limp (no signal, free to turn), False = no data."""
    P = lambda deg, rad: (
        cx - rad * math.cos(math.radians(deg)),
        cy - rad * math.sin(math.radians(deg)),
    )
    pygame.draw.circle(surf, (26, 30, 36), (cx, cy), r + 10)
    pygame.draw.rect(surf, PANEL2, (cx - r - 12, cy + 1, 2 * r + 24, r // 2 + 22))
    pygame.draw.circle(surf, LINE, (cx, cy), r + 10, 2)
    prev = None
    for d in range(0, 181, 3):  # the allowed range lit up, the rest dark
        q = P(d, r - 3)
        if prev:
            pygame.draw.line(surf, color if lo <= d <= hi else BAR_BG, prev, q, 8)
        prev = q
    for d in range(0, 181, 30):
        pygame.draw.line(surf, (150, 160, 172), P(d, r - 14), P(d, r - 24), 2)
        text(surf, fonts['s'], '%d' % d, P(d, r - 38), MUTED, 'center')
    if angle is False:
        text(surf, fonts['m'], 'NO DATA', (cx, cy + 28), MUTED, 'center')
    elif angle is None:
        pygame.draw.line(surf, (96, 102, 110), (cx, cy), P(90, r - 20), 5)
        pygame.draw.circle(surf, (96, 102, 110), (int(P(90, r - 20)[0]), int(P(90, r - 20)[1])), 8)
        text(surf, fonts['m'], 'LIMP', (cx, cy + 28), WARN, 'center')
    else:
        tip = P(angle, r - 20)
        pygame.draw.line(surf, (235, 240, 244), (cx, cy), tip, 6)
        pygame.draw.circle(surf, color, (int(tip[0]), int(tip[1])), 9)
        text(surf, fonts['l'], '%d' % angle + chr(176), (cx, cy + 32), TEXT, 'center')
    pygame.draw.circle(surf, (210, 214, 220), (cx, cy), 9)
    pygame.draw.circle(surf, (40, 44, 50), (cx, cy), 4)
    text(surf, fonts['m'], label, (cx, cy - r - 22), TEXT, 'center')


def _rot(v, yaw, pitch, roll):
    """Body frame -> world: roll about x (forward), pitch about y (left), yaw about z (up). Angles in degrees."""
    x, y, z = v
    c, s = math.cos(math.radians(roll)), math.sin(math.radians(roll))
    y, z = y * c - z * s, y * s + z * c
    c, s = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
    x, z = x * c + z * s, -x * s + z * c
    c, s = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    x, y = x * c - y * s, x * s + y * c
    return x, y, z


def board3d(surf, fonts, cx, cy, k, yaw, pitch, roll, ok=True):
    """The MPU6050 board as a little slab turning with the real sensor, with its X (forward), Y (left), Z (up) axes. k = pixels per unit."""
    proj = lambda p: (cx + k * 0.866 * (p[0] - p[1]), cy - k * (p[2] + 0.5 * (p[0] + p[1])))
    ring = [
        proj((1.8 * math.cos(math.radians(a)), 1.8 * math.sin(math.radians(a)), -0.8))
        for a in range(0, 361, 15)
    ]
    for p, q in zip(ring, ring[1:]):
        pygame.draw.line(surf, (70, 78, 88), p, q, 1)  # the ground, fixed
    for a, name in ((0, 'N'),):
        pygame.draw.line(surf, (70, 78, 88), proj((0, 0, -0.8)), proj((1.8, 0, -0.8)), 1)
    hx, hy, hz = 1.5, 1.0, 0.14
    V = [(sx * hx, sy * hy, sz * hz) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
    R = [_rot(v, yaw, pitch, roll) for v in V]
    faces = [
        ((0, 1, 3, 2), (60, 66, 76)),
        ((4, 5, 7, 6), (60, 66, 76)),
        ((0, 1, 5, 4), (66, 72, 82)),
        ((2, 3, 7, 6), (66, 72, 82)),
        ((0, 2, 6, 4), (74, 80, 92)),
        ((1, 3, 7, 5), (74, 80, 92)),
    ]
    cam = (-1.0, -1.0, 1.2)
    order = sorted(faces, key=lambda f: sum(sum(R[i][j] * cam[j] for j in range(3)) for i in f[0]))
    for idx, col in order:
        top = idx == (1, 3, 7, 5)  # +z face: the chip side
        pygame.draw.polygon(
            surf,
            (0, 120, 108) if top and ok else (0, 90, 80) if top else col,
            [proj(R[i]) for i in idx],
        )
        pygame.draw.polygon(surf, (150, 160, 172), [proj(R[i]) for i in idx], 1)
    for axis, col, name in (
        ((2.4, 0, 0), (235, 80, 70), 'X'),
        ((0, 2.4, 0), (80, 210, 100), 'Y'),
        ((0, 0, 2.0), (90, 150, 245), 'Z'),
    ):
        e = proj(_rot(axis, yaw, pitch, roll))
        pygame.draw.line(surf, col, proj((0, 0, 0)), e, 3)
        pygame.draw.circle(surf, col, (int(e[0]), int(e[1])), 5)
        text(surf, fonts['m'], name, (e[0] + 10, e[1] - 10), col, 'center')


def battery(surf, fonts, x, y, w, h, volts, vmin=6.0, vmax=8.4, low=6.4, cells=2):
    """A battery picture: the fill is the charge between vmin and vmax, the line marks the low-battery warning level."""
    f = 0.0 if volts is None else max(0.0, min(1.0, (volts - vmin) / (vmax - vmin)))
    bad = volts is not None and volts < low
    col = BAD if bad else (WARN if f < 0.35 else OK)
    pygame.draw.rect(surf, (26, 30, 36), (x + w // 2 - 14, y, 28, 8), border_radius=2)  # the cap
    body = pygame.Rect(x, y + 8, w, h - 8)
    pygame.draw.rect(surf, (26, 30, 36), body, border_radius=8)
    pygame.draw.rect(surf, LINE, body, 2, border_radius=8)
    if volts is not None and f > 0:
        fh = int((body.h - 8) * f)
        pygame.draw.rect(
            surf, col, (body.x + 4, body.bottom - 4 - fh, body.w - 8, fh), border_radius=5
        )
    for i in range(1, cells):  # cell dividers
        yy = body.y + body.h * i // cells
        pygame.draw.line(surf, (26, 30, 36), (body.x + 4, yy), (body.right - 4, yy), 3)
    ly = body.bottom - 4 - int((body.h - 8) * (low - vmin) / (vmax - vmin))
    pygame.draw.line(surf, (255, 255, 255), (body.x - 6, ly), (body.right + 6, ly), 2)
    text(surf, fonts['s'], 'low %.1f' % low, (body.right + 10, ly), WARN, 'mid')
    text(surf, fonts['s'], '%.1f V' % vmax, (body.right + 10, body.y + 4), MUTED, 'mid')
    text(surf, fonts['s'], '%.1f V' % vmin, (body.right + 10, body.bottom - 4), MUTED, 'mid')
