"""Byte pipes to the robot. A Transport only moves bytes; framing and meaning live in protocol.py and link.py. This file has the USB cable (serial) one."""

import threading
from collections import namedtuple

from .errors import friendly_error, install_hint

BAUD = 115200


Port = namedtuple('Port', 'device description')


def list_serial_ports():
    """COM ports, USB first. The Windows Bluetooth 'Incoming' ports (address 000000000000) are left out: opening them can hang."""
    try:
        from serial.tools import list_ports
    except ImportError:
        return []
    out = []
    for p in list_ports.comports():
        if str(getattr(p, 'hwid', '')).upper().endswith('000000000000'):
            continue
        out.append(Port(p.device, getattr(p, 'description', '') or ''))
    return sorted(out, key=lambda p: ('BLUETOOTH' in p.description.upper(), p.device))


class Transport:
    """Base class: a byte pipe to the robot that opens in the background and is read by polling."""

    name, handshake_timeout = 'transport', 2.5

    def __init__(self):
        """A new transport is closed."""
        self.is_open, self.last_error, self.opening = False, '', False

    def start_open(self):
        """Begin opening (must return at once)."""
        raise NotImplementedError

    def close(self):
        """Close the pipe."""
        self.is_open = False

    def write(self, data):
        """Send bytes."""
        raise NotImplementedError

    def read(self):
        """Return everything received since the last call."""
        return b''


class SerialTransport(Transport):
    """A COM port. Opens in a background thread and never touches DTR / RTS (that would reset the ESP32)."""

    def __init__(self, port, baud=BAUD):
        """USB cable on COM port `port`."""
        super().__init__()
        self.port, self.baud, self.ser = port, baud, None
        self.name = '%s @ %d' % (port, baud)
        self._cancel, self._lock = False, threading.Lock()

    def start_open(self):
        """Open the port in a background thread."""
        self.opening, self._cancel, self.last_error = True, False, ''
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        """The thread that reads the port."""
        err = ''
        try:
            import serial

            ser = serial.Serial()
            ser.port, ser.baudrate, ser.timeout, ser.write_timeout = self.port, self.baud, 0, 0.3
            ser.dtr, ser.rts = False, False
            ser.open()
            with self._lock:
                if self._cancel:
                    ser.close()
                else:
                    self.ser, self.is_open = ser, True
        except ImportError:
            err = 'pyserial is not installed for this Python: run  ' + install_hint('pyserial')
        except Exception as e:
            err = friendly_error(e)
        self.last_error = '' if self.is_open else err
        self.opening = False

    def close(self):
        """Close the port."""
        self._cancel = True
        with self._lock:
            try:
                if self.ser:
                    self.ser.close()
            except Exception:
                pass
            self.ser, self.is_open = None, False

    def write(self, data):
        """Send bytes."""
        try:
            self.ser.write(data)
        except Exception as e:
            if (
                type(e).__name__ == 'SerialTimeoutException'
            ):  # buffer full: drop this one, the next CMD is 50 ms away
                return
            self.last_error = friendly_error(e)
            raise IOError(self.last_error)

    def read(self):
        """Everything received since the last call."""
        try:
            n = self.ser.in_waiting
            return self.ser.read(n) if n else b''
        except Exception as e:
            self.last_error = friendly_error(e)
            raise IOError(self.last_error)
