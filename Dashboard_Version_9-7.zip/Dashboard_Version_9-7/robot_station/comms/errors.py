"""Helpers that turn low-level exceptions into sentences a person can act on."""

import sys


def install_hint(module):
    """The pip command to install a missing module for the Python that runs the dashboard."""
    return '"%s" -m pip install %s' % (sys.executable, module)


def friendly_error(e):
    """The cryptic text pyserial / bleak / Windows give, as one sentence the person can act on."""
    s = str(e).strip() or e.__class__.__name__
    low = s.lower()
    if (
        'permission' in low
        or 'access is denied' in low
        or 'errno 13' in low
        or 'resource busy' in low
    ):
        return (
            'port busy or access denied: close the Arduino Serial Monitor or any other program using it (%s)'
            % s[:60]
        )
    if (
        'filenotfound' in low
        or 'no such file' in low
        or 'errno 2' in low
        or 'cannot find the file' in low
        or 'winerror 2' in low
    ):
        return 'port not found: re-plug the USB cable, then press Refresh (%s)' % s[:60]
    if (
        'unplug' in low
        or 'device not configured' in low
        or 'input/output error' in low
        or 'errno 5' in low
        or 'winerror 22' in low
    ):
        return 'the port went away (cable unplugged): %s' % s[:60]
    if 'turned off' in low or 'bluetooth is off' in low or 'radio' in low or 'org.bluez' in low:
        return (
            'Bluetooth is off or missing on this PC: switch it on in Windows settings (%s)' % s[:70]
        )
    if 'timeout' in low or 'timed out' in low:
        return 'the robot did not answer in time: switch it on, bring it close, and make sure nothing else is connected to it'
    if 'not found' in low or 'could not find' in low:
        return 'device not found: press Scan again (the robot must be on and advertising)'
    return s


def bleak_missing_text(e=None):
    """The sentence shown when the Bluetooth library is not installed."""
    return 'bleak is not installed for this Python: run  ' + install_hint('bleak')
