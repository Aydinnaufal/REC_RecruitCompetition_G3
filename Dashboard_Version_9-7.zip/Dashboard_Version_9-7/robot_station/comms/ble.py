"""Bluetooth LE: scanning for the robot and the transport that talks to it through the Nordic UART service (what the firmware offers)."""

import threading
import time
from collections import deque
from collections import namedtuple

from .errors import bleak_missing_text, friendly_error
from .transports import Transport

NUS_SERVICE = '6e400001-b5a3-f393-e0a9-e50e24dcca9e'  # Nordic UART service, what the firmware offers in BLE mode


NUS_RX = '6e400002-b5a3-f393-e0a9-e50e24dcca9e'  # laptop -> robot (write)


NUS_TX = '6e400003-b5a3-f393-e0a9-e50e24dcca9e'  # robot -> laptop (notify)


ROBOT_NAME_PREFIX = 'REC'  # the firmware advertises as "REC-Robot"


BleDevice = namedtuple('BleDevice', 'name address rssi nus')


class BleScanner:
    """Scans for Bluetooth LE devices in a background thread. .devices: the REC robot first, then by signal strength."""

    def __init__(self, timeout=5.0):
        """Scan for `timeout` seconds once start() is called."""
        self.timeout, self.running, self.devices, self.error, self.started = (
            timeout,
            False,
            [],
            '',
            0.0,
        )

    def start(self):
        """Start scanning in a background thread."""
        self.running, self.error, self.started = True, '', time.monotonic()
        threading.Thread(target=self._run, daemon=True).start()

    def progress(self):
        """How far the scan is, 0 to 1."""
        return min(1.0, (time.monotonic() - self.started) / self.timeout) if self.running else 1.0

    def _run(self):
        """The scan thread: collects the devices that advertise."""
        try:
            import asyncio

            try:
                from bleak import BleakScanner
            except ImportError as e:
                self.error = bleak_missing_text(e)
                return
            found = asyncio.run(BleakScanner.discover(timeout=self.timeout, return_adv=True))
            devs = []
            for key, val in (found.items() if isinstance(found, dict) else []):
                dev, adv = val if isinstance(val, tuple) else (val, None)
                uuids = [u.lower() for u in (getattr(adv, 'service_uuids', None) or [])]
                name = getattr(adv, 'local_name', None) or getattr(dev, 'name', None) or ''
                devs.append(
                    BleDevice(
                        name,
                        getattr(dev, 'address', str(key)),
                        getattr(adv, 'rssi', None) if adv else None,
                        NUS_SERVICE in uuids,
                    )
                )
            devs.sort(
                key=lambda d: (
                    not (d.nus or d.name.upper().startswith(ROBOT_NAME_PREFIX)),
                    -(d.rssi if d.rssi is not None else -200),
                )
            )
            self.devices = [d for d in devs if d.name or d.nus]  # nameless beacons are noise
        except Exception as e:
            self.error = friendly_error(e)
        finally:
            self.running = False

    def robot(self):
        """The device whose name starts with ROBOT_NAME_PREFIX (strongest signal first), or None."""
        for d in self.devices:
            if d.nus or d.name.upper().startswith(ROBOT_NAME_PREFIX):
                return d
        return None


class BleTransport(Transport):
    """Bluetooth LE to the robot's Nordic-UART service. All bleak calls run in one thread with its own asyncio loop. Writes never block the
    dashboard; if the radio falls behind the newest command is dropped (the next one is 50 ms away). One failed write does NOT end the link:
    only Windows reporting the device gone, or 20 failures in a row, does."""

    handshake_timeout = 8.0

    def __init__(self, address, label='', client_factory=None):
        """Connect to the device with this Bluetooth address when start_open() is called."""
        super().__init__()
        self.address, self.name, self.client_factory = (
            address,
            'BLE %s' % (label or address),
            client_factory,
        )
        self._rx, self._lock = deque(), threading.Lock()
        self._loop = self._stop = self._client = None
        self._pending, self.chunk, self._lost, self._cancel = 0, 20, False, False
        self._write_fails, self.last_write_error = 0, ''

    def start_open(self):
        """Open the connection in a background thread (it can take up to 10 s)."""
        self.opening, self._cancel, self.last_error, self._lost = True, False, '', False
        threading.Thread(target=self._thread, daemon=True).start()

    def _thread(self):
        """The connection thread: connect, subscribe to notifications, then wait until closed or dropped."""
        import asyncio

        loop = asyncio.new_event_loop()
        self._loop = loop
        try:
            loop.run_until_complete(self._session())
        except Exception as e:
            self.last_error = friendly_error(e)
            self._lost = self.is_open
        finally:
            self.is_open = self.opening = False
            try:
                loop.close()
            except Exception:
                pass

    async def _session(self):
        import asyncio

        self._stop = asyncio.Event()
        factory = self.client_factory
        if factory is None:
            try:
                from bleak import BleakClient
            except ImportError as e:
                self.last_error, self.opening = bleak_missing_text(e), False
                return
            factory = BleakClient
        client = self._client = factory(self.address, disconnected_callback=self._on_disconnect)
        last = ''
        for _ in range(2):
            if self._cancel:
                self.opening = False
                return
            try:
                await client.connect(timeout=10.0)
                last = ''
                break
            except Exception as e:
                last = friendly_error(e)
        if last:
            self.last_error, self.opening = last, False
            return
        try:
            have = {
                str(getattr(c, 'uuid', '')).lower()
                for s in client.services
                for c in getattr(s, 'characteristics', [])
            }
            if NUS_RX not in have or NUS_TX not in have:
                self.last_error, self.opening = (
                    'connected, but this device is not the REC robot (no serial service): is the BLE firmware flashed?',
                    False,
                )
                await client.disconnect()
                return
            await client.start_notify(NUS_TX, self._on_notify)
            self.chunk = max(20, min(180, int(getattr(client, 'mtu_size', 23) or 23) - 3))
        except Exception as e:
            self.last_error, self.opening = friendly_error(e), False
            try:
                await client.disconnect()
            except Exception:
                pass
            return
        self.is_open, self.opening = True, False
        await self._stop.wait()
        try:
            await client.disconnect()
        except Exception:
            pass

    def _on_notify(self, _char, data):
        """Bluetooth data arrived from the robot: queue it for read()."""
        with self._lock:
            self._rx.append(bytes(data))

    def _on_disconnect(self, _client):
        """Bluetooth dropped: remember why so the Link can report it."""
        if self.is_open and not self._cancel:
            self.last_error = (
                'Bluetooth LE link was dropped by Windows or the robot (out of range, robot reset, or radio interference)'
                + (
                    (' after write errors: ' + self.last_write_error)
                    if self.last_write_error
                    else ''
                )
            )
            self._lost = True

    async def _awrite(self, data):
        try:
            for i in range(0, len(data), self.chunk):
                await self._client.write_gatt_char(NUS_RX, data[i : i + self.chunk], response=False)
            self._write_fails = 0
        except Exception as e:
            self._write_fails += 1
            self.last_write_error = '%s: %s' % (e.__class__.__name__, (str(e) or '-')[:80])
            gone = getattr(self._client, 'is_connected', True) is False
            if gone or self._write_fails >= 20:
                self.last_error = (
                    'Bluetooth LE device is gone (%s)' % self.last_write_error
                    if gone
                    else friendly_error(e)
                )
                self._lost = True
        finally:
            self._pending -= 1

    def write(self, data):
        """Send bytes to the robot, in pieces that fit one Bluetooth packet."""
        if not self.is_open or self._loop is None:
            raise IOError(self.last_error or 'Bluetooth LE link is not open')
        if self._lost:
            raise IOError(self.last_error)
        if self._pending >= 4:  # the radio is behind: drop this one
            return
        import asyncio

        self._pending += 1
        asyncio.run_coroutine_threadsafe(self._awrite(bytes(data)), self._loop)

    def read(self):
        """Everything received since the last call."""
        if (
            self.is_open
            and not self._cancel
            and not self._lost
            and getattr(self._client, 'is_connected', True) is False
        ):
            self._lost, self.last_error = (
                True,
                'Bluetooth LE link lost (Windows reports the device disconnected)',
            )
        if self._lost:
            raise IOError(self.last_error or 'Bluetooth LE link lost')
        with self._lock:
            out = b''.join(self._rx)
            self._rx.clear()
        return out

    def close(self):
        """Drop the connection."""
        self._cancel = True
        try:
            if self._loop and self._stop and not self._loop.is_closed():
                self._loop.call_soon_threadsafe(self._stop.set)
        except Exception:
            pass
        self.is_open = False
