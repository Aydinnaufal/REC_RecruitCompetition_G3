"""Dead-reckoned picture data (position, heading) built from the robot's own telemetry."""

import math


class TelemetryPose:
    """Turns telemetry into the picture data of sim.Robot.snapshot(). Position is dead reckoning (wheel percent x 30 cm/s, heading from the
    gyro): fine for watching, not for navigation."""

    MAX_CM_S = 30.0

    def __init__(self):
        """Start at the origin facing the zero heading."""
        self.x = self.y = self.al = self.ar = self.yaw0 = 0.0
        self.t = None

    def zero(self, tel):
        """Make the current robot yaw the zero heading."""
        self.yaw0 = tel.get('yaw', 0.0)

    def reset(self):
        """Put the dead-reckoned position back at the origin."""
        self.x = self.y = 0.0

    def snapshot(self, tel, at=None):
        """Picture data (same shape as Robot.snapshot) from one telemetry report at time `at`."""
        th = math.radians(tel['yaw'])
        if self.t is not None and at is not None:
            dt = max(0.0, min(0.2, at - self.t))
            v = (tel['vl'] + tel['vr']) / 200.0 * self.MAX_CM_S
            self.x += -math.sin(th) * v * dt
            self.y += math.cos(th) * v * dt
            self.al += tel['vl'] / 100.0 * self.MAX_CM_S * dt / 3.0
            self.ar += tel['vr'] / 100.0 * self.MAX_CM_S * dt / 3.0
        self.t = at
        return dict(
            x=self.x,
            y=self.y,
            th=th,
            ref_th=math.radians(self.yaw0),
            heading=(-(tel['yaw'] - self.yaw0)) % 360,
            vl=tel['vl'] / 100.0,
            vr=tel['vr'] / 100.0,
            al=self.al,
            ar=self.ar,
            speed=(tel['vl'] + tel['vr']) / 200.0 * self.MAX_CM_S,
            omega=math.radians(tel['gz']),
            lift=0.6 + 11.4 * tel['lift'] / 100.0,
            pad=3.0 * tel['grip'] / 100.0,
            cmd=tel['grip'] / 100.0,
            holding=False,
            touching=False,
            turn_on=False,
            snapping=False,
            mode='arcade',
            rt=0.0,
            speed_scale=1.0,
            source='robot',
        )
