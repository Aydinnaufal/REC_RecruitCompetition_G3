// REC robot - TUNING firmware V_9_7 for the ARDUINO NANO, for Robot Station V 9.7 (the Tune page).
//
// Test the motors, the two servos, the MPU6050 gyro and the battery reading from the dashboard, and keep the
// values found (start power, wheel direction, servo limits, battery ratio) in the EEPROM.
// The full robot firmware (nano_robot_V_9_7) reads the same values.
//
// Board "Arduino Nano", processor "ATmega328P". Libraries: Servo, Wire, EEPROM (come with the Arduino IDE).
// Link: HC-05 on D0 / D1 at 115200 baud, or the USB cable. DISCONNECT THE HC-05 FROM D0 / D1 WHILE UPLOADING.
//
// Safety: nothing moves until the dashboard arms the output. No command for 400 ms stops the wheels;
// 3 s without any frame disarms the output.
//
// NOT TESTED on the real robot: wheels in the air first.
#include <Arduino.h>
#include <Wire.h>

#include "config.h"
#include "frame.h"
#include "settings.h"
#include "state.h"
#include "outputs.h"
#include "imu.h"
#include "protocol.h"

void setup() {
  pinMode(LED_PIN, OUTPUT);
  motorsInit();  // motors off, servos limp until told
  Serial.begin(LINK_BAUD);
  loadSettings();
  imuInit();
  startCalibration();
  blinkCount = 3;
}

void loop() {
  uint32_t now = millis();
  readLink(handleLine);

  bool linkAlive = lastRxMs && now - lastRxMs < LINK_LOST_MS;
  if (armed && !linkAlive) disarm();
  bool live = armed && now - lastCmdMs <= FAILSAFE_MS;

  static uint32_t lastLoopMs;
  float dt = (now - lastLoopMs) * 1e-3f;
  lastLoopMs = now;
  if (dt > 0.1f) dt = 0.1f;

  if (!live) {
    if (wheelPercent[0] || wheelPercent[1]) stopAll();
  } else {
    drive(0, cmdLeft);
    drive(1, cmdRight);
    servoCommand(0, cmdServo1);
    servoCommand(1, cmdServo2);
  }
  servoStep(dt);
  updateImu(now);

  if (linkAlive && now - lastTelemetryMs >= 100) {
    lastTelemetryMs = now;
    sendTelemetry();
  }
  txPump();

  // LED: on while talking, blinks for typed text.
  static uint32_t blinkMs;
  static int blinkStep;
  if (blinkCount && now - blinkMs > 150) {
    blinkMs = now;
    blinkStep++;
    if (blinkStep >= blinkCount * 2) blinkCount = blinkStep = 0;
  }
  digitalWrite(LED_PIN, blinkCount ? blinkStep % 2 == 0 : ((int32_t)(ledUntilMs - now) > 0 || linkAlive));
}
