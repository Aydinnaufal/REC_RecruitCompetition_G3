// outputs.h - wheels (L298N) and servos. The same wiring and the same PWM as nano_robot.
//   left  motor (A): IN1 D5, IN2 D4, ENA D11  (Timer 2 pin)
//   right motor (B): IN3 D3, IN4 D2, ENB D10  (made by Timer 2 interrupts: the Servo library owns Timer 1)
#pragma once
#include <Servo.h>

volatile uint8_t enbDuty;  // 0..255 for D10

ISR(TIMER2_OVF_vect) {
  if (enbDuty) PORTB |= _BV(PB2);
}
ISR(TIMER2_COMPB_vect) {
  PORTB &= ~_BV(PB2);
}

void setEnb(uint8_t duty) {
  uint8_t sreg = SREG;
  cli();
  enbDuty = duty;
  OCR2B = duty;
  if (duty == 0 || duty == 255) {
    TIMSK2 &= ~_BV(OCIE2B);
    if (duty) PORTB |= _BV(PB2);
    else PORTB &= ~_BV(PB2);
  } else {
    TIMSK2 |= _BV(OCIE2B);
  }
  SREG = sreg;
}

void motorsInit() {
  const uint8_t pins[] = {IN1, IN2, IN3, IN4, ENA_PIN, ENB_PIN};
  for (uint8_t p : pins) {
    pinMode(p, OUTPUT);
    digitalWrite(p, LOW);
  }
  TCCR2A = _BV(WGM21) | _BV(WGM20);  // fast PWM, prescaler 64 = 976 Hz
  TCCR2B = _BV(CS22);
  OCR2A = 0;
  OCR2B = 0;
  TIMSK2 = _BV(TOIE2);
}

// Wheel `side` (0 = left, 1 = right) at `percent`.
void drive(int side, int percent) {
  percent = constrain(percent, -100, 100);
  wheelPercent[side] = percent;
  int direction = (side ? invr : invl) > 0 ? -percent : percent;
  int pwm = percent ? map(abs(percent), 1, 100, (int)minpwm, 255) : 0;
  pwm = constrain(pwm, 0, 255);
  wheelPwm[side] = direction < 0 ? -pwm : pwm;
  digitalWrite(side ? IN3 : IN1, direction > 0);
  digitalWrite(side ? IN4 : IN2, direction < 0);
  if (side) setEnb(pwm);
  else analogWrite(ENA_PIN, pwm);
}

void stopAll() {
  drive(0, 0);
  drive(1, 0);
}

void disarm() {
  armed = false;
  cmdLeft = cmdRight = 0;
  stopAll();
}

// ---------------------------------------------------------------- servos
Servo servoDriver[2];
bool servoAttached[2];
const uint8_t SERVO_PIN[2] = {SERVO1_PIN, SERVO2_PIN};

void servoPulse(int i, int degrees) {
  if (!servoAttached[i]) {
    servoDriver[i].attach(SERVO_PIN[i], 500, 2400);
    servoAttached[i] = true;
  }
  servoDriver[i].writeMicroseconds(500 + (int)(1900L * degrees / 180));
}

// The limits servo i really uses; limits that cannot work are replaced by the safe ones.
void servoLimits(int i, int* low, int* high) {
  int a = constrain((int)(i ? lo2 : lo1), 0, 180);
  int b = constrain((int)(i ? hi2 : hi1), 0, 180);
  if (a > b) {
    int t = a;
    a = b;
    b = t;
  }
  if (b - a < SERVO_MIN_SPAN) {
    a = SERVO_SAFE_LOW;
    b = SERVO_SAFE_HIGH;
  }
  *low = a;
  *high = b;
}

// Servo i: -1 = limp (no pulses), -2 = keep as it is, otherwise an angle inside the limits, reached at SERVO_DPS.
void servoCommand(int i, int degrees) {
  if (degrees == -2) return;
  if (degrees < 0) {
    if (servoAttached[i]) {
      servoDriver[i].detach();
      servoAttached[i] = false;
    }
    servoAngle[i] = servoTarget[i] = -1;
    return;
  }
  int low, high;
  servoLimits(i, &low, &high);
  servoTarget[i] = constrain(degrees, low, high);
  if (servoAngle[i] < 0) {  // first command after limp: the real position is unknown, start there
    servoPosition[i] = servoTarget[i];
    servoAngle[i] = servoTarget[i];
    servoPulse(i, servoAngle[i]);
  }
}

void servoStep(float dt) {
  for (int i = 0; i < 2; i++) {
    if (servoAngle[i] < 0 || servoTarget[i] < 0 || servoPosition[i] == servoTarget[i]) continue;
    float diff = servoTarget[i] - servoPosition[i], most = SERVO_DPS * dt;
    servoPosition[i] += diff > most ? most : diff < -most ? -most : diff;
    int angle = (int)(servoPosition[i] + 0.5f);
    if (angle != servoAngle[i]) {
      servoAngle[i] = angle;
      servoPulse(i, angle);
    }
  }
}
