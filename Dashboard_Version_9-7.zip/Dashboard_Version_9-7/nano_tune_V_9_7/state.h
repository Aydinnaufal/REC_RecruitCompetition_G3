// state.h - everything that changes while the firmware runs.
#pragma once

// ---- what the dashboard asked for
bool armed = false;
int cmdLeft, cmdRight;               // wheels, -100..100 percent
int cmdServo1 = -2, cmdServo2 = -2;  // degrees; -1 = limp, -2 = keep
uint16_t lastSeq, telemetrySeq;
uint32_t lastCmdMs, lastTelemetryMs, lastRxMs;  // lastRxMs: a valid frame (0 = never)

// ---- outputs
int wheelPercent[2], wheelPwm[2];  // what the wheels get now
int servoAngle[2] = {-1, -1};      // angle now (-1 = limp: no pulses)
int servoTarget[2] = {-1, -1};     // angle it is asked to go to
float servoPosition[2];            // angle on its way there

// ---- sensors
bool imuOk = false, calibrating = true;
uint8_t whoAmI;
float imu[7];  // ax ay az (g), temperature (C), gx gy gz (deg/s)
float gyroBias, yaw;
float calSum;
int calSamples;
uint32_t calStartMs, lastImuMs;

// ---- LED
uint32_t ledUntilMs;
int blinkCount;
