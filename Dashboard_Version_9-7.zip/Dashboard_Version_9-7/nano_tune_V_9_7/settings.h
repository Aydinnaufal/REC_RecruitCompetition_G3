// settings.h - the tuning values, kept in the EEPROM. The table is the SAME as in nano_robot (same order, same
// addresses): what is tuned here is used by the robot. This sketch only changes the first eight.
#pragma once
#include <EEPROM.h>

float minpwm = 0;                                   // lowest PWM that still turns a wheel
float invl = 0, invr = 0;                           // 1 = this wheel is wired the other way round
float lo1 = SERVO_SAFE_LOW, hi1 = SERVO_SAFE_HIGH;  // servo 1 limits, degrees
float lo2 = SERVO_SAFE_LOW, hi2 = SERVO_SAFE_HIGH;  // servo 2 limits, degrees
float ratio = DEFAULT_VBAT_RATIO;                   // battery divider ratio

const uint8_t TUNE_COUNT = 8;
const uint8_t SETTING_COUNT = 23;  // the robot's table: slots after the first eight are not touched here
const char TUNE_NAME[TUNE_COUNT][8] PROGMEM = {"minpwm", "invl", "invr", "lo1", "hi1", "lo2", "hi2", "ratio"};
float* const TUNE_VALUE[TUNE_COUNT] = {&minpwm, &invl, &invr, &lo1, &hi1, &lo2, &hi2, &ratio};

const int EEPROM_MAGIC_ADDRESS = 0;
const uint16_t EEPROM_MAGIC = 0xEC01;
const int EEPROM_FIRST = 2;  // setting k lives at EEPROM_FIRST + 4 * k

int tuneIndex(const char* name) {
  for (uint8_t k = 0; k < TUNE_COUNT; k++)
    if (!strcmp_P(name, TUNE_NAME[k])) return k;
  return -1;
}

void loadSettings() {
  uint16_t magic;
  EEPROM.get(EEPROM_MAGIC_ADDRESS, magic);
  if (magic != EEPROM_MAGIC) {  // first start, or another layout: start clean
    for (int a = EEPROM_FIRST; a < EEPROM_FIRST + 4 * SETTING_COUNT; a++) EEPROM.update(a, 0xFF);
    EEPROM.put(EEPROM_MAGIC_ADDRESS, EEPROM_MAGIC);
  }
  for (uint8_t k = 0; k < TUNE_COUNT; k++) {
    float v;
    EEPROM.get(EEPROM_FIRST + 4 * k, v);
    if (!isnan(v) && !isinf(v)) *TUNE_VALUE[k] = v;  // never saved: keep the default
  }
}

// Change one value by name and keep it. Returns false for an unknown name.
bool changeSetting(const char* name, float value) {
  int k = tuneIndex(name);
  if (k < 0) return false;
  *TUNE_VALUE[k] = value;
  EEPROM.put(EEPROM_FIRST + 4 * k, value);
  return true;
}
