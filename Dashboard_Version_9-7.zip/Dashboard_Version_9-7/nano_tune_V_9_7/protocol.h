// protocol.h - the text protocol ($TYPE,field,field*HH, HH = XOR of the characters in hex).
//
// Dashboard -> robot
//   CMD,seq,left,right,servo1,servo2,enable   wheels in percent, servos in degrees (-1 limp, -2 keep)
//   TCFG,name,value                           change a tuning value (kept in the EEPROM)
//   PING,n   HELLO?   STOP   CAL
// Robot -> dashboard
//   HELLO,proto,fw,robot,version   RST,reason,seconds   PONG,n,ms   ACK,...
//   TCFG,minpwm,invl,invr,lo1,hi1,lo2,hi2,ratio     all tuning values
//   TUN,seq,ack,ms,pwmL,pwmR,s1,s2,gx,gy,gz,ax,ay,az,temp,yaw,vbat_mv,flags,whoami
#pragma once

void sendTuningValues() {
  Frame f(F("TCFG"));
  f.f(minpwm, 2).f(invl, 0).f(invr, 0).f(lo1, 1).f(hi1, 1).f(lo2, 1).f(hi2, 1).f(ratio, 3);
  f.send();
}

// Reject a value that would make a servo unable to move (or move past its ends).
bool servoLimitAllowed(const char* name, float value) {
  if (name[0] != 'l' && name[0] != 'h') return true;  // not lo1 hi1 lo2 hi2
  if (name[1] != 'o' && name[1] != 'i') return true;
  if (value < 0 || value > 180) return false;
  bool second = name[2] == '2';
  float otherLow = second ? lo2 : lo1, otherHigh = second ? hi2 : hi1;
  if (name[0] == 'l') return value <= otherHigh - SERVO_MIN_SPAN;
  return value >= otherLow + SERVO_MIN_SPAN;
}

int batteryMillivolts() {
  if (!BATTERY_FITTED) return 0;
  long sum = 0;
  for (int i = 0; i < 4; i++) sum += analogRead(BATTERY_PIN);
  return (int)(sum / 4 * 5000L / 1023 * ratio);
}

void sendTelemetry() {
  int batteryMv = batteryMillivolts();
  bool failsafe = millis() - lastCmdMs > FAILSAFE_MS;
  int flags = (armed ? 1 : 0) | (failsafe ? 2 : 0) | (imuOk && !calibrating ? 4 : 0) | (calibrating ? 8 : 0) |
              (batteryMv > 1000 && batteryMv < 6400 ? 16 : 0);
  Frame f(F("TUN"));
  f.i(++telemetrySeq).i(lastSeq).i((long)millis()).i(wheelPwm[0]).i(wheelPwm[1]).i(servoAngle[0]).i(servoAngle[1]);
  f.f(imu[4], 1).f(imu[5], 1).f(imu[6] - gyroBias, 1).f(imu[0], 2).f(imu[1], 2).f(imu[2], 2).f(imu[3], 1);
  f.f(yaw, 1).i(batteryMv).i(flags).i(whoAmI);
  f.send();
}

void handleLine(char* line) {
  char* body = openFrame(line);
  if (!body) {  // typed text lights the LED; a damaged frame is ignored
    if (line[0] != '$') {
      ledUntilMs = millis() + 2000;
      blinkCount = 3;
      Frame(F("ACK")).txt(F("TEXT")).send();
    }
    return;
  }
  lastRxMs = millis() | 1;

  if (!strncmp_P(body, PSTR("CMD,"), 4)) {
    long v[6];
    if (getLongs(body + 4, v, 6) == 6) {
      lastSeq = (uint16_t)v[0];
      cmdLeft = constrain(v[1], -100, 100);
      cmdRight = constrain(v[2], -100, 100);
      cmdServo1 = (int)v[3];
      cmdServo2 = (int)v[4];
      armed = v[5] == 1;
      lastCmdMs = millis();
    }
  } else if (!strncmp_P(body, PSTR("PING,"), 5)) {
    Frame f(F("PONG"));
    f.ram(body + 5).i((long)millis());
    f.send();
  } else if (!strncmp_P(body, PSTR("HELLO?"), 6)) {
    Frame hello(F("HELLO"));
    hello.i(1).txt(F("rec-tune")).txt(F("tune")).ram(FW_VERSION);
    hello.send();
    sendTuningValues();
    Frame rst(F("RST"));
    rst.txt(F("reset")).i((long)(millis() / 1000));
    rst.send();
  } else if (!strncmp_P(body, PSTR("STOP"), 4)) {
    disarm();
    Frame(F("ACK")).txt(F("STOP")).send();
  } else if (!strncmp_P(body, PSTR("CAL"), 3)) {
    stopAll();
    startCalibration();
    Frame(F("ACK")).txt(F("CAL")).send();
  } else if (!strncmp_P(body, PSTR("TCFG,"), 5)) {
    const char* p = body + 5;
    char name[8];
    uint8_t length = 0;
    while (*p && *p != ',' && length < 7) name[length++] = *p++;
    name[length] = 0;
    float value;
    if (*p == ',' && getFloat(p + 1, &value) && servoLimitAllowed(name, value)) changeSetting(name, value);
    sendTuningValues();  // always answer: the dashboard shows what the robot really holds
  }
}
