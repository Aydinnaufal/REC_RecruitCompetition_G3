// config.h - names, pins and limits of the tuning firmware (Arduino Nano + HC-05 + L298N + MPU6050 + 2 servos).
#pragma once

const char FW_VERSION[] = "V_9_7_nano";
const uint32_t LINK_BAUD = 115200;    // the HC-05 must be set to this (see docs/NANO.md)

// ---------------------------------------------------------------- pins (same as the robot firmware)
const uint8_t IN1 = 5, IN2 = 4;       // left motor  (L298N motor A) direction
const uint8_t IN3 = 3, IN4 = 2;       // right motor (L298N motor B) direction
const uint8_t ENA_PIN = 11;           // left motor speed  (PWM, Timer 2)
const uint8_t ENB_PIN = 10;           // right motor speed (PWM made by Timer 2 too, see outputs.h)
const uint8_t SERVO1_PIN = 6;         // grip
const uint8_t SERVO2_PIN = 9;         // lift
const uint8_t BATTERY_PIN = A0;       // battery divider (not fitted in the schematic)
const uint8_t LED_PIN = 13;           // on-board LED
// MPU6050 gyro: SDA = A4, SCL = A5 (see imu.h)

// ---------------------------------------------------------------- safety
const uint32_t FAILSAFE_MS = 400;     // no valid CMD for this long = the wheels stop
const uint32_t LINK_LOST_MS = 3000;   // after this long without a frame the output is disarmed

// ---------------------------------------------------------------- servos
const float SERVO_DPS = 300.0f;       // servos move at most this fast (degrees per second)
const int SERVO_SAFE_LOW = 10, SERVO_SAFE_HIGH = 170;  // used when no limits are saved or the saved ones cannot work
const int SERVO_MIN_SPAN = 10;        // limits closer together than this (degrees) are ignored

// ---------------------------------------------------------------- battery
// The schematic has no battery divider. To measure the pack: 100k from battery + to A0, 47k from A0 to GND, then set this true.
const bool BATTERY_FITTED = false;
const float DEFAULT_VBAT_RATIO = 147.0f / 47.0f;
