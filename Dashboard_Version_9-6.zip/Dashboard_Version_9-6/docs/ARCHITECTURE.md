# Architecture

`run_dashboard.py` calls `robot_station.main.main()`. Dependencies point downwards only:

```
main  ->  app  ->  screens  ->  ui  ->  (pygame)
            |         |
            |         +-> rendering -> simulation
            +-> comms, inputs, autotune
config, mathutil: used by everyone
```

| Package | Job |
|---|---|
| `config.py` | Version, file names, page names, screen layout numbers (`CW`, `CH`, `LX` ... `PAGE`) |
| `main.py` | `Dashboard`: window, event loop, fullscreen, quit |
| `comms/` | `protocol` (frame encode/parse), `transports` (serial, BLE, `ble.py`), `link` (connection, arming, telemetry, commands), `pose`, `errors` |
| `inputs/` | Gamepad reading, button/axis mapping, event log |
| `simulation/` | The simulated robot and arena (used when no robot reports a heading) |
| `rendering/` | Camera and drawing of the 3D scene |
| `ui/` | Fonts, colours, widgets (button, spin, dropdown), gauges |
| `screens/` | What each page looks like. `widget_screen.py` builds the buttons; `*_page.py` draw the rest |
| `app/` | The application state, as small mixins: `settings`, `timer`, `tune_page`, `connection`, `drive`, `pid_page`, `autotune`, joined in `core.App` |
| `autotune/` | Pure logic with no pygame and no I/O: `metrics`, `rules`, `tuner` (testable on its own) |

Rules of thumb: screens only read `App`; `App` never draws; `autotune/` knows nothing about the robot link.

## Firmware

`esp32_tune_V_9_6/` is the sketch for the Tune page: `config.h`, `pwm.h`, `settings.h`, `state.h`, `ble_stream.h`, `outputs.h` (wheels, servos), `imu.h`, `protocol.h`.

### Robot firmware (`esp32_robot_V_9_6/`)

`config.h` pins and constants, `pwm.h`, `settings.h` (flash), `state.h`, `ble_stream.h`, `motors.h`, `gyro.h`, `protocol.h`, `control.h` (the control laws), and the `.ino` with `setup()` and `loop()`.

### BACK and turning (V 9.6)
`App.back_pressed` first calls `App.cancel_turns()`: `sim.cancel_snap()` (drops the dashboard-side snap target), `autotune_stop('BACK')`, `pid_cancel('stopped')` and `tune_stop()`. Then it arms or disarms as before. The robot needs no change: with the snap target gone the dashboard stops sending the heading field, and a disarm sends zero wheel speed.
