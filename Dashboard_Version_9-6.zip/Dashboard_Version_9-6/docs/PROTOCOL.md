# Protocol (rec1)

A frame is `$TYPE,f1,f2,...*HH` followed by a newline. `HH` is the XOR of every byte between `$` and `*`, in hex. Floats have two decimals.

## PC to robot

| Frame | Fields | Notes |
|---|---|---|
| `HELLO?` | | Ask the robot to introduce itself (also sends one HLD) |
| `PING` | n | Answered by `PONG,n,ms` |
| `CMD` | seq, vl, vr, grip, lift, en [, hdg [, steer]] | 30 Hz. vl and vr are -100..100. `en` = 1 arms. `hdg` is the target heading in tenths of a degree, and may be missing. **`steer` (new in V 9.0)**: 1 means reach `hdg` while driving (hold control) instead of an in-place snap turn |
| `CFG` | key, value | Set and save one setting in flash. Keys: minpwm, invl, invr, lo1, hi1, lo2, hi2, go, gc, hold, kp, ki, kd, gl, gr, ml, mr, bal, gsign, skp, skd, gscale (V 9.6) |
| `STOP`, `ZERO`, `CAL` | | Stop the wheels, re-zero the heading, calibrate the gyro |

## Robot to PC

| Frame | Fields |
|---|---|
| `HELLO` | proto, fw, robot, version |
| `RST` | reason, seconds | Sent after a restart |
| `TEL` | seq, ack, ms, yaw, gz, vl, vr, grip, lift, vbat_mv, flags (10 Hz) |
| `HLD` | mode, target, err, corr, bal, gl, gr, ml, mr, kp, ki, kd, hold, gsign, skp, skd, gscale (V 9.6). Every 100 ms, every 50 ms while a target is active (was 100 ms only) |
| `ACK` | what, key |
| `PONG` | n, ms |

`HLD.mode`: 1 idle, 2 hold, 3 snap turn.

## Safety

The robot stops its wheels when no `CMD` arrives for 400 ms. It is disarmed at boot and after every new link. Yaw is positive when turning left; `err = yaw - target`.

## Tuning firmware (Tune page)

| Frame | Direction | Fields |
|---|---|---|
| `CMD` | PC to robot | seq, left, right, servo1, servo2, enable. Servo angle 0..180, -1 = limp, -2 = keep |
| `TCFG` | PC to robot | name, value. Names: minpwm, invl, invr, lo1, hi1, lo2, hi2, ratio. Kept in flash |
| `TCFG` | robot to PC | minpwm, invl, invr, lo1, hi1, lo2, hi2, ratio. Sent after every `TCFG` and `HELLO?`, so the dashboard always shows what the robot holds |
| `TUN` | robot to PC | seq, ack, ms, pwmL, pwmR, s1, s2, gx, gy, gz, ax, ay, az, temp, yaw, vbat_mv, flags, whoami |
| `CAL`, `STOP`, `PING`, `HELLO?` | PC to robot | as above |

V 9.1: the robot refuses a servo limit outside 0..180 or closer than 10 degrees to the other limit of the same servo, and still answers with its real values. Reset all and Undo send limits low, high, low, so a move of the window always completes.
