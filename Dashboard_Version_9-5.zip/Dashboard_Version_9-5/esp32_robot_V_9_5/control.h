// control.h - from the stick command to the wheels, with the gyro closing the loop.
//
//   stick command -> [ snap turn | straight-line hold ] -> ramp -> wheels
//
// Sign convention: yaw grows when the robot turns LEFT. headingError = yaw - target, so a
// positive error means "turned too far left"; the correction makes the left wheel faster
// (l += c, r -= c), which turns the robot back to the right.
//
// There are three ways the heading is controlled:
//
//  1. SNAP TURN (controlMode 3). The dashboard sent a target heading while the wheels are not
//     driving: the robot spins in place, PD on the error:   w = skp * e - skd * yawRate
//
//  2. STRAIGHT HOLD (controlMode 2). Both wheel commands are (nearly) equal and the robot drives:
//     the heading is latched once the last turn settled and a PID keeps it:
//         c = kp * error + kd * yawRate + bal * speed / 100
//     "bal" is the integral term. It is learned (ki * error) and is the extra power the weaker
//     wheel needs; it is kept in flash.
//
//  3. STEERING (also controlMode 2). Like the hold, but the heading to hold is the target from the
//     dashboard (CMD field 8 = 1). This is how auto-tune excites kp, kd and ki without stopping.
#pragma once

// True when the wheel commands ask for the same speed and the robot actually drives.
bool wheelsDriveStraight(float averageCmd) {
  return fabsf(cmdLeft - cmdRight) < STRAIGHT_MAX_DIFF && fabsf(averageCmd) > STRAIGHT_MIN_SPEED;
}

// Snap turn: spin in place until the gyro says we are at turnTarget. Sets left and right (percent).
//
//   w = skp * error - skd * turn rate        the PD, as before
//   |w| <= SNAP_APPROACH * |error|           the closer to the target, the slower: no hard push at the end
//   |w| <  SNAP_MIN                          made by pulsing SNAP_MIN on and off, so tiny corrections are gentle
//   arrived                                  wheels off, and they stay off until the error is SNAP_REARM times the
//                                            tolerance (no tiny back-and-forth wiggle around the target)
void snapTurn(float& left, float& right) {
  controlMode = 3;
  holding = false;
  float e = turnTarget - yaw;  // positive: the target is to the left
  headingError = -e;
  bool still = fabsf(yawRate) < SNAP_STILL;
  if (fabsf(e) < SNAP_TOL && still) snapDone = true;
  else if (fabsf(e) > SNAP_TOL * SNAP_REARM) snapDone = false;
  bool timedOut = millis() - turnSinceMs > SNAP_TIMEOUT_MS;
  if (snapDone || timedOut) {
    left = right = 0;
    return;
  }
  float w = skp * e - skd * yawRate;
  bool braking = w * yawRate < 0;  // the wheels push against the turn
  if (!braking) w = constrain(w, -SNAP_APPROACH * fabsf(e), SNAP_APPROACH * fabsf(e));  // slow on the way in
  // Moving toward the target faster than it can be stopped from: brake in proportion to the excess rate.
  float fastest = sqrtf(2.0f * SNAP_DECEL * fabsf(e));
  if (e * yawRate > 0 && fabsf(yawRate) > fastest) {
    w = -(yawRate > 0 ? 1 : -1) * SNAP_BRAKE * (fabsf(yawRate) - fastest);
    braking = true;
  }
  w = constrain(w, -SNAP_MAX, SNAP_MAX);
  float size = fabsf(w);
  if (size < SNAP_MIN && !(braking && fabsf(yawRate) > SNAP_PULSE_BELOW_RATE)) {  // below the lowest steady speed: pulse it, the average is what was wanted
    bool on = (millis() % SNAP_PULSE_MS) < size / SNAP_MIN * SNAP_PULSE_MS;
    w = on ? (w < 0 ? -SNAP_MIN : SNAP_MIN) : 0;
  }
  left = -w;
  right = w;
  correction = w;
}

// Straight hold, or steering to turnTarget while driving. Adds the correction to l and r.
void holdHeading(float& left, float& right, float averageCmd, bool steering, float dt) {
  bool gyroReady = imuOk && !gyroCalibrating;
  // Learned: the weaker wheel needs a bit more, in proportion to speed (nothing in a spin: average is 0).
  float balanceTerm = bal * averageCmd / 100.0f;
  bool straight = hold > 0 && gyroReady && wheelsDriveStraight(averageCmd);

  if (steering) {  // the target comes from the dashboard
    holding = true;
    holdYaw = turnTarget;
  } else if (!straight) {
    holding = false;
    straightSinceMs = millis();
  } else if (!holding && millis() - straightSinceMs > HOLD_LATCH_MS && fabsf(yawRate) < HOLD_LATCH_RATE) {
    holding = true;  // latch the heading once the last turn has settled
    holdYaw = yaw;
  }
  if (wasSteering && !steering) {  // steering just ended: latch the heading we ended on
    holding = false;
    straightSinceMs = millis();
  }
  wasSteering = steering;

  float c = balanceTerm;
  if (holding) {
    controlMode = 2;
    headingError = yaw - holdYaw;  // + = drifted left
    float pd = kp * headingError + kd * yawRate;
    // The integral term becomes the balance. It stops growing while the correction is at its limit.
    if (fabsf(pd + balanceTerm) < HOLD_MAX)
      bal = constrain(bal + ki * headingError * (averageCmd > 0 ? 1 : -1) * dt, -BAL_MAX, BAL_MAX);
    c = constrain(pd + balanceTerm, -HOLD_MAX, HOLD_MAX);
  }
  left += c;
  right -= c;
  correction = c;
}

// Stick command -> gyro control -> ramp -> wheels. Called every loop while armed.
void drive(float dt) {
  float left = cmdLeft, right = cmdRight;
  float averageCmd = (cmdLeft + cmdRight) / 2.0f;
  bool gyroReady = imuOk && !gyroCalibrating;
  controlMode = hold > 0 && gyroReady ? 1 : 0;
  headingError = correction = 0;

  // Steering: reach the dashboard's heading while driving, with the hold PID.
  bool steering = turnActive && steerWhileDriving && hold > 0 && gyroReady && wheelsDriveStraight(averageCmd);

  if (turnActive && gyroReady && !steering) snapTurn(left, right);
  else holdHeading(left, right, averageCmd, steering, dt);

  speedLeft = ramp(speedLeft, constrain(left, -100.0f, 100.0f), dt);
  speedRight = ramp(speedRight, constrain(right, -100.0f, 100.0f), dt);
  setWheel(0, speedLeft);
  setWheel(1, speedRight);
}
