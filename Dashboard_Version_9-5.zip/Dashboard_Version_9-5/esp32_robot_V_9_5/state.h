// state.h - everything that changes while the robot runs.
#pragma once

// ---- link and safety
bool armed = false;            // the dashboard armed the output (CMD enable = 1)
uint32_t lastCmdMs;            // when the last valid CMD arrived
uint16_t lastCmdSeq;           // its sequence number (echoed in TEL so the dashboard can time the round trip)
uint16_t telemetrySeq;         // numbers the TEL frames

// ---- what the dashboard asked for (percent, -100..100)
int cmdLeft, cmdRight;         // wheel speeds
int cmdGrip;                   // grip 0..100
int cmdLift;                   // lift stick -100..100 (tower only)
bool snapDone;                 // the snap turn arrived and waits until the error grows past SNAP_REARM
bool turnActive;               // a target heading came with the command
float turnTarget;              // ... the target yaw in degrees
bool steerWhileDriving;        // ... and it is to be reached while driving (see control.h), not in place
uint32_t turnSinceMs;          // when the current target first arrived

// ---- wheels (percent, after the ramp)
float speedLeft, speedRight;

// ---- gyro
bool imuOk;                    // the MPU6050 answered at start-up
bool gyroCalibrating = true;   // measuring the zero-rate offset: the robot must stand still for one second
int calSamples;
double calSum;
uint32_t calStartMs;
float gyroBias;                // deg/s measured while still
float yaw;                     // heading in degrees, + = turned left
float yawRate;                 // deg/s, + = turning left
uint32_t lastGyroMs;

// ---- gyro control (what the PID page shows in the HLD report)
int controlMode;               // 0 off, 1 ready, 2 holding a heading, 3 turning to a target
bool holding;                  // the straight-line heading is latched
float holdYaw;                 // ... and this is it
bool wasSteering;
uint32_t straightSinceMs;      // when the wheels last started to ask for the same speed
float headingError;            // yaw - target, in degrees
float correction;              // wheel-speed difference added by the control, in percent

// ---- servos
bool isTower;
float liftPosition;            // tower lift, 0..100 %
int servoAngle[2] = {-1, -1};  // angle now (-1 = limp: not yet commanded)
int servoTarget[2] = {-1, -1}; // wanted angle
float servoPosition[2];        // angle on its way there

// ---- LED and bookkeeping
uint32_t ledUntilMs;
int blinkCount;
uint32_t lastTelemetryMs, lastHoldReportMs;
