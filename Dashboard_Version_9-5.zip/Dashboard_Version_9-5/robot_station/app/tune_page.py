"""The Tune page: what the tuning firmware reports and what the sliders ask of it."""

import os

from robot_station import ui
from robot_station.config import SERVO_MIN_SPAN, TUNE, TUNE_DEFAULTS, TUNE_FILE

RESET_CONFIRM_S = 3.0  # "Reset all" must be pressed twice within this time


class TunePageMixin:
    """The Tune page: what the tuning firmware reports and what the sliders ask of it."""

    def _init_tune_page(self):
        # What the page asks of the robot: wheels in percent, servos in degrees (None = limp).
        self.tune = dict(vl=0.0, vr=0.0, s1=None, s2=None)
        self.sweep = False  # servos sweep between their limits
        self.sweep_t = 0.0
        self.ramp = None  # the start-power search, see ramp_toggle()
        self.tune_backup = None  # the values "Undo" goes back to: those from when the robot connected
        self._reset_asked_until = 0.0  # "Reset all" was pressed once and waits for the second press

    def tune_tel(self):
        """The tuning firmware's latest report, or {} when there is none (not connected, silent, or the robot runs another firmware)."""
        l = self.link
        t = l.tune_tel
        return t if t and l.connected and l.clock() - t['at'] < 1.0 else {}

    def tune_status(self):
        """(text, colour) for the page header."""
        l = self.link
        if not l.connected:
            return 'NOT CONNECTED: open the LINK tab, connect to REC-Robot', ui.WARN
        if l.hello and l.hello.get('robot') != 'tune':
            return (
                'this robot runs the normal firmware, not esp32_tune_V_9_5: flash the tuning sketch',
                ui.BAD,
            )
        if not self.tune_tel():
            return 'connected, waiting for tuning data...', ui.WARN
        return (
            'OUTPUT LIVE: sliders move the robot'
            if l.armed
            else 'connected. Press ARM OUTPUT on the LINK tab to move anything'
        ), (ui.BAD if l.armed else ui.OK)

    def cfg(self, key):
        """A tuning value as the tuning firmware reports it, or None."""
        l = self.link
        return l.tune_cfg.get(key) if l.connected else None

    def set_cfg(self, key, v):
        """Change a tuning value in the robot (TCFG frame). Servo limits that would leave the servo no room to move are refused."""
        if not self._servo_limit_ok(key, v):
            self.link.say(
                'err',
                'servo limits must stay at least %d degrees apart (min below max)' % SERVO_MIN_SPAN,
            )
            return
        self._send_cfg(key, v)

    def _send_cfg(self, key, v):
        self.link.send_frame('TCFG', key, v)
        self.link.tune_cfg[key] = float(v)  # shown at once; the robot's answer confirms it

    def _servo_limit_ok(self, key, v):
        """False when a new servo limit would be closer than SERVO_MIN_SPAN to the other limit of that servo."""
        if key[:2] not in ('lo', 'hi'):
            return True
        other = self.cfg(('hi' if key[:2] == 'lo' else 'lo') + key[2:])
        if other is None:
            return True
        return v <= other - SERVO_MIN_SPAN if key[:2] == 'lo' else v >= other + SERVO_MIN_SPAN

    # ---------------------------------------------------------------- reset and undo
    def reset_confirming(self):
        """True for a few seconds after the first press of Reset all."""
        return self.link.clock() < self._reset_asked_until

    def reset_all(self):
        """Reset all: the first press asks, the second (within RESET_CONFIRM_S) puts every tuning value back to its default."""
        link = self.link
        if not link.tune_cfg:
            return
        if not self.reset_confirming():
            self._reset_asked_until = link.clock() + RESET_CONFIRM_S
            link.say(
                'sys',
                'Reset all: press it again within %d s to put start power, wheel direction, servo limits '
                'and the battery ratio back to their defaults' % RESET_CONFIRM_S,
            )
            return
        self._reset_asked_until = 0.0
        self.tune_backup = dict(link.tune_cfg)  # what Undo brings back
        self._put_values(TUNE_DEFAULTS)
        link.say('sys', 'tuning values reset to their defaults. Undo brings the old ones back')

    def undo_values(self):
        """Undo: put back the values from when the robot connected, or from just before the last Reset all. Pressing it again goes forward again."""
        link = self.link
        if not self.tune_backup or not link.tune_cfg:
            return
        current = dict(link.tune_cfg)
        self._put_values(self.tune_backup)
        self.tune_backup = current
        link.say('sys', 'previous tuning values put back (Undo again to go forward)')

    def _put_values(self, values):
        """Send a whole set of tuning values. The servos are let go first and the wheels stopped, so nothing jumps."""
        self.tune_stop()
        self.set_servo(1, None)
        self.set_servo(2, None)
        for key in ('minpwm', 'invl', 'invr', 'ratio'):
            if key in values:
                self._send_cfg(key, values[key])
        # The robot refuses limits that would be too close together at any moment, so each pair goes
        # low, high, low: whichever order the move needs, the last frame completes it.
        for n in ('1', '2'):
            for key in ('lo' + n, 'hi' + n, 'lo' + n):
                if key in values:
                    self._send_cfg(key, values[key])

    def set_motor(self, side, v):
        """Set a wheel slider (side 0 = left, 1 = right); stops a running start-power search on that side."""
        self.tune['vl' if side == 0 else 'vr'] = float(v)
        if self.ramp and self.ramp['side'] == side:
            self.ramp = None

    def set_servo(self, i, v):
        """Set a servo slider in degrees, or None for limp."""
        self.tune['s%d' % i] = None if v is None else int(v)
        self.sweep = False

    def tune_stop(self):
        """Zero both wheels and stop the ramp and the servo sweep."""
        self.tune['vl'] = self.tune['vr'] = 0.0
        self.ramp, self.sweep = None, False

    def servo_value(self, i):
        """The servo slider position (90 when limp)."""
        v = self.tune['s%d' % i]
        return 90 if v is None else v

    def ramp_toggle(self, side):
        """Find the lowest drive that turns a wheel: the wheel is brought up slowly from 0, press again the moment it starts to turn."""
        if self.ramp and self.ramp['side'] == side:
            t = self.tune_tel()
            pwm = abs(t.get('pwm_l' if side == 0 else 'pwm_r', 0))
            self.tune_stop()
            if pwm:
                self.set_cfg('minpwm', pwm)
                self.link.say('sys', 'wheel started at PWM %d: minpwm saved' % pwm)
            return
        self.tune_stop()
        self.set_cfg('minpwm', 0)  # with minpwm 0 the percent goes straight to PWM
        self.ramp = dict(side=side, pct=0.0)

    def invert(self, side):
        """Reverse the direction of a wheel."""
        k = 'invl' if side == 0 else 'invr'
        self.set_cfg(k, 0 if self.cfg(k) else 1)

    def save_values(self):
        """Write the tuning values to tuning_values.txt, ready to paste into the firmware."""
        c = self.link.tune_cfg
        if not c:
            return
        lines = [
            '// Robot Station V 9.5 tuning values: they are kept in the robot already',
            'const int MIN_PWM = %d;' % c['minpwm'],
            'const bool INVERT_LEFT = %s, INVERT_RIGHT = %s;'
            % ('true' if c['invl'] else 'false', 'true' if c['invr'] else 'false'),
            'servo 1 limits: %d .. %d degrees' % (c['lo1'], c['hi1']),
            'servo 2 limits: %d .. %d degrees' % (c['lo2'], c['hi2']),
            'const float VBAT_RATIO = %.4f;' % c['ratio'],
        ]
        try:
            with open(TUNE_FILE, 'w') as f:
                f.write('\n'.join(lines) + '\n')
            self.link.say('sys', 'saved %s' % os.path.basename(TUNE_FILE))
        except Exception as e:
            self.link.say('err', 'could not save the values: %s' % e)

    def tick_tune(self, dt):
        """Call every frame: keep sliders at zero while disarmed, advance the ramp and sweep, send the Tune command."""
        l = self.link
        if not l.connected:
            self.tune_backup = None  # the next connection takes a new snapshot
        elif self.tune_backup is None and l.tune_cfg:
            self.tune_backup = dict(l.tune_cfg)  # the values the robot had when we connected
        if self.mode != TUNE:
            l.tune = None
            return
        if not l.armed:
            self.tune['vl'] = self.tune['vr'] = (
                0.0  # never leave a slider up: arming must not start the wheels
            )
        if self.ramp:
            self.ramp['pct'] += dt * 3.0  # 3 % per second: slow enough to catch the moment a fast (9 V) motor starts
            if self.ramp['pct'] >= 100:
                self.tune_stop()
            else:
                self.tune['vl' if self.ramp['side'] == 0 else 'vr'] = self.ramp['pct']
        if self.sweep:
            self.sweep_t += dt
            ph = (self.sweep_t % 4.0) / 2.0
            ph = ph if ph <= 1 else 2 - ph
            for i, (lo, hi) in (
                (1, (self.cfg('lo1'), self.cfg('hi1'))),
                (2, (self.cfg('lo2'), self.cfg('hi2'))),
            ):
                lo, hi = 0 if lo is None else lo, 180 if hi is None else hi
                self.tune['s%d' % i] = int(lo + (hi - lo) * ph)
        t = self.tune
        l.tune = dict(
            vl=t['vl'],
            vr=t['vr'],
            s1=-1 if t['s1'] is None else t['s1'],
            s2=-1 if t['s2'] is None else t['s2'],
        )
