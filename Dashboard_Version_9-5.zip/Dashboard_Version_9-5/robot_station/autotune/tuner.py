"""The auto-tuner: turn, measure, adjust, turn again.

The tuner never talks to the robot itself. It is a small state machine that is asked two things
over and over by whoever drives it (the dashboard):

1. ``next_test()``: which test should the robot run next, with which gains?
2. ``report(rows, t0, start_yaw)``: here is what the robot did, as PID-history rows.

Stages (each one is a series of tests, ``cycles`` of them)::

    turn   skp, skd   turn in place by +-turn_deg          (snap-turn controller)
    steer  kp, kd     change heading by +-steer_deg while driving forward / backward
                      (straight-line controller; Ki is switched off so it cannot disturb this)
    drift  ki         drive straight with the learned balance reset to zero; Ki is how fast
                      the robot learns to cancel its own lean

Every test is measured (``metrics.py``), compared with the best run so far, and the rules
(``rules.py``) pick the next gains. A gain set that makes things worse is thrown away and the next
try uses a smaller step, so the result is never worse than the best run that was measured.
"""

from dataclasses import dataclass, field

from .metrics import analyze_drift, analyze_step
from .rules import propose_drift, propose_steer, propose_turn

START_STEP = 0.5  # first change: about half of the current gain
MIN_STEP = 0.06  # below this the tuner stops: further changes are too small to measure
IMPROVEMENT = 0.02  # a run must be this much cheaper than the best one to count as better

# Longest a test may run, seconds.
TURN_WINDOW_S = 4.0
STEER_WINDOW_S = 3.0
DRIFT_WINDOW_S = 4.0

# The firmware limits the output of each controller; the metrics need to know to judge saturation.
TURN_CORRECTION_LIMIT = 50.0  # SNAP_MAX in the firmware
STEER_CORRECTION_LIMIT = 25.0  # HOLD_MAX in the firmware

TOLERANCE_DEG = 2.0  # "on target" for turn and steer
DRIFT_TOLERANCE_DEG = 1.0

GAIN_KEYS = ('skp', 'skd', 'kp', 'kd', 'ki')


@dataclass
class TuneSettings:
    """What the person chose before pressing Auto-tune."""

    cycles: int = 4  # tests per stage (the drift stage uses half, at least 2)
    tune_turn: bool = True  # stage turn:  skp, skd
    tune_hold: bool = True  # stages steer and drift:  kp, kd, ki
    turn_deg: float = 60.0  # size of the turn
    steer_deg: float = 15.0  # size of the heading change while driving
    drive_speed: float = 50.0  # wheel speed of the driving tests, percent


@dataclass
class TestRequest:
    """One test for the robot to run."""

    stage: str  # 'turn', 'steer' or 'drift'
    kind: str  # the same as stage; the dashboard runs a test of this kind
    cycle: int  # 1-based number inside the stage
    cycles: int  # how many tests the stage will run at most
    deg: float  # heading change (0 for drift)
    speed: float  # wheel speed in percent, negative = reverse
    duration: float  # longest the test may take, seconds
    gains: dict  # gains the robot must have for this test
    force: tuple = ()  # settings that must be sent even if they look unchanged (e.g. ('bal',))
    description: str = ''


@dataclass
class _Stage:
    """The progress of one stage."""

    name: str
    keys: tuple
    cycles: int
    propose: object
    candidate: dict = field(default_factory=dict)
    best_cost: float = None
    best_metrics: object = None
    done: int = 0  # tests finished
    step: float = START_STEP


class AutoTuner:
    """Runs the stages in order. See the module documentation."""

    def __init__(self, settings, start_gains):
        self.settings = settings
        self.start_gains = dict(start_gains)
        self.best_gains = dict(start_gains)  # the best value of every gain found so far
        self.messages = []  # everything the tuner has to say, in order
        self.history = []  # one dict per finished test
        self.aborted = ''
        self._bad_runs = 0
        self._pending = None
        self._stage_names = []
        if settings.tune_turn:
            self._stage_names.append('turn')
        if settings.tune_hold:
            self._stage_names += ['steer', 'drift']
        self._stage_index = -1
        self._stage = None
        self._next_stage()

    # ---------------------------------------------------------------- state
    @property
    def finished(self):
        """True when all stages are done, or the tuner was aborted."""
        return bool(self.aborted) or self._stage is None

    @property
    def stage_name(self):
        return self._stage.name if self._stage else ''

    @property
    def progress(self):
        """(tests done, tests planned at most) over all stages."""
        planned = self._planned_total()
        done = sum(1 for _ in self.history)
        return done, planned

    def _planned_total(self):
        return sum(self._cycles_for(n) for n in self._stage_names)

    def _cycles_for(self, name):
        cycles = max(1, int(self.settings.cycles))
        return max(2, cycles // 2) if name == 'drift' else cycles

    def _next_stage(self):
        self._stage_index += 1
        if self._stage_index >= len(self._stage_names):
            self._stage = None
            return
        name = self._stage_names[self._stage_index]
        keys, propose = {
            'turn': (('skp', 'skd'), propose_turn),
            'steer': (('kp', 'kd'), propose_steer),
            'drift': (('ki',), propose_drift),
        }[name]
        self._stage = _Stage(name, keys, self._cycles_for(name), propose)
        self._stage.candidate = {k: self.best_gains[k] for k in keys}

    # ---------------------------------------------------------------- 1. what to run next
    def next_test(self):
        """The test to run now (the same one again until ``report`` was called)."""
        stage, s = self._stage, self.settings
        if stage is None:
            return None
        sign = (
            1 if stage.done % 2 == 0 else -1
        )  # alternate direction so the robot stays where it is
        gains = dict(self.best_gains)
        gains.update(stage.candidate)
        force = ()
        if stage.name == 'turn':
            deg, speed, duration = sign * s.turn_deg, 0.0, TURN_WINDOW_S
            what = 'turn %+d deg in place' % deg
        elif stage.name == 'steer':
            gains['ki'] = 0.0  # no learning while the P and D gains are judged
            deg, speed, duration = sign * s.steer_deg, sign * s.drive_speed, STEER_WINDOW_S
            what = 'steer %+d deg while %s' % (deg, 'driving' if sign > 0 else 'reversing')
        else:
            force = ('bal',)  # start every run with the balance forgotten, so the lean shows
            gains['bal'] = 0.0
            deg, speed, duration = 0.0, sign * s.drive_speed, DRIFT_WINDOW_S
            what = 'straight %s' % ('forward' if sign > 0 else 'backward')
        changed = ', '.join('%s %.2f' % (k, stage.candidate[k]) for k in stage.keys)
        self._pending = TestRequest(
            stage.name,
            stage.name,
            stage.done + 1,
            stage.cycles,
            deg,
            speed,
            duration,
            gains,
            force,
            '%s %d/%d: %s  (%s)' % (stage.name, stage.done + 1, stage.cycles, what, changed),
        )
        return self._pending

    # ---------------------------------------------------------------- 2. what happened
    def report(self, rows, t0, start_yaw):
        """Measure the finished test, learn from it, decide the next gains. Returns a message."""
        request, stage = self._pending, self._stage
        if request is None or stage is None:
            return ''
        metrics = self._measure(request, rows, t0, start_yaw)
        if metrics is None:
            self._bad_runs += 1
            note = 'no usable data from the last test (did the robot move?)'
            if self._bad_runs >= 2:
                self.abort(
                    'two tests in a row gave no data: check the link, the gyro and that the output is armed'
                )
            return self._say(note)
        self._bad_runs = 0

        better = stage.best_cost is None or metrics.cost < stage.best_cost - IMPROVEMENT
        tested = dict(stage.candidate)
        if better:
            stage.best_cost, stage.best_metrics = metrics.cost, metrics
            self.best_gains.update(tested)
        else:
            stage.candidate = self.best_gains_for(stage)  # throw the try away
        stage.step = max(MIN_STEP, stage.step * 0.85) if better else stage.step * 0.5
        stage.done += 1
        self.history.append(
            dict(stage=stage.name, cycle=stage.done, gains=tested, metrics=metrics, better=better)
        )

        text = '%s %d/%d  %s  cost %.2f  %s' % (
            stage.name,
            stage.done,
            stage.cycles,
            self._describe(metrics),
            metrics.cost,
            'better' if better else 'not better: back to %s' % self._gain_text(stage.candidate),
        )
        final = self._gain_text(self.best_gains_for(stage))
        proposal = None
        if stage.done < stage.cycles and stage.step >= MIN_STEP:
            proposal = stage.propose(self.best_gains_for(stage), stage.best_metrics, stage.step)

        if proposal is not None:  # another test with new gains
            stage.candidate, reason = proposal
            return self._say('%s  | %s: %s' % (text, reason, self._gain_text(stage.candidate)))

        if stage.done >= stage.cycles:
            ending = 'stage done'
        elif stage.step < MIN_STEP:
            ending = 'converged'
        else:
            ending = 'nothing left to improve'
        self._next_stage()
        return self._say('%s  | %s, best: %s' % (text, ending, final))

    def abort(self, reason):
        """Stop. The best gains found so far stay in ``best_gains``."""
        if not self.aborted:
            self.aborted = reason or 'stopped'
            self.messages.append('stopped: ' + self.aborted)

    # ---------------------------------------------------------------- results
    def final_gains(self):
        """The best gains found (the starting ones for anything that was not tuned)."""
        return dict(self.best_gains)

    def summary(self):
        """A one-paragraph result."""
        parts = []
        for key in GAIN_KEYS:
            before, after = self.start_gains[key], self.best_gains[key]
            if abs(before - after) > 1e-6:
                parts.append('%s %.2f -> %.2f' % (key, before, after))
        return 'result: ' + (
            ', '.join(parts) if parts else 'no change, the gains were already the best measured'
        )

    # ---------------------------------------------------------------- helpers
    def best_gains_for(self, stage):
        return {k: self.best_gains[k] for k in stage.keys}

    def _measure(self, request, rows, t0, start_yaw):
        if request.kind == 'turn':
            return analyze_step(
                rows,
                t0,
                start_yaw,
                start_yaw + request.deg,
                TOLERANCE_DEG,
                TURN_CORRECTION_LIMIT,
                request.duration,
            )
        if request.kind == 'steer':
            return analyze_step(
                rows,
                t0,
                start_yaw,
                start_yaw + request.deg,
                TOLERANCE_DEG,
                STEER_CORRECTION_LIMIT,
                request.duration,
            )
        return analyze_drift(rows, t0, DRIFT_TOLERANCE_DEG, request.duration)

    def _say(self, text):
        self.messages.append(text)
        return text

    @staticmethod
    def _gain_text(gains):
        return ', '.join('%s %.2f' % (k, v) for k, v in gains.items())

    @staticmethod
    def _describe(m):
        if hasattr(m, 'overshoot_pct'):
            return 'overshoot %.0f %%, settle %.1f s, swings %d, error %+.1f deg' % (
                m.overshoot_pct,
                m.settle_s,
                m.ringing,
                m.final_error_deg,
            )
        return 'peak lean %.1f deg, settle %.1f s, swings %d, end error %.1f deg' % (
            m.peak_error_deg,
            m.settle_s,
            m.ringing,
            m.final_error_deg,
        )
