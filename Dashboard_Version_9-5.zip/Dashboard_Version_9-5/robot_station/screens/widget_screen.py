"""The widgets of every page, grouped so each page can be shown, clicked and typed into on its own."""

from robot_station import simulation
from robot_station import ui
from robot_station.config import (
    CW,
    GAME,
    LX,
    M,
    MONITOR,
    PID,
    RW,
    RX,
    SOURCES,
    TABS,
    TOP,
    TRANSPORTS,
    TUNE,
    VP,
    WW,
    X0,
)
from robot_station.ui.theme import ACCENT


class Screen:
    """All widgets, in groups: top (always), scene (Game and Monitor), mon (Monitor only), tune (Tune only), link and settings (one tab at a time)."""

    def __init__(self, app):
        """Build all the widget groups for this App."""
        self.top, self.scene, self.mon, self.tune, self.link, self.settings, self.pidg = (
            ui.Group() for _ in range(7)
        )
        self.build(app)

    def active(self, app):
        """The groups that are visible now."""
        page = {TUNE: self.tune, PID: self.pidg}.get(app.mode)
        return (
            [self.top]
            + ([page] if page else [self.scene])
            + ([self.mon] if app.mode == MONITOR else [])
            + [self.link if app.tab == 'link' else self.settings]
        )

    def motion(self, app, pos):
        """Mouse moved."""
        for g in self.active(app):
            g.motion(pos)

    def click(self, app, pos):
        """Mouse pressed: an open dropdown list takes the click first."""
        gs = self.active(app)
        for g in gs:  # an open dropdown list takes the click first
            if any(d.open for d in g.of(ui.Dropdown)):
                return g.click(pos)
        return any([g.click(pos) for g in gs])

    def draw(self, app, surf, fonts):
        """Draw the widgets, then any open lists on top."""
        for g in self.active(app):
            g.draw_widgets(surf, fonts)
        for g in self.active(app):
            g.draw_lists(surf, fonts)

    def release(self, app):
        """Mouse button released."""
        for g in (self.top, self.scene, self.mon, self.tune, self.link, self.settings, self.pidg):
            g.release()

    def close_all(self, app):
        """Close open dropdown lists."""
        for g in self.active(app):
            g.close_all()

    def any_open(self, app):
        """True while a dropdown list is open."""
        return any(d.open for g in self.active(app) for d in g.of(ui.Dropdown))

    def typing(self, app):
        """True while a text box has the keyboard."""
        return any(g.typing() for g in self.active(app))

    def key(self, app, e):
        """A key press for the text box."""
        return any([g.key(e) for g in self.active(app)])

    def drop_focus(self, app, pos):
        """Click outside a text box: release the keyboard."""
        for g in self.active(app):
            g.drop_focus(pos)

    def build(self, app):
        """Create every widget; each page has its own method."""
        self._build_top_bar(app)
        self._build_picture_header(app)
        self._build_tune_page(app)
        self._build_link_tab(app)
        self._build_pid_page(app)
        self._build_settings_tab(app)

    def _build_top_bar(self, app):
        """Top bar."""
        link = app.link
        B = ui.Button
        self.top.add(
            B(
                (250, 20, 92, 28),
                'Game',
                lambda: app.set_mode(GAME),
                active=lambda: app.mode == GAME,
            )
        )
        self.top.add(
            B(
                (346, 20, 92, 28),
                'Monitor',
                lambda: app.set_mode(MONITOR),
                active=lambda: app.mode == MONITOR,
            )
        )
        self.top.add(
            B(
                (442, 20, 92, 28),
                'Tune',
                lambda: app.set_mode(TUNE),
                active=lambda: app.mode == TUNE,
            )
        )
        self.top.add(
            B((538, 20, 62, 28), 'PID', lambda: app.set_mode(PID), active=lambda: app.mode == PID)
        )
        self.top.add(
            B(
                (606, 18, 150, 32),
                lambda: 'LINK  %s' % link.state,
                lambda: setattr(app, 'tab', 'link'),
            )
        )
        tx = CW - M - 176
        self.top.add(B((tx, 20, 54, 28), 'Timer', app.timer_toggle, active=lambda: app.timer_on))
        self.top.add(
            B((tx + 58, 20, 54, 28), 'Reset', app.timer_reset, enabled=lambda: app.timer_on)
        )
        self.top.add(
            B((tx + 116, 20, 60, 28), 'Restart', app.timer_restart, enabled=lambda: app.timer_on)
        )
        self.top.add(
            ui.Tabs(
                (RX + 8, TOP + 8, RW - 16, 30),
                TABS,
                lambda: app.tab,
                lambda v: setattr(app, 'tab', v),
            )
        )

    def _build_picture_header(self, app):
        """Picture header."""
        vx = VP[0] + VP[2]
        app.dd_view = self.scene.add(
            ui.Dropdown((vx - 176, TOP + 22, 176, 28), 'VIEW', [], app.cur_view, app.set_view)
        )
        self.mon.add(
            ui.Dropdown(
                (vx - 176 - 196, TOP + 22, 184, 28),
                'PICTURE FROM',
                SOURCES,
                lambda: app.source,
                lambda v: setattr(app, 'source', v),
            )
        )

    def _build_tune_page(self, app):
        """TUNE page: positions match draw_tune()."""
        link = app.link
        B = ui.Button
        T, armed, up = self.tune, (lambda: link.armed), (lambda: bool(app.tune_tel()))
        for side, cx in ((0, LX + 140), (1, LX + 390)):
            T.add(
                ui.Slider(
                    (cx - 120, 312, 240, 22),
                    lambda s=side: app.tune['vl' if s == 0 else 'vr'],
                    lambda v, s=side: app.set_motor(s, v),
                    -100,
                    100,
                    1,
                    0.03,
                    armed,
                    ACCENT,
                    '%d',
                )
            )
            T.add(B((cx - 120, 342, 70, 26), 'Stop', lambda s=side: app.set_motor(s, 0)))
            T.add(
                B(
                    (cx - 44, 342, 164, 26),
                    lambda s=side: (
                        'Wheel moves: SAVE'
                        if app.ramp and app.ramp['side'] == s
                        else 'Find start power'
                    ),
                    lambda s=side: app.ramp_toggle(s),
                    active=lambda s=side: bool(app.ramp and app.ramp['side'] == s),
                    enabled=lambda: link.armed and bool(app.cfg('minpwm') is not None),
                )
            )
        for i, cx in ((1, 544 + 130), (2, 544 + 370)):
            T.add(
                ui.Slider(
                    (cx - 120, 312, 240, 22),
                    lambda i=i: app.servo_value(i),
                    lambda v, i=i: app.set_servo(i, v),
                    0,
                    180,
                    1,
                    None,
                    armed,
                    (240, 170, 70),
                    '%d',
                )
            )
            T.add(
                B(
                    (cx - 120, 342, 70, 26),
                    'Limp',
                    lambda i=i: app.set_servo(i, None),
                    active=lambda i=i: app.tune['s%d' % i] is None,
                    enabled=armed,
                )
            )
            T.add(
                B((cx - 44, 342, 74, 26), 'Centre', lambda i=i: app.set_servo(i, 90), enabled=armed)
            )
            T.add(
                B(
                    (cx + 36, 342, 84, 26),
                    'Min / Max',
                    lambda i=i: app.set_servo(
                        i,
                        (
                            app.cfg('lo%d' % i)
                            if app.tune['s%d' % i] != app.cfg('lo%d' % i)
                            else app.cfg('hi%d' % i)
                        ),
                    ),
                    enabled=lambda: link.armed and app.cfg('lo1') is not None,
                )
            )
        T.add(
            B(
                (544 + 500 - 130, 96, 120, 22),
                lambda: 'Sweep: ON' if app.sweep else 'Sweep both',
                lambda: setattr(app, 'sweep', not app.sweep),
                active=lambda: app.sweep,
                enabled=armed,
            )
        )
        T.add(
            B(
                (LX + 520 - 190, 388, 180, 22),
                'Zero gyro (keep still)',
                lambda: link.send_frame('CAL'),
                enabled=up,
            )
        )
        rows = [
            ('Start power (MIN_PWM)', 'minpwm', 5, 0, 200, '%d'),
            ('Servo 1 min deg', 'lo1', 5, 0, 180, '%d'),
            ('Servo 1 max deg', 'hi1', 5, 0, 180, '%d'),
            ('Servo 2 min deg', 'lo2', 5, 0, 180, '%d'),
            ('Servo 2 max deg', 'hi2', 5, 0, 180, '%d'),
            ('Battery ratio', 'ratio', 0.05, 1.0, 6.0, '%.3f'),
        ]
        for k, (lab, key, step, lo, hi, fmt) in enumerate(rows):
            T.add(
                ui.Spin(
                    (706 + 12, 432 + k * 30, 314, 24),
                    lab,
                    lambda key=key: app.cfg(key),
                    lambda v, key=key: app.set_cfg(key, v),
                    step,
                    lo,
                    hi,
                    fmt,
                )
            )
        T.add(
            B(
                (706 + 12, 618, 152, 26),
                lambda: 'Left wheel: %s' % ('REVERSED' if app.cfg('invl') else 'normal'),
                lambda: app.invert(0),
                active=lambda: bool(app.cfg('invl')),
                enabled=up,
            )
        )
        T.add(
            B(
                (706 + 174, 618, 152, 26),
                lambda: 'Right wheel: %s' % ('REVERSED' if app.cfg('invr') else 'normal'),
                lambda: app.invert(1),
                active=lambda: bool(app.cfg('invr')),
                enabled=up,
            )
        )
        # Three buttons share one row: 98 px wide, 10 px apart.
        has_values = lambda: bool(link.tune_cfg)
        T.add(B((706 + 12, 652, 98, 26), 'Save file', app.save_values, enabled=has_values))
        T.add(
            B(
                (706 + 120, 652, 98, 26),
                'Undo',
                app.undo_values,
                enabled=lambda: bool(link.tune_cfg and app.tune_backup),
            )
        )
        T.add(
            B(
                (706 + 228, 652, 98, 26),
                lambda: 'Press again!' if app.reset_confirming() else 'Reset all',
                app.reset_all,
                active=app.reset_confirming,
                enabled=has_values,
            )
        )

    def _build_link_tab(self, app):
        """LINK tab (every widget keeps 10 px inside its card)."""
        link = app.link
        B = ui.Button
        L, idle = self.link, (lambda: not link.active)
        L.add(
            ui.Dropdown(
                (X0 + 10, 146, 150, 28),
                'CONNECT BY',
                TRANSPORTS,
                lambda: app.transport_kind,
                app.set_transport,
                enabled=idle,
            )
        )
        app.dd_target = L.add(
            ui.Dropdown(
                (X0 + 170, 146, WW - 180, 28),
                'DEVICE',
                [],
                app.target_value,
                app.set_target,
                enabled=idle,
            )
        )
        L.add(
            B(
                (X0 + 10, 184, 156, 28),
                lambda: 'Disconnect' if link.active else 'Connect',
                app.toggle_connection,
                active=lambda: link.active,
                enabled=lambda: not app.scanning(),
            )
        )
        L.add(
            B(
                (X0 + 172, 184, WW - 182, 28),
                lambda: 'Scan' if app.transport_kind == 'ble' else 'Refresh',
                app.refresh,
                enabled=lambda: idle() and not app.scanning(),
            )
        )
        L.add(
            B(
                (X0 + 10, 418, 160, 28),
                lambda: 'OUTPUT ARMED' if link.armed else 'ARM OUTPUT',
                app.toggle_arm,
                active=lambda: link.armed,
            )
        )
        L.add(B((X0 + WW - 170, 418, 160, 28), 'E-STOP  (Space)', app.estop, danger=True))
        term = L.add(ui.TextInput((X0 + 10, 752, WW - 82, 26), lambda t: link.send_raw(t)))
        L.add(
            B(
                (X0 + WW - 62, 752, 52, 26),
                'Send',
                lambda: (term.text and (link.send_raw(term.text), setattr(term, 'text', ''))),
                enabled=lambda: link.connected,
            )
        )
        L.add(B((X0 + 10, 788, 82, 22), 'Clear', link.log.clear))

    def _build_pid_page(self, app):
        """PID page: positions match draw_pid()."""
        link = app.link
        B = ui.Button
        H = self.pidg
        rows = [
            ('Hold strength  Kp', 'kp', 0.1, 0.0, 5.0, '%.1f'),
            ('Hold learning  Ki', 'ki', 0.1, 0.0, 5.0, '%.1f'),
            ('Hold damping  Kd', 'kd', 0.05, 0.0, 2.0, '%.2f'),
            ('Left wheel gain', 'gl', 0.01, 0.5, 1.5, '%.2f'),
            ('Right wheel gain', 'gr', 0.01, 0.5, 1.5, '%.2f'),
            ('Left start PWM', 'ml', 5, 0, 200, '%d'),
            ('Right start PWM', 'mr', 5, 0, 200, '%d'),
            ('Turn strength', 'skp', 0.1, 0.2, 4.0, '%.1f'),
            ('Turn damping', 'skd', 0.05, 0.0, 1.0, '%.2f'),
        ]
        for k, (lab, key, step, lo, hi, fmt) in enumerate(rows):
            H.add(
                ui.Spin(
                    (LX + 12, 428 + k * 28, 306, 24),
                    lab,
                    lambda key=key: app.hcfg(key),
                    lambda v, key=key: app.set_hcfg(key, v),
                    step,
                    lo,
                    hi,
                    fmt,
                )
            )
        H.add(
            B(
                (LX + 10, 690, 154, 28),
                lambda: 'Gyro hold: ON' if app.hcfg('hold') else 'Gyro hold: OFF',
                app.hold_toggle,
                active=lambda: bool(app.hcfg('hold')),
                enabled=lambda: app.hcfg('hold') is not None,
            )
        )
        H.add(
            B(
                (LX + 170, 690, 152, 28),
                'Flip gyro direction',
                app.gyro_flip,
                enabled=lambda: app.hcfg('gsign') is not None,
            )
        )
        H.add(
            B(
                (LX + 10, 724, 154, 28),
                'Reset balance',
                lambda: app.set_hcfg('bal', 0),
                enabled=lambda: app.hcfg('bal') is not None,
            )
        )
        H.add(B((LX + 170, 724, 152, 28), 'Re-zero heading', app.zero))
        can = lambda: (
            link.armed and app.hold_fresh() and app.pid_test is None and not app.autotune_running
        )
        H.add(
            B(
                (366, 640, 160, 28),
                'Straight 3 s (50%)',
                lambda: app.pid_start('straight'),
                enabled=can,
            )
        )
        for k, dg in enumerate((45, -45, 90, -90)):
            H.add(
                B(
                    (532 + k * 78, 640, 72, 28),
                    'Turn %+d' % dg,
                    lambda dg=dg: app.pid_start('turn', dg),
                    enabled=can,
                )
            )
        H.add(
            B(
                (848, 640, 92, 28),
                lambda: 'Resume' if app.hist_pause else 'Pause',
                lambda: setattr(app, 'hist_pause', not app.hist_pause),
                active=lambda: app.hist_pause,
            )
        )
        H.add(B((946, 640, 86, 28), 'Clear', app.hist.clear))

        # Auto-tune row (the status text under it is drawn by draw_pid).
        idle = lambda: not app.autotune_running
        H.add(
            B(
                (366, 732, 150, 28),
                lambda: 'STOP AUTO-TUNE' if app.autotune_running else 'AUTO-TUNE',
                app.autotune_toggle,
                active=lambda: app.autotune_running,
                enabled=lambda: app.autotune_running or can(),
            )
        )
        H.add(
            ui.Spin(
                (524, 732, 210, 28),
                'Cycles',
                lambda: app.autotune_cycles,
                app.set_autotune_cycles,
                1,
                1,
                12,
                '%d',
                enabled=idle,
            )
        )
        H.add(
            B(
                (742, 732, 290, 28),
                lambda: 'Tune: ' + app.autotune_what_label(),
                app.next_autotune_what,
                enabled=idle,
            )
        )

    def _build_settings_tab(self, app):
        """SETTINGS tab."""
        sim = app.sim
        B = ui.Button
        S, look = self.settings, app.look
        S.add(
            ui.Dropdown(
                (X0 + 10, 146, 160, 28),
                'DRIVE MODE',
                [(k, simulation.MODE_LABEL[k]) for k in simulation.MODES],
                lambda: sim.mode,
                lambda v: setattr(sim, 'mode', v),
            )
        )
        S.add(
            B(
                (X0 + 180, 146, WW - 190, 28),
                lambda: 'Turn (LT): ON' if sim.turn_on else 'Turn (LT): OFF',
                lambda: setattr(sim, 'turn_on', not sim.turn_on),
                active=lambda: sim.turn_on,
            )
        )
        S.add(
            ui.Stepper(
                (X0 + 10, 212, 152, 24),
                'Trail',
                lambda: look.trail_on,
                lambda v: setattr(look, 'trail_on', v),
                lambda: look.trail_i,
                lambda v: setattr(look, 'trail_i', v),
            )
        )
        S.add(
            ui.Stepper(
                (X0 + 186, 212, 152, 24),
                'Shadow',
                lambda: look.shadow_on,
                lambda v: setattr(look, 'shadow_on', v),
                lambda: look.shadow_i,
                lambda v: setattr(look, 'shadow_i', v),
            )
        )
        S.add(
            ui.Stepper(
                (X0 + 10, 246, 152, 24),
                'Arrow',
                lambda: look.arrow_on,
                lambda v: setattr(look, 'arrow_on', v),
                lambda: look.arrow_i,
                lambda v: setattr(look, 'arrow_i', v),
            )
        )
        S.add(B((X0 + 186, 246, 152, 24), 'Reset camera', look.reset_cam))
        S.add(B((X0 + 10, 316, 160, 28), 'Re-zero heading', app.zero))
        S.add(
            B(
                (X0 + 178, 316, 160, 28),
                'Reset cubes',
                sim.reset_cubes,
                enabled=lambda: app.mode == GAME,
            )
        )
        S.add(B((X0 + 10, 350, 160, 28), 'Reset robot', sim.reset_robot))
        S.add(B((X0 + 178, 350, 160, 28), 'Reset all', sim.reset))
        S.add(
            B(
                (X0 + 10, 430, 164, 28),
                'Fullscreen (F11)',
                app.toggle_fullscreen,
                active=lambda: app.fullscreen,
            )
        )
        S.add(
            B(
                (X0 + 10, 472, WW - 20, 24),
                lambda: 'Lift stick: REVERSED' if app.lift_invert else 'Lift stick: normal',
                lambda: (
                    setattr(app, 'lift_invert', not app.lift_invert),
                    app.save_settings(),
                ),
                active=lambda: app.lift_invert,
            )
        )
        S.add(
            B(
                (X0 + 10, 500, WW - 20, 28),
                lambda: 'Auto-reconnect: ON' if app.auto_reconnect else 'Auto-reconnect: OFF',
                lambda: (
                    setattr(app, 'auto_reconnect', not app.auto_reconnect),
                    app.save_settings(),
                ),
                active=lambda: app.auto_reconnect,
            )
        )
        S.add(
            ui.Spin(
                (X0 + 12, 540, WW - 24, 24),
                'Speed without RT (cm/s)',
                lambda: sim.slow_cm,
                lambda v: (setattr(sim, 'slow_cm', float(v)), app.save_settings()),
                1,
                10,
                simulation.MAX_SPEED,
                '%d',
            )
        )
